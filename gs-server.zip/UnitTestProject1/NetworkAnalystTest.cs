﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class NetworkAnalystTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
