﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GazServiceServerAdmin
{
    public class GetConfigurations
    {
        public static string GetConnectionString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["sqlConnection"].ConnectionString;
        }

        public static List<string> GetAdresses()
        {
            List<string> result = new List<string>();
            int n = 0;

            for (int i = 0; i < System.Configuration.ConfigurationManager.AppSettings.Count; i++)
            {
                if (int.TryParse(System.Configuration.ConfigurationManager.AppSettings.GetKey(i), out n))
                    result.Add(System.Configuration.ConfigurationManager.AppSettings[i]);
            }
            return result;
        }

        public static string GetValue(string key)
        {
            return System.Configuration.ConfigurationManager.AppSettings[key];
        }
    }
}