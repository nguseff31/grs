﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.SqlClient;
using System.Security.Principal;

namespace GazServiceServerAdmin
{
    public class roleAdmin
    {
        private static string getRoles(string field, WindowsPrincipal User)
        {
            string sqlWHERE = "";
            // Отобразить общую информацию о пользователе. 
            //User.Identity.Name;
            //User.Identity.AuthenticationType;
            WindowsPrincipal principal = User;
            WindowsIdentity identity = (WindowsIdentity)principal.Identity;

            foreach (IdentityReference SIDRef in identity.Groups)
            {
                // Получить системный код SID 
                SecurityIdentifier sid = (SecurityIdentifier)SIDRef.Translate(typeof(SecurityIdentifier));
                NTAccount account = (NTAccount)SIDRef.Translate(typeof(NTAccount));
                string[] rolll = account.Value.Split('\\');
                sqlWHERE += string.Format("or [{1}] like '{0}' ", rolll[rolll.Length - 1], field);
            }
            if (sqlWHERE.Length > 0)
            {
                sqlWHERE = sqlWHERE.Substring(2);
            }
            return sqlWHERE;
        }

        public static string getAllRolesAttributes()
        {
            string xmlResult = "<roles>";
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand("SELECT * FROM [GASADMIN].[dbo].[roles]", connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            xmlResult += string.Format("<role label=\"{0}\" alias=\"{1}\">", reader["role"], reader["alias"]);

                            using (SqlConnection connection2 = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                            {
                                using (SqlCommand command2 = new SqlCommand(string.Format("SELECT DISTINCT [layer] FROM [GASADMIN].[dbo].[attrs] WHERE [role] like '{0}'", reader["role"]), connection2))
                                using (SqlDataReader reader2 = command2.ExecuteReader())
                                {
                                    while (reader2.Read())
                                    {
                                        xmlResult += string.Format("<layer label=\"{0}\">", reader2["layer"]);

                                        using (SqlConnection connection3 = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                                        {
                                            using (SqlCommand command3 = new SqlCommand(string.Format("SELECT * FROM [GASADMIN].[dbo].[attrs] WHERE [role] like '{0}' and [layer] like '{1}'", reader["role"], reader2["layer"]), connection3))
                                            using (SqlDataReader reader3 = command3.ExecuteReader())
                                            {
                                                while (reader3.Read())
                                                {
                                                    xmlResult += string.Format("<field name=\"{0}\" label=\"{1}\"/>", reader3["attribute"], reader3["name"].ToString().Replace('"', '\''));
                                                }
                                            }
                                        }

                                        xmlResult += "</layer>";
                                    }
                                }
                            }

                            xmlResult += "</role>";
                        }
                    }
                }
            }
            xmlResult += "</roles>";
            return xmlResult;
        }

        public static void addLayerForRoleWithAttrs(string roleName, string layerName, string layerAttrs, string layerAttrAlias)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                string[] arr = layerAttrAlias.Split('|');
                int i = 0;
                foreach (string attr in layerAttrs.Split('|'))
                {
                    using (SqlCommand command = new SqlCommand(string.Format("INSERT INTO [GASADMIN].[dbo].[attrs] VALUES ('{0}', '{1}', '{2}', '{3}')", roleName, layerName, attr, arr[i]), connection))
                        command.ExecuteNonQuery();
                    i++;
                }
            }
        }

        public static void removeAttrFromLayer(string roleName, string layerName, string attrName, string attrAlias)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                string tmp = "";
                tmp = string.Format("and attribute like '{0}'", attrName);
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[attrs] WHERE role like '{0}' and layer like '{1}' {2}", roleName, layerName, tmp), connection))
                    command.ExecuteNonQuery();
                tmp = string.Format("and name like '{0}'", attrAlias);
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[attrs] WHERE role like '{0}' and layer like '{1}' {2}", roleName, layerName, tmp), connection))
                    command.ExecuteNonQuery();
            }
        }

        public static void removeLayerForRole(string roleName, string layerName)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[attrs] WHERE role like '{0}' and layer like '{1}'", roleName, layerName), connection))
                    command.ExecuteNonQuery();
            }
        }

        public static string getRolePlace(WindowsPrincipal User)
        {
            string xmlResult = "<places>";
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                string sqlWHERE = getRoles("filial", User);
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand("SELECT * FROM [GASADMIN].[dbo].[res] WHERE " + sqlWHERE, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            xmlResult += string.Format("<filial label=\"{0}\" code=\"{1}\"/>", reader["filial"], reader["filialcode"]);
                        }
                    }
                }
                sqlWHERE = getRoles("res", User);
                using (SqlConnection connection2 = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command2 = new SqlCommand("SELECT * FROM [GASADMIN].[dbo].[res] WHERE " + sqlWHERE, connection2))
                    using (SqlDataReader reader2 = command2.ExecuteReader())
                    {
                        while (reader2.Read())
                        {
                            xmlResult += string.Format("<res label=\"{0}\" code=\"{1}\"/>", reader2["res"], reader2["rescode"]);
                        }
                    }
                }
            }
            xmlResult += "</places>";
            return xmlResult;
        }

        public static string getRoleLayersEdits(WindowsPrincipal User)
        {
            string xmlResult = "<layers>";
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                string sqlWHERE = getRoles("role", User);
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand("SELECT * FROM [GASADMIN].[dbo].[edits] WHERE " + sqlWHERE, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            xmlResult += string.Format("<layer label=\"{0}\"/>", reader["layer"].ToString().Replace('"', '\''));
                        }
                    }
                }
            }
            xmlResult += "</layers>";
            return xmlResult;
        }

        public static string getRoleLayersFields(WindowsPrincipal User)
        {
            string xmlResult = "<layers>";
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                string sqlWHERE = getRoles("role", User);
                List<string> layers = new List<string>();
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand("SELECT DISTINCT [layer] FROM [GASADMIN].[dbo].[attrs] WHERE " + sqlWHERE, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            layers.Add(reader.GetString(0));
                        }
                    }

                    foreach (string layer in layers)
                    {
                        xmlResult += string.Format("<layer label=\"{0}\">", layer.ToString().Replace('"', '\''));
                        List<string> attrCol = new List<string>();
                        bool isHaveAttr = false;
                        using (SqlCommand command2 = new SqlCommand(string.Format("SELECT * FROM [GASADMIN].[dbo].[attrs] WHERE ({1}) and [layer] like '{0}'", layer, sqlWHERE), connection))
                        using (SqlDataReader reader2 = command2.ExecuteReader())
                        {
                            while (reader2.Read())
                            {
                                if (reader2["attribute"].ToString() != "" || reader2["attribute"].ToString() != null)
                                {
                                    foreach (string chkAttr in attrCol)
                                    {
                                        if (chkAttr == reader2["attribute"].ToString().Replace(" ", ""))
                                        {
                                            isHaveAttr = true;
                                            break;
                                        }
                                    }
                                    if (!isHaveAttr)
                                    {
                                        xmlResult += string.Format("<field name=\"{0}\" label=\"{1}\"/>", reader2["attribute"].ToString().Replace('"', '\'').Replace(" ", ""), reader2["name"].ToString().Replace('"', '\''));
                                        attrCol.Add(reader2["attribute"].ToString().Replace(" ", ""));
                                    }
                                }
                            }
                        }
                        xmlResult += "</layer>";
                    }
                }
            }
            xmlResult += "</layers>";
            return xmlResult;
        }
    }
}