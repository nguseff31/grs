﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using GeomertyNetworkWorker;

namespace GazServiceServerAdmin
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            //Инициализация параметров
            GeometryNetworkWorker.workLayers.grs = GetConfigurations.GetValue("gydro_grs");
            GeometryNetworkWorker.workLayers.prg = GetConfigurations.GetValue("gydro_prg");
            GeometryNetworkWorker.workLayers.subscriber = GetConfigurations.GetValue("gydro_subscriber");
            GeometryNetworkWorker.workLayers.consumer = GetConfigurations.GetValue("gydro_consumer");
            GeometryNetworkWorker.workLayers.gaspipeline = GetConfigurations.GetValue("gydro_gaspipeline");
            GeometryNetworkWorker.workLayers.network_Net_Junctions = GetConfigurations.GetValue("gydro_network_Net_Junctions");
            GeometryNetworkWorker.workspace = GetConfigurations.GetValue("gydro_workspace");
            GeometryNetworkWorker.type = GetConfigurations.GetValue("gydro_type");
            GeometryNetworkWorker.datasetname = GetConfigurations.GetValue("gydro_datasetname");
            GeometryNetworkWorker.geometrynetwork = GetConfigurations.GetValue("gydro_geometrynetwork");
            GeometryNetworkWorker.pipeattr = GetConfigurations.GetValue("gydro_pipeselect");
            
            int n = 0;
            for (int i = 0; i < System.Configuration.ConfigurationManager.AppSettings.Count; i++)
            {
                string key = System.Configuration.ConfigurationManager.AppSettings.GetKey(i);
                string[] arr = key.Split('_');
                if (arr[0] == "gydro")
                {
                    if (arr[1] == "attr")
                    {
                        if (arr[2] == "pipe")
                        {
                            GeometryNetworkWorker.workAttributes.pip.Add(arr[3], System.Configuration.ConfigurationManager.AppSettings[key]);
                        }
                        else if (arr[2] == "prg")
                        {
                            GeometryNetworkWorker.workAttributes.prg.Add(arr[3], System.Configuration.ConfigurationManager.AppSettings[key]);
                        }
                        else if (arr[2] == "subscriber")
                        {
                            GeometryNetworkWorker.workAttributes.sub.Add(arr[3], System.Configuration.ConfigurationManager.AppSettings[key]);
                        }
                        else if (arr[2] == "consumer")
                        {
                            GeometryNetworkWorker.workAttributes.con.Add(arr[3], System.Configuration.ConfigurationManager.AppSettings[key]);
                        }
                        else if (arr[2] == "grs")
                        {
                            GeometryNetworkWorker.workAttributes.grs.Add(arr[3], System.Configuration.ConfigurationManager.AppSettings[key]);
                        }
                    }
                }
            }
            GetNetworkArmat.workLayers.grs = GetConfigurations.GetValue("gas_armat_grs");
            GetNetworkArmat.workLayers.subscriber = GetConfigurations.GetValue("gas_armat_subscriber");
            GetNetworkArmat.workLayers.consumer = GetConfigurations.GetValue("gas_armat_consumer");
            GetNetworkArmat.workLayers.stpvalve = GetConfigurations.GetValue("gas_armat_stpvalve");
            GetNetworkArmat.workLayers.gaspipeline = GetConfigurations.GetValue("gas_armat_gaspipeline");
            GetNetworkArmat.workLayers.ArmtDataSet_Net_Junctions = GetConfigurations.GetValue("gas_armat_ArmtDataSet_Junctions");
            GetNetworkArmat.workspace = GetConfigurations.GetValue("gas_armat_GDBpath");
            GetNetworkArmat.type = GetConfigurations.GetValue("gas_armat_type");
            GetNetworkArmat.datasetname = GetConfigurations.GetValue("gas_armat_datasetname");
            GetNetworkArmat.geometrynetwork = GetConfigurations.GetValue("gas_armat_feature_classname");

            symbols_icons.icon_break = GetConfigurations.GetValue("icon_break_path");
            symbols_icons.icon_valve = GetConfigurations.GetValue("icon_valve_path");
            symbols_icons.symbols_path = GetConfigurations.GetValue("config_path");
            


        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}