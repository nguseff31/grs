﻿using System;
using System.Web.Services.Description;
using System.Collections.Generic;
using GazServiceServerAdmin;

namespace Msdn.Web.Services.Samples
{
    public class HttpsReflector : SoapExtensionReflector
    {
        public override void ReflectMethod()
        {
            //no-op
        }

        public override void ReflectDescription()
        {
            List<string> adresses = GetConfigurations.GetAdresses();

            ServiceDescription description = ReflectionContext.ServiceDescription;
            foreach (Service service in description.Services)
            {
                foreach (Port port in service.Ports)
                {
                    foreach (ServiceDescriptionFormatExtension extension in port.Extensions)
                    {
                        SoapAddressBinding binding = extension as SoapAddressBinding;
                        if (null != binding)
                        {
                            for (int i = 0; i < adresses.Count; i++)
                            {
                                binding.Location = binding.Location.Replace(adresses[i], "");
                            }
                                //binding.Location = binding.Location.Replace("10.74.132.232", "81.30.210.150:8888");
                                //if (!binding.Location.Contains(":8888") && binding.Location.Contains("81.30.210.150"))
                                //    binding.Location = binding.Location.Replace("81.30.210.150", "81.30.210.150:8888");
                                //binding.Location = binding.Location.Replace("192.168.30.232", "92.50.157.86:8888");
                            ////уфагаз
                            //binding.Location = binding.Location.Replace("http://10.74.132.232:8888", "");
                            //binding.Location = binding.Location.Replace("http://10.74.132.232", "");
                            //binding.Location = binding.Location.Replace("http://10.74.132.235:8888", "");
                            //binding.Location = binding.Location.Replace("http://10.74.132.235", "");  
                            //binding.Location = binding.Location.Replace("http://81.30.210.150:8888", "");
                            //binding.Location = binding.Location.Replace("http://81.30.210.150", "");
                            ////octopus
                            //binding.Location = binding.Location.Replace("http://octopus", "");
                            //binding.Location = binding.Location.Replace("http://172.20.1.100", "");
                            ////центргаз
                            //binding.Location = binding.Location.Replace("http://213.189.250.40:8889", "");
                            //binding.Location = binding.Location.Replace("http://213.189.250.40", "");                            
                            //binding.Location = binding.Location.Replace("http://192.168.2.174:8889", "");
                            //binding.Location = binding.Location.Replace("http://192.168.2.174", "");
                        }
                    }
                }
            }
        }
    }
}