﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.SqlClient;

namespace GazServiceServerAdmin
{
    public class attrAdmin
    {
        public static string getAllLayersRequriedFields()
        {
            try
            {
                string xmlResult = "<layers>";
                if (HttpContext.Current.Request.IsAuthenticated)
                {
                    List<string> layers = new List<string>();
                    using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                    {
                        using (SqlCommand command = new SqlCommand("SELECT DISTINCT [layer] FROM [GASADMIN].[dbo].[fields]", connection))
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                layers.Add(reader.GetString(0));
                            }
                        }
                        foreach (string layer in layers)
                        {
                            xmlResult += string.Format("<layer label=\"{0}\">", layer.ToString().Replace('"', '\''));
                            using (SqlCommand command2 = new SqlCommand(string.Format("SELECT * FROM [GASADMIN].[dbo].[fields] WHERE [layer] like '{0}'", layer), connection))
                            using (SqlDataReader reader2 = command2.ExecuteReader())
                            {
                                while (reader2.Read())
                                {
                                    if (reader2["attribute"].ToString() != "" || reader2["attribute"].ToString() != null)
                                    {
                                        xmlResult += string.Format("<field name=\"{0}\" label=\"{1}\"/>", reader2["attribute"].ToString().Replace('"', '\'').Replace(" ", ""), reader2["name"].ToString().Replace('"', '\''));
                                    }
                                }
                            }
                            xmlResult += "</layer>";
                        }
                    }
                }
                xmlResult += "</layers>";
                return xmlResult;
            }
            catch (Exception ex)
            {
                return string.Format("<error>{0}</error>", ex.Message);
            }
        }

        public static void addLayerForRequriedFields(string layerName, string layerAttrs, string layerAttrAlias)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                string[] arr = layerAttrAlias.Split('|');
                int i = 0;
                foreach (string attr in layerAttrs.Split('|'))
                {
                    using (SqlCommand command = new SqlCommand(string.Format("INSERT INTO [GASADMIN].[dbo].[fields] VALUES ('{0}', '{1}', '{2}')", layerName, attr, arr[i]), connection))
                        command.ExecuteNonQuery();
                    i++;
                }
            }
        }

        public static void removeRequriedFieldFromLayer(string layerName, string attrName, string attrAlias)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                string tmp = "";
                tmp = string.Format("and attribute like '{0}'", attrName);
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[fields] WHERE layer like '{0}' {1}", layerName, tmp), connection))
                    command.ExecuteNonQuery();
                tmp = string.Format("and name like '{0}'", attrAlias);
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[fields] WHERE layer like '{0}' {1}", layerName, tmp), connection))
                    command.ExecuteNonQuery();
            }
        }

        public static void removeLayerForRequriedFields(string layerName)
        {
            using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[fields] WHERE layer like '{0}'", layerName), connection))
                    command.ExecuteNonQuery();
            }
        }
    }
}