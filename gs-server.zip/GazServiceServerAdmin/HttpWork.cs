﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Web;


namespace GazServiceServerAdmin
{
    public class HttpWork
    {

        //"http://demos.legato.net/wps/wps?SERVICE=WPS&REQUEST=Execute"
        public static string HttpPost(string parameters, string uri)
        {
            WebRequest webRequest = WebRequest.Create(uri);
            ICredentials credent = new NetworkCredential("msergey90", "30071990", "gis");
            String ts = Environment.GetEnvironmentVariable("use_proxy");
           /* if (ts == null) ts = "NO";

            if (ts.ToUpper() == "YES")*/
                webRequest.Proxy = new WebProxy("172.20.1.1:8080", true, null, credent);
                webRequest.Method = "POST";

            byte[] data = Encoding.UTF8.GetBytes(parameters);

            Stream os = null;
            try
            {
                webRequest.ContentLength = data.Length;
                os = webRequest.GetRequestStream();
                os.Write(data, 0, data.Length);
            }
            catch (WebException ex)
            {
                // MessageBox.Show(ex.Message, "HttpPost: Request error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (os != null)
                {
                    os.Close();
                }
            }

            try
            {
                HttpWebResponse rsp = (HttpWebResponse)webRequest.GetResponse();
                System.IO.StreamReader reader = new System.IO.StreamReader(rsp.GetResponseStream());
                string strReturn = reader.ReadToEnd();
                return strReturn;
            }
            catch (WebException ex)
            {
                //  MessageBox.Show(ex.Message, "HttpPost: Response error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }

        //"http://demos.legato.net/wps/wps?SERVICE=WPS&REQUEST=DescribeProcess&IDENTIFIER=buffer"
        public static string HttpGet(string uri)
        {
            WebRequest webRequest = WebRequest.Create(uri);
            //ICredentials credent = new NetworkCredential("msergey90", "30071990", "gis");
            //String ts = Environment.GetEnvironmentVariable("use_proxy");
           /* if (ts == null) ts = "NO";
            if (ts.ToUpper() == "YES")*/
                //webRequest.Proxy = new WebProxy("172.20.1.1:8080", true, null, credent);
            webRequest.Method = "GET";

            try
            {
                WebResponse webResponse = webRequest.GetResponse();
                if (webResponse == null)
                { return null; }
                StreamReader sr = new StreamReader(webResponse.GetResponseStream());
                return sr.ReadToEnd().Trim();
            }
            catch (WebException ex)
            {
                // MessageBox.Show(ex.Message, "HttpGet: Response error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;





        }
    }
}