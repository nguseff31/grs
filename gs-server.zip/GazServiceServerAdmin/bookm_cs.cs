﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Security.Principal;
using System.Xml;
using System.Xml.Linq;

namespace GazServiceServerAdmin
{
    public class bookm_cs
    {

        public static string getUserBookmarks(WindowsPrincipal User)
        {
            WindowsPrincipal principal = User;
            string curuserName = User.Identity.Name;
            string[] tmpName = curuserName.Split('\\');
            curuserName = tmpName[tmpName.Length - 1];

            string username = "";

            string xmlResult = "<bookmarks> ";
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand("SELECT * FROM [GASADMIN].[dbo].[bookm]", connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            username = reader["username"].ToString();
                            if (username.ToLower() == curuserName.ToLower())
                            {
                                xmlResult += string.Format("<bkmr username=\"{0}\"  xmin=\"{1}\"  ymin=\"{2}\" xmax=\"{3}\" ymax=\"{4}\" name=\"{5}\" />", reader["username"], reader["xmin"], reader["ymin"], reader["xmax"], reader["ymax"], reader["name"]);
                            }
                            //xmlResult += string.Format("<bkmr username=\"{0}\"  xmin=\"{1}\"  ymin=\"{2}\" xmax=\"{3}\" ymax=\"{4}\" name=\"{5}\" />", reader["username"], reader["xmin"], reader["ymin"], reader["xmax"], reader["ymax"], reader["name"]);


                        }
                    }
                }
            }

            return xmlResult += " </bookmarks>";
        }


        public static void saveUserBookmarks(WindowsPrincipal User, XmlDocument xmlResult)
        {
            WindowsPrincipal principal = User;
            string curuserName = User.Identity.Name;
            string[] tmpName = curuserName.Split('\\');
            curuserName = tmpName[tmpName.Length - 1];

            if (HttpContext.Current.Request.IsAuthenticated)
            {
                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {
                    using (SqlCommand command = new SqlCommand(string.Format("DELETE FROM [GASADMIN].[dbo].[bookm] WHERE username like '{0}'", curuserName), connection))
                        command.ExecuteNonQuery();
                }


                using (SqlConnection connection = Helper.GetConnection(GetConfigurations.GetConnectionString()))
                {

                    foreach (XmlNode item in xmlResult.ChildNodes[0].ChildNodes)
                    {

                        //task.Attributes.GetNamedItem("id").Value

                        using (SqlCommand command = new SqlCommand(string.Format("INSERT INTO [GASADMIN].[dbo].[bookm] VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", curuserName,
                            item.Attributes["xmin"].Value, item.Attributes.GetNamedItem("ymin").Value,
                            item.Attributes.GetNamedItem("xmax").Value, item.Attributes.GetNamedItem("ymax").Value,
                            item.Attributes.GetNamedItem("name").Value), connection))

                            command.ExecuteNonQuery();

                    }



                }
            }



        }

    }
}