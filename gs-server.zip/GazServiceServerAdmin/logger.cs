﻿using System;
using System.Collections.Generic;
using System.Web;

namespace GazServiceServerAdmin
{
    public class logger
    {
        public static readonly string File;
        public string[][] info;
        private System.Data.DataSet dataSet;

        public DateTime data_start;
        public DateTime data_end;
        public DateTime data_for;
        public DateTime data_s;

        public String get_filter(string s_data_start, string s_data_end)
        {
            try
            {
                string[] s_data_start_spl = s_data_start.Split('.');
                string[] s_data_end_spl = s_data_end.Split('.');
                string month;
                string day;
                data_start = new DateTime(Convert.ToInt32(s_data_start_spl[0]), Convert.ToInt32(s_data_start_spl[1]), Convert.ToInt32(s_data_start_spl[2]));
                data_end = new DateTime(Convert.ToInt32(s_data_end_spl[0]), Convert.ToInt32(s_data_end_spl[1]), Convert.ToInt32(s_data_end_spl[2]));
                data_for = data_start;
                data_s = new DateTime(2012, 6, 1);
                //Количество дней за которые надо вывести логи
                var data_logi = data_end - data_start;


                int n = 0;
                String[] str_spl;
                String[] str_spl2;
                string line;
                string line2;

                string data;
                string time;
                string operation = "-";
                string objecID;
                string service = "/";
                string sloy = "/";

                string user_proverka = "-";
                string user = "-";
                string addr;

                
                System.IO.StreamReader file;

                string result = "<items>";
                /* string result_service = "<items>";
                 string result_operation = "<items>";*/
                result += String.Format("<item user=\"{0}\" />", "все");
                result += String.Format("<item2 service=\"{0}\" />", "все");
                result += String.Format("<item3 operation=\"{0}\" />", "все");
                result += String.Format("<item4 sloy=\"{0}\" />", "все");


                for (int i = 0; i <= Convert.ToInt32(data_logi.Days); i++)
                {



                    string year = (data_for.Year - 2000).ToString();
                    if (data_for.Month < 10)
                    {
                        month = "0" + data_for.Month.ToString();
                    }
                    else
                    {
                        month = data_for.Month.ToString();
                    }
                    if (data_for.Day < 10)
                    {
                        day = "0" + data_for.Day.ToString();
                    }
                    else
                    {
                        day = data_for.Day.ToString();
                    }


                    //Если файл существует тогда работаем с ним, иначе нах
                    if (System.IO.File.Exists(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log"))
                    {
                        int counter = 0;
                        int nachalo = 0;
                        int konec = 0;
                        file = new System.IO.StreamReader(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log");

                        while ((line = file.ReadLine()) != null)
                        {

                            if ((!(line.Contains("#"))) && (data_for >= data_s))
                            {
                                sloy = " ";
                                operation = " ";
                                if ((line.Contains("GET")) && (line.Contains("/ArcGIS/rest/services/")))
                                {
                                    if (line.Contains("logedit.html"))
                                    {
                                        str_spl = line.Split(' ');
                                        data = str_spl[0];
                                        time = str_spl[1];
                                        line2 = str_spl[6];
                                        str_spl2 = line2.Split('&');
                                        operation = str_spl2[0];
                                        objecID = str_spl2[1];
                                        addr = str_spl2[3];
                                        user = str_spl[8];
                                        //как только арслан сделает слой
                                        //sloy = str_spl2[2];
                                        //addr = str_spl2[3];  
                                        str_spl2 = addr.Split('/');
                                        for (int z = 0; z < str_spl2.Length; z++)
                                        {
                                            if (str_spl2[z] == "services")
                                            { nachalo = z; }

                                            if ((str_spl2[z] == "MapServer") || (str_spl2[z] == "FeatureServe"))
                                            { konec = z; }

                                        }
                                        if (konec != 0)
                                        {
                                            service = "/";
                                            for (int x = nachalo + 1; x < konec; x++)
                                            { service += str_spl2[x] + "/"; }

                                        }
                                        sloy = str_spl2[konec + 1];
                                        //sloy = str_spl2[2];


                                    }
                                    if ((line.Contains("FeatureServer")) && (!line.Contains("logedit.html")))
                                    {
                                        str_spl = line.Split(' ');
                                        data = str_spl[0];
                                        time = str_spl[1];
                                        addr = str_spl[5] + "?" + str_spl[6];// +"?" + str_spl[7];
                                        user = str_spl[8];
                                        
                                        str_spl2 = str_spl[5].Split('/');
                                        for (int z = 0; z < str_spl2.Length; z++)
                                        {
                                            if (str_spl2[z] == "services")
                                            { nachalo = z; }

                                            if ((str_spl2[z] == "FeatureServer"))
                                            { konec = z; }

                                        }
                                        if (konec != 0)
                                        {
                                            service = "/";
                                            for (int x = nachalo + 1; x < konec; x++)
                                            { service += str_spl2[x] + "/"; }

                                        }
                                        if (konec + 1 < str_spl2.Length)
                                        {
                                            sloy = str_spl2[konec + 1];
                                        }
                                        if (konec + 2 < str_spl2.Length)
                                        {
                                            operation = str_spl2[konec + 2];
                                        }

                                    }

                                    if ((line.Contains("MapServer")) && (!line.Contains("logedit.html")))
                                    {
                                        str_spl = line.Split(' ');
                                        data = str_spl[0];
                                        time = str_spl[1];
                                        addr = str_spl[5] + "?" + str_spl[6];// +"?" + str_spl[7];
                                        user = str_spl[8];

                                        str_spl2 = str_spl[5].Split('/');
                                        for (int z = 0; z < str_spl2.Length; z++)
                                        {
                                            if (str_spl2[z] == "services")
                                            { nachalo = z; }

                                            if ((str_spl2[z] == "MapServer"))
                                            { konec = z; }

                                        }
                                        if (konec != 0)
                                        {
                                            service = "/";
                                            for (int x = nachalo + 1; x < konec; x++)
                                            { service += str_spl2[x] + "/"; }

                                        }
                                        if (konec + 1 < str_spl2.Length)
                                        {
                                            if ((str_spl2[konec + 1].Contains("export")) || (str_spl2[konec + 1].Contains("legend")) || (str_spl2[konec + 1].Contains("query")) || (str_spl2[konec + 1].Contains("identify")) || (str_spl2[konec + 1].Contains("find")))
                                            {
                                                operation = str_spl2[konec + 1];
                                            }
                                            else
                                            {
                                                if (konec + 2 < str_spl2.Length)
                                                {
                                                    sloy = str_spl2[konec + 1];
                                                    operation = str_spl2[konec + 2];
                                                }
                                                else
                                                {
                                                    sloy = str_spl2[konec + 1];

                                                }


                                            }
                                        }


                                    }
                                }

                                if (line.Contains("POST"))
                                {

                                }
                                if (operation == "images") { operation = "просмотр изображения"; }
                                if (operation == "export") { operation = "просмотр карты"; }
                                if (operation == "legend") { operation = "просмотр легенды"; }
                                if (operation == "query") { operation = "поиск объектов"; }
                                if (operation == "identify") { operation = "идентификация"; }
                                if (operation == "ADD") { operation = "добавление объекта"; }
                                if (operation == "UPDATE") { operation = "обновление объекта"; }
                                if (operation == "DELETE") { operation = "удаление объекта"; }
                                if (operation == "find") { operation = "поиск ресурсов"; }



                                user_proverka = "user=\"" + user;
                                if (!result.Contains(user_proverka))
                                {
                                    result += String.Format("<item user=\"{0}\" />", user);
                                }

                                if (!result.Contains(service))
                                {

                                    result += String.Format("<item2 service=\"{0}\" />", service);
                                }
                                if ((!result.Contains(operation)) && (operation != "просмотр изображения") && (operation != "поиск объектов") && (operation != "просмотр легенды") && (operation != "идентификация") && (operation != "-"))
                                {
                                    bool canConvert2;
                                    int test2 = 0;
                                    canConvert2 = int.TryParse(operation, out test2);
                                    if (!canConvert2)
                                    {
                                        result += String.Format("<item3 operation=\"{0}\" />", operation);
                                    }
                                   
                                }
                                if (!result.Contains(sloy))
                                {
                                    bool canConvert;
                                    int test = 0;
                                    canConvert = int.TryParse(sloy, out test);

                                    
                                    if (canConvert)
                                    {
                                        result += String.Format("<item4 sloy=\"{0}\" />", sloy);
                                    }
                                }

                            }
                            counter++;
                            n++;
                        }

                    }
                    data_for = data_for.AddDays(1);
                }
                //result_service += "</items>";
                // result +="<item4 sloy=1 />";
                result += "</items>";
                return result;

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public String search_of_map(string s_data_start, string s_data_end, string user_, string service_, string operation_, string sloy_, double x_, double y_)
        {
            string[] s_data_start_spl = s_data_start.Split('.');
            string[] s_data_end_spl = s_data_end.Split('.');
            string month;
            string day;
            data_start = new DateTime(Convert.ToInt32(s_data_start_spl[0]), Convert.ToInt32(s_data_start_spl[1]), Convert.ToInt32(s_data_start_spl[2]));
            data_end = new DateTime(Convert.ToInt32(s_data_end_spl[0]), Convert.ToInt32(s_data_end_spl[1]), Convert.ToInt32(s_data_end_spl[2]));
            data_for = data_start;
            //Количество дней за которые надо вывести логи
            var data_logi = data_end - data_start;

            if (service_ == null)
            {
                service_ = "/";
            }
            if (user_ == null)
            {
                user_ = "-";
            }
            if (operation_ == null)
            {
                operation_ = "/";
            }
            if (sloy_ == null)
            {
                sloy_ = "/";
            }
            int n = 0;
            String[] str_spl;
            String[] str_spl2;
            string line;
            string line2;

            string data = " ";
            string time = " ";
            string operation = "-";
            string objecID = " ";
            string service = "/";
            string sloy = "/";
            double xmin, ymin, xmax, ymax;

            string user = "-";
            string addr = "-";

            
            String[] stroka;
            System.IO.StreamReader file;

            string result = "<items>";
            /* string result_service = "<items>";
             string result_operation = "<items>";*/

            for (int i = 0; i <= Convert.ToInt32(data_logi.Days); i++)
            {



                string year = (data_for.Year - 2000).ToString();
                if (data_for.Month < 10)
                {
                    month = "0" + data_for.Month.ToString();
                }
                else
                {
                    month = data_for.Month.ToString();
                }
                if (data_for.Day < 10)
                {
                    day = "0" + data_for.Month.ToString();
                }
                else
                {
                    day = data_for.Day.ToString();
                }


                //Если файл существует тогда работаем с ним, иначе нах
                if (System.IO.File.Exists(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log"))
                {
                    int counter = 0;
                    int nachalo = 0;
                    int konec = 0;
                    file = new System.IO.StreamReader(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log");

                    while ((line = file.ReadLine()) != null)
                    {

                        if (!(line.Contains("#")))
                        {
                            if (line.Contains("GET"))
                            {
                                if (line.Contains("logedit.html"))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    line2 = str_spl[6];
                                    str_spl2 = line2.Split('&');
                                    operation = "/" + str_spl2[0];
                                    objecID = str_spl2[1];
                                    addr = str_spl2[3];
                                    //как только арслан сделает слой
                                    //sloy = str_spl2[2];
                                    //addr = str_spl2[3];  
                                    str_spl2 = addr.Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "MapServer") || (str_spl2[z] == "FeatureServe"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    // sloy = "/" + str_spl2[konec + 1];
                                    sloy = "/" + str_spl2[2];


                                }
                                if (line.Contains("FeatureServer"))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    addr = str_spl[5] + "?" + str_spl[6];// +"?" + str_spl[7];
                                    user = str_spl[8];

                                    str_spl2 = str_spl[5].Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "FeatureServe"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    if (konec + 1 < str_spl2.Length)
                                    {
                                        sloy = "/" + str_spl2[konec + 1];
                                    }
                                    if (konec + 2 < str_spl2.Length)
                                    {
                                        operation = "/" + str_spl2[konec + 2];
                                    }

                                }
                                if (line.Contains("MapServer"))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    addr = str_spl[5] + "?" + str_spl[6] + "?" + str_spl[7];
                                    user = str_spl[8];

                                    str_spl2 = str_spl[5].Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "MapServer"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    if (konec + 1 < str_spl2.Length)
                                    {
                                        operation = "/" + str_spl2[konec + 1];
                                    }


                                }
                            }

                            if (line.Contains("POST"))
                            {

                            }
                            addr = System.Uri.UnescapeDataString(addr);

                            if (addr.Contains("bbox="))
                            {
                                //а надо ли? 
                                addr.Replace("bbox=", "^");
                                stroka = addr.Split('^');
                                stroka = stroka[2].Split('&');
                                stroka = stroka[1].Split(',');
                                xmin = Convert.ToDouble(stroka[0]);
                                ymin = Convert.ToDouble(stroka[1]);
                                xmax = Convert.ToDouble(stroka[2]);
                                ymax = Convert.ToDouble(stroka[3]);

                                if ((x_ > xmin) && (x_ < xmax) && (y_ > ymin) && (y_ < ymax))
                                {
                                    if ((service.Contains(service_)) && (user.Contains(user_)) && (operation.Contains(operation_)) && (sloy.Contains("/" + sloy_)))
                                    {
                                        result += String.Format("<item data=\"{0}\" time=\"{1}\" user=\"{2}\" service=\"{3}\" operation=\"{4}\" sloy=\"{5}\" objecID=\"{6}\" />", data, time, user, service, operation, sloy, objecID);
                                    }
                                }
                            }
                        }
                        counter++;
                        n++;
                    }

                }
                data_for = data_for.AddDays(1);
            }
            //result_service += "</items>";
            result += "</items>";
            return result;
        }

        public String search_of_filter(string s_data_start, string s_data_end, string user_, string service_, string operation_, string sloy_)
        {
            string[] s_data_start_spl = s_data_start.Split('.');
            string[] s_data_end_spl = s_data_end.Split('.');
            string month;
            string day;
            data_start = new DateTime(Convert.ToInt32(s_data_start_spl[0]), Convert.ToInt32(s_data_start_spl[1]), Convert.ToInt32(s_data_start_spl[2]));
            data_end = new DateTime(Convert.ToInt32(s_data_end_spl[0]), Convert.ToInt32(s_data_end_spl[1]), Convert.ToInt32(s_data_end_spl[2]));
            data_for = data_start;
            data_s = new DateTime(2012, 6, 1);
            //Количество дней за которые надо вывести логи
            var data_logi = data_end - data_start;

            if (service_ == null)
            { service_ = "/"; }
            if (service_ == "все")
            { service_ = "/"; }

            if (user_ == null)
            { user_ = "/"; }
            if (user_ == "все")
            { user_ = "/"; }

            if ((user_ != null)&&(user_ !="/"))
            { user_ = "/" + user_; }


            if (operation_ == null)
            { operation_ = "/"; }
            if (operation_ == "все")
            { operation_ = "/"; }

            if (sloy_ == null)
            { sloy_ = "/"; }
            if (sloy_ == " ")
            { sloy_ = "/"; }
            if (sloy_ == "")
            { sloy_ = "/"; }
            if (sloy_ == "все")
            { sloy_ = "/"; }




            int n = 0;
            String[] str_spl;
            String[] str_spl2;
            string line;
            string line2;

            string data = " ";
            string time = " ";
            string operation = "/";
            string objecID = " ";
            string service = "/";
            string sloy = "/";
            string map = "/";

            string user = "/";
            string addr;

            string ts_s;
            String[] stroka;
            String[] stroka2;
            String[] ts_spl;
            System.IO.StreamReader file;

            string result = "<items>";
            /* string result_service = "<items>";
             string result_operation = "<items>";*/

            for (int i = 0; i <= Convert.ToInt32(data_logi.Days); i++)
            {



                string year = (data_for.Year - 2000).ToString();
                if (data_for.Month < 10)
                {
                    month = "0" + data_for.Month.ToString();
                }
                else
                {
                    month = data_for.Month.ToString();
                }
                if (data_for.Day < 10)
                {
                    day = "0" + data_for.Day.ToString();
                }
                else
                {
                    day = data_for.Day.ToString();
                }


                //Если файл существует тогда работаем с ним, иначе нах
                if (System.IO.File.Exists(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log"))
                {
                    int counter = 0;
                    int nachalo = 0;
                    int konec = 0;
                    file = new System.IO.StreamReader(@"c:\WINDOWS\system32\LogFiles\W3SVC1\u_ex" + year + month + day + ".log");

                    while ((line = file.ReadLine()) != null)
                    {

                        if ((!(line.Contains("#"))) && (data_for >= data_s))
                        {

                            if ((line.Contains("GET")) && (line.Contains("/ArcGIS/rest/services/")))
                            {
                                objecID = " ";
                                map = " ";
                                sloy = "/";
                                operation = "/";

                                if (line.Contains("logedit.html"))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    line2 = str_spl[6];
                                    str_spl2 = line2.Split('&');
                                    operation = "/" + str_spl2[0];
                                    objecID = str_spl2[1];
                                    addr = str_spl2[3];
                                    user = "/" + str_spl[8];
                                    //как только арслан сделает слой
                                    //sloy = str_spl2[2];
                                    //addr = str_spl2[3];  
                                    str_spl2 = addr.Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "MapServer") || (str_spl2[z] == "FeatureServer"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    sloy = "/" + str_spl2[konec + 1];
                                    //sloy = str_spl2[2];


                                }
                                if ((line.Contains("FeatureServer")) && (!line.Contains("logedit.html")))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    addr = str_spl[5] + "?" + str_spl[6];// +"?" + str_spl[7];
                                    user ="/" + str_spl[8];

                                    str_spl2 = str_spl[5].Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "FeatureServer"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    if (konec + 1 < str_spl2.Length)
                                    {
                                        sloy = "/" + str_spl2[konec + 1];
                                    }
                                    if (konec + 2 < str_spl2.Length)
                                    {
                                        operation = "/" + str_spl2[konec + 2];
                                    }

                                }
                                if ((line.Contains("MapServer")) && (!line.Contains("logedit.html")))
                                {
                                    str_spl = line.Split(' ');
                                    data = str_spl[0];
                                    time = str_spl[1];
                                    addr = str_spl[5] + "?" + str_spl[6] + "?" + str_spl[7];
                                    user ="/"+ str_spl[8];
                                    if (line.Contains("export"))
                                    {
                                        map = str_spl[6];
                                        map = map.Replace("bbox=", "^");
                                        stroka = map.Split('^');
                                        map = stroka[1];
                                        stroka2 = stroka[1].Split('&');
                                        map = stroka2[0];
                                        map = System.Uri.UnescapeDataString(map);
                                    }

                               /*     if ((line.Contains("identify")) && (line.Contains("xmin")))
                                    {
                                        map = str_spl[6];
                                        map = map.Replace("xmin", "^");
                                        stroka = map.Split('^');
                                        map = stroka[1];
                                        stroka2 = stroka[1].Split('&');
                                        map = stroka2[0];
                                        map = map.Replace("ymin", "^");
                                        map = map.Replace("xmax", "^");
                                        map = map.Replace("ymax", "^");
                                        stroka = map.Split('^');

                                        string ss = System.Uri.UnescapeDataString(stroka[0]);
                                        string ss2 = System.Uri.UnescapeDataString(stroka[1]);
                                        string ss3 = System.Uri.UnescapeDataString(stroka[2]);
                                        string ss4 = System.Uri.UnescapeDataString(stroka[3]);
                                        stroka = ss.Split(':');
                                        ss = stroka[1];
                                        stroka = ss.Split(',');
                                        ss = stroka[0];
                                        stroka = ss2.Split(':');
                                        ss2 = stroka[1];
                                        stroka = ss2.Split(',');
                                        ss2 = stroka[0];
                                        stroka = ss3.Split(':');
                                        ss3 = stroka[1];
                                        stroka = ss3.Split(',');
                                        ss3 = stroka[0];
                                        stroka = ss4.Split(':');
                                        ss4 = stroka[1];
                                        stroka = ss4.Split('}');
                                        ss4 = stroka[0];
                                        map = ss + "," + ss2 + "," + ss3 + "," + ss4;// +"," + System.Uri.UnescapeDataString(stroka[1]) + "," + System.Uri.UnescapeDataString(stroka[2]) + "," + System.Uri.UnescapeDataString(stroka[3]);
                                        //map = System.Uri.UnescapeDataString(map);
                                    }

                                    if ((line.Contains("identify")) && (!line.Contains("xmin")) && (line.Contains("geometry=%7B%22x%22%3A")))
                                    {
                                        map = str_spl[6];
                                        map = map.Replace("%7B%22x%22%3A", "^");
                                        stroka = map.Split('^');
                                        map = stroka[1];

                                        map = map.Replace("%7D", "^");
                                        map = map.Replace("%2C%22y%22%3A", "^");
                                        stroka = map.Split('^');

                                        //map = stroka[1];


                                        string ss = System.Uri.UnescapeDataString(stroka[0]);
                                        string ss2 = System.Uri.UnescapeDataString(stroka[1]);


                                        map = ss + "," + ss2;
                                    }*/





                                    str_spl2 = str_spl[5].Split('/');
                                    for (int z = 0; z < str_spl2.Length; z++)
                                    {
                                        if (str_spl2[z] == "services")
                                        { nachalo = z; }

                                        if ((str_spl2[z] == "MapServer"))
                                        { konec = z; }

                                    }
                                    if (konec != 0)
                                    {
                                        service = "/";
                                        for (int x = nachalo + 1; x < konec; x++)
                                        { service += str_spl2[x] + "/"; }

                                    }
                                    /*  if (konec + 1 < str_spl2.Length)
                                      {
                                          operation = "/" + str_spl2[konec + 1];
                                      }*/

                                    if (konec + 1 < str_spl2.Length)
                                    {
                                        if ((str_spl2[konec + 1].Contains("export")) || (str_spl2[konec + 1].Contains("legend")) || (str_spl2[konec + 1].Contains("query")) || (str_spl2[konec + 1].Contains("identify")) || (str_spl2[konec + 1].Contains("find")))
                                        {
                                            operation = "/" + str_spl2[konec + 1];
                                        }
                                        else
                                        {
                                            if (konec + 2 < str_spl2.Length)
                                            {
                                                sloy = "/" + str_spl2[konec + 1];
                                                operation = "/" + str_spl2[konec + 2];
                                            }
                                            else
                                            {
                                                sloy = "/" + str_spl2[konec + 1];

                                            }


                                        }
                                    }

                                }





                            }

                            if (line.Contains("POST"))
                            {

                            }
                            if (operation_ == "просмотр изображения") { operation_ = "images"; }
                            if (operation_ == "просмотр карты") { operation_ = "export"; }
                            if (operation_ == "просмотр легенды") { operation_ = "legend"; }
                            if (operation_ == "поиск объектов") { operation_ = "query"; }
                            if (operation_ == "идентификация") { operation_ = "identify"; }
                            if (operation_ == "добавление объекта") { operation_ = "ADD"; }
                            if (operation_ == "обновление объекта") { operation_ = "UPDATE"; }
                            if (operation_ == "удаление объекта") { operation_ = "DELETE"; }
                            if (operation_ == "поиск ресурсов") { operation_ = "find"; }

                            
                            if (operation=="/DELETE")
                            {
                                result += String.Format("<item2 sloy=\"{0}\" objecID=\"{1}\" />", sloy, objecID);
                            }
                            
                            if ((service.Contains(service_)) && (user.Contains(user_)) && (operation.Contains(operation_)) && (sloy.Contains(sloy_)))
                            {
                                if (operation == "/images") { operation = "просмотр изображения"; }
                                if (operation == "/export") { operation = "просмотр карты"; }
                                if (operation == "/legend") { operation = "просмотр легенды"; }
                                if (operation == "/query") { operation = "поиск объектов"; }
                                if (operation == "/identify") { operation = "идентификация"; }
                                if (operation == "/ADD") { operation = "добавление объекта"; }
                                if (operation == "/UPDATE") { operation = "обновление объекта"; }
                                if (operation == "/DELETE") { operation = "удаление объекта"; }
                                if (operation == "/find") { operation = "поиск ресурсов"; }

                                if (sloy == "/")
                                {
                                    sloy = "-";
                                }
                                if (operation == "/")
                                {
                                    operation = "-";
                                }

                                bool canConvert2;
                                int test2 = 0;

                                if (user_.Length > 2)
                                {
                                    canConvert2 = int.TryParse(operation, out test2);
                                    if ((operation != "просмотр изображения") && (operation != "поиск объектов") && (operation != "просмотр легенды") && (operation != "идентификация") && (operation != "-") && (user == user_) && (!canConvert2))
                                    {
                                            user = user.Replace("/", "");
                                            result += String.Format("<item data=\"{0}\" time=\"{1}\" user=\"{2}\" service=\"{3}\" operation=\"{4}\" sloy=\"{5}\" objecID=\"{6}\" map=\"{7}\" />", data, time, user, service, operation, sloy, objecID, map);
                                      
                                    }
                                    sloy = "-";
                                    operation = "-";
                                    objecID = " ";
                                }
                                else 
                                {
                                    canConvert2 = int.TryParse(operation, out test2);

                                    if ((operation != "просмотр изображения") && (operation != "поиск объектов") && (operation != "просмотр легенды") && (operation != "идентификация") && (operation != "-") && (!canConvert2))
                                    {
                                                user = user.Replace("/", "");
                                                result += String.Format("<item data=\"{0}\" time=\"{1}\" user=\"{2}\" service=\"{3}\" operation=\"{4}\" sloy=\"{5}\" objecID=\"{6}\" map=\"{7}\" />", data, time, user, service, operation, sloy, objecID, map);
                                    }
                                    sloy = "-";
                                    operation = "-";
                                    objecID = " ";
                                }
                            }

                        }
                        counter++;
                        n++;
                    }

                }
                data_for = data_for.AddDays(1);
            }
            //result_service += "</items>";
            result += "</items>";
            return result;
        }







    }
}