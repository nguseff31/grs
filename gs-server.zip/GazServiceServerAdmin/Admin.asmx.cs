﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data;
using System.IO;
using System.Security.Principal;
using System.Net.Mail;
using GeomertyNetworkWorker;
//using Excel = Microsoft.Office.Interop.Excel;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Xml;
using System.Xml.Linq;
using System.Web.Script.Services;
using FluorineFx.AMF3;
using FluorineFx;
using MS.Internal.WindowsBase;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SRow = DocumentFormat.OpenXml.Spreadsheet.Row;
using SevenZip.Compression.LZMA;
using System.Text;

namespace GazServiceServerAdmin
{
    /// <summary>
    /// Сводное описание для Admin
    /// </summary>
    [WebService(Namespace = "http://81.30.210.150:8888/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Чтобы разрешить вызывать веб-службу из скрипта с помощью ASP.NET AJAX, раскомментируйте следующую строку. 
    // [System.Web.Script.Services.ScriptService]
    public class Admin : System.Web.Services.WebService
    {
       

        #region Роли
        //begin*******************Роли***************************//
        [WebMethod]
        public string getRoleLayersFields()
        {
            return roleAdmin.getRoleLayersFields((WindowsPrincipal)User);
        }

        [WebMethod]
        public string getRoleLayersEdits()
        {
            return roleAdmin.getRoleLayersEdits((WindowsPrincipal)User);
        }

        [WebMethod]
        public string getRolePlace()
        {
            return roleAdmin.getRolePlace((WindowsPrincipal)User);
        }

        [WebMethod]
        public void removeLayerForRole(string roleName, string layerName)
        {
            roleAdmin.removeLayerForRole(roleName, layerName);
        }

        [WebMethod]
        public void removeAttrFromLayer(string roleName, string layerName, string attrName, string attrAlias)
        {
            roleAdmin.removeAttrFromLayer(roleName, layerName, attrName, attrAlias);
        }

        [WebMethod]
        public void addLayerForRoleWithAttrs(string roleName, string layerName, string layerAttrs, string layerAttrAlias)
        {
            roleAdmin.addLayerForRoleWithAttrs(roleName, layerName, layerAttrs, layerAttrAlias);
        }

        [WebMethod]
        public string getAllRolesAttributes()
        {
            return roleAdmin.getAllRolesAttributes();
        }
        //*******************Роли***************************end//
        #endregion Роли

        #region Поля
        //begin*******************Поля***************************//
        [WebMethod]
        public string getAllLayersRequriedFields()
        {
            return attrAdmin.getAllLayersRequriedFields();
        }

        [WebMethod]
        public void addLayerForRequriedFields(string layerName, string layerAttrs, string layerAttrAlias)
        {
            attrAdmin.addLayerForRequriedFields(layerName, layerAttrs, layerAttrAlias);
        }

        [WebMethod]
        public void removeRequriedFieldFromLayer(string layerName, string attrName, string attrAlias)
        {
            attrAdmin.removeRequriedFieldFromLayer(layerName, attrName, attrAlias);
        }

        [WebMethod]
        public void removeLayerForRequriedFields(string layerName)
        {
            attrAdmin.removeLayerForRequriedFields(layerName);
        }
        //*******************Поля***************************end//
        #endregion Поля

        #region Закладки
        //begin************Закладки***************************//
        [WebMethod]
        public string getBookmarks()
        {

            string xmlResult = bookm_cs.getUserBookmarks((WindowsPrincipal)User);

            if (!String.IsNullOrEmpty(xmlResult))
            {
                if (xmlResult.StartsWith("<bookmarks>") && xmlResult.EndsWith("</bookmarks>"))
                {
                    return xmlResult;

                }
                else
                {
                    return "<bookmarks></bookmarks>";
                }
            }
            else
            {
                return "<bookmarks></bookmarks>";
            }
        }

        [WebMethod]
        public void saveBookmarks(string xml)
        {
            XmlDocument xmlResult = new XmlDocument();
            xmlResult.LoadXml(xml);


            bookm_cs.saveUserBookmarks((WindowsPrincipal)User, xmlResult);
        }
        //*******************Закладки*********************end//
        #endregion Закладки


        #region Задвижки

        [WebMethod]
        public string getSymbolsSettings()
        {
            symbols sym = new symbols();
            

            string result;
            result = sym.getSettings();
            return result;
        
        }
        [WebMethod]
        public string[] getFileListbreak()
        {
            symbols sym = new symbols();
            return sym.getListOfBreaks();

           

            
        }
        [WebMethod]
        public string[] getFileListvalve()
        {
            symbols sym = new symbols();
            return sym.getListOfValves();

        
        }

        [WebMethod]
        public void saveSSettings(string xmlResult)
        {
            symbols sym = new symbols();
            sym.saveSettings(xmlResult);

        }
        #endregion


        #region Сеть
        [WebMethod]
        public String get_Network(string layer, double x, double y, List<string> inputPressure, double qip, double qif)
        {
            GeometryNetworkWorker gnw = new GeometryNetworkWorker();
            return gnw.CreateFullGeometricNetwork(layer, x, y, inputPressure, Server.MapPath("~\\Logs"), qip, qif);
        }

        [WebMethod]
        public List<string> get_Pressures(string layer, double x, double y)
        {
            GeometryNetworkWorker gnw = new GeometryNetworkWorker();
            return gnw.GetPressures(layer, x, y);
        }

        //[WebMethod]
        //public String GetNetworkArmat(int oid, string layer)
        //{
        //    GetNetworkArmat gnw = new GetNetworkArmat();
        //    return gnw.CreateFullGeometricNetwork(oid, layer);
        //}

        [WebMethod]
        public byte[] GetNetworkArmat(int x, int y, string layer, string JIDs)
        {
            
            GetNetworkArmat gnw = new GetNetworkArmat();
            UTF8Encoding encoding = new UTF8Encoding();
            return SevenZipHelper.Compress(encoding.GetBytes(JsonConvert.SerializeObject(gnw.CreateFullGeometricNetwork(x, y, layer, JIDs))));
        }
        /*public String[] GetNetworkArmat(int x, int y, string layer, string JIDs)
        {
            
                GetNetworkArmat gnw = new GetNetworkArmat();
                return gnw.CreateFullGeometricNetwork(x, y, layer, JIDs);
           
        }*/
        
		[WebMethod]
        public String GetNetworkAbon(string idArms, string layer)
        {
            GetNetworkAbon gnw = new GetNetworkAbon();
            return gnw.CreateFullGeometricNetwork(idArms, layer);
        }
        #endregion

        [WebMethod]
        public string SaveToShape(string points)
        {
            string fileName = System.IO.Path.GetRandomFileName();
            fileName = fileName.Substring(0, fileName.Length - 4);
            string shapesDIR = Server.MapPath("~\\Shapes");
            ToShape.SaveToShapeFile(points, shapesDIR, fileName);
            return @"Shapes\" + fileName + @"\Network.zip";
        }

        [WebMethod]
        public String get_filter(string s_data_start, string s_data_end)
        {
            logger log = new logger();
            return log.get_filter(s_data_start, s_data_end);
        }

        [WebMethod]
        public String search_of_map(string s_data_start, string s_data_end, string user_, string service_, string operation_, string sloy_, double x_, double y_)
        {
            logger log = new logger();
            return log.search_of_map(s_data_start, s_data_end, user_, service_, operation_, sloy_, x_, y_);
        }

        [WebMethod]
        public String search_of_filter(string s_data_start, string s_data_end, string user_, string service_, string operation_, string sloy_)
        {
            logger log = new logger();
            return log.search_of_filter(s_data_start, s_data_end, user_, service_, operation_, sloy_);
        }

        [WebMethod]
        public string sendEmail(String phone, String subject, String mess)
        {
            try
            {
                string adress = GetConfigurations.GetValue("adminmailadress");
                MailAddress fromAddress = new MailAddress(adress, GetConfigurations.GetValue("toname"));
                MailAddress to = new MailAddress(GetConfigurations.GetValue("toadress"), GetConfigurations.GetValue("toname"));
                MailMessage message = new MailMessage(fromAddress, to);
                message.Subject = subject;
                message.IsBodyHtml = false;
                message.Body = "Системный логин отправителя: " + ((WindowsPrincipal)User).Identity.Name + ", указанный контактный телефон: " + phone + "\n" + mess;
                SmtpClient smtpClient = new SmtpClient(GetConfigurations.GetValue("smtpadress"), int.Parse(GetConfigurations.GetValue("smtpport")));
                smtpClient.Credentials = new System.Net.NetworkCredential(adress, GetConfigurations.GetValue("adminmailpassword"));
                smtpClient.Send(message);
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// Метод для сохранения настроек на сервере
        /// </summary>
        /// <param name="name">Название файла</param>
        /// <param name="receivedData">Параметры</param>
        /// <returns>Результат сохранения</returns>
        [WebMethod]
        public bool SaveXMLconfig(string name, object receivedData)
        {
            if (receivedData == null) return false;
            if (receivedData as XmlNode[] == null) return false;
            string saveData = (receivedData as XmlNode[])[0].InnerText;
            try
            {
                receivedData = "<root title='" + name + "'>\n" + saveData + "\n</root>";
                string path = "C:\\Server\\Configurations\\" + name + ".xml";
                FileStream FS = new FileStream(path, FileMode.Create);
                StreamWriter sw = new StreamWriter(FS);
                sw.Write(receivedData);
                sw.Close();
                FS.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Метод для передачи клиенту настроек, хранящихся на сервере
        /// </summary>
        /// <returns>Массив строчек, представляющих собой содержимое XML-документов</returns>
        [WebMethod]
        public string[] GetXMLconfigs()
        {
            string path = "C:\\Server\\Configurations\\";
            try
            {
                FileStream FS;
                StreamReader SR;
                DirectoryInfo di = new DirectoryInfo(path);
                FileInfo[] fi = di.GetFiles();
                string[] xmls = new string[fi.Length];
                //XmlNode[] xmls = new XmlNode[];
                for (int i = 0; i < xmls.Length; i++)
                {
                    FS = new FileStream(path + fi[i].Name, FileMode.Open, FileAccess.Read);
                    SR = new StreamReader(FS);
                    xmls[i] = SR.ReadToEnd();
                    SR.Close();
                    FS.Close();
                }
                return xmls;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        #region Создание XLSX
        List<Dictionary<string, object>> aliasDicAr;
        [WebMethod]
        public string ConverttoXLS(byte[] receiveData, byte[] receiveAl)
        {
            #region old
            //if (receiveAl == null) return "";
            //ByteArray bArrAl = new ByteArray();
            //bArrAl = BytesToByteArray(receiveAl);
            //object[] ac = (object[])bArrAl.ReadObject();
            //Dictionary<string, object> aliasDic;
            //aliasDicAr = new Dictionary<string, string>();
            //for (int i = 0; i < ac.Length; i++)
            //{
            //    aliasDic = (Dictionary<string, object>)ac[i];
            //    aliasDicAr.Add(aliasDic["name"].ToString(), aliasDic["alias"].ToString());
            //}
            //aliasDicAr.Add("geometry", "Геометрия");
            //if (receiveData == null) return "";
            //byte[] ba = { };
            //ba = SevenZip.Compression.LZMA.SevenZipHelper.Decompress(receiveData);
            //ByteArray bArr = new ByteArray();
            //bArr = BytesToByteArray(ba);
            //object[] ob = (object[])bArr.ReadObject();
            //try
            //{
            //    string timesStamp = DateTime.Now.ToString("dd-MM-yyyy_HH.mm.ss.fff") + ".xlsx";
            //    string path = Server.MapPath("~\\temp\\") + timesStamp;
            //    saveXLS3(path, ob);
            //    return timesStamp;
            //}
            //catch (Exception ex)
            //{
            //    System.Diagnostics.Debug.Print(ex.Message);
            //    return "";
            //}
            #endregion

            if (receiveAl == null) return "";
            ByteArray bArrAl = new ByteArray();
            bArrAl = BytesToByteArray(receiveAl);
            object[] ac = (object[])bArrAl.ReadObject();
            Dictionary<string, object> aliasDic;

            aliasDicAr = new List<Dictionary<string, object>>();
            for (int i = 0; i < ac.Length; i++)
            {
                aliasDic = (Dictionary<string, object>)ac[i];
                aliasDicAr.Add(aliasDic);
            }
            if (receiveData == null) return "";
            byte[] ba = { };
            ba = SevenZip.Compression.LZMA.SevenZipHelper.Decompress(receiveData);

            ByteArray bArr = new ByteArray();
            bArr = BytesToByteArray(ba);
            string JSONstr = bArr.ReadUTFBytes(bArr.Length);
            JArray ja = JArray.Parse(JSONstr);
            try
            {
                string timesStamp = DateTime.Now.ToString("dd-MM-yyyy_HH.mm.ss.fff") + ".xlsx";
                string path = Server.MapPath("~\\temp\\") + timesStamp;
                saveXLS3(path, ja);
                return timesStamp;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print(ex.Message);
                return "";
            }
        }
        /*//сохраняет в xls
        public void saveXLS(string path, XmlDocument xDoc)
        {
            try
            {
                DateTime dt0 = new DateTime();
                DateTime dt1 = new DateTime();
                dt0 = DateTime.Now;
                XmlNodeList nodes = xDoc.SelectNodes("root/source/item");
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook XWork = xlApp.Workbooks.Add(Type.Missing);
                Excel.Worksheet XSheet = XWork.Sheets.Add(Type.Missing);

                xlApp.Interactive = false;
                xlApp.EnableEvents = false;

                for (int i = 0; i < nodes.Count; i++)
                {
                    XmlNodeList xNodes = nodes[i].SelectNodes("*");
                    char s = 'A';
                    if (i == 0)
                    {
                        for (int j = 0; j < xNodes.Count && j < 26; j++)
                        {
                            XSheet.get_Range(s + (i + 1).ToString(), Type.Missing).Value2 = xNodes[j].Name;
                            XSheet.get_Range(s + (i + 1).ToString(), Type.Missing).EntireColumn.ColumnWidth = 30;
                            s++;
                        }
                        s = 'A';
                    }
                    for (int j = 0; j < xNodes.Count && j < 26; j++)
                    {
                        XSheet.get_Range(s + (i + 2).ToString(), Type.Missing).Value2 = xNodes[j].InnerText;
                        s++;
                    }
                }

                XWork.SaveAs(path, Excel.XlFileFormat.xlExcel12, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlShared, false, false, false);

                XSheet = null;
                XWork = null;
                xlApp.Interactive = true;
                xlApp.ScreenUpdating = true;
                xlApp.UserControl = true;
                xlApp.Quit();
                dt1 = DateTime.Now;
                TimeSpan ts = new TimeSpan();
                ts = dt1 - dt0;
                System.Diagnostics.Debug.Print(ts.ToString());
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print(ex.Message);
            }
        }*/

        //FileStream st;
        //StreamWriter sw;
        public void saveXLS3(string path, JArray data)
        {
            #region old

            //try
            //{
            //    DateTime dt0 = new DateTime();
            //    DateTime dt1 = new DateTime();
            //    dt0 = DateTime.Now;
            //    SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Create(path, SpreadsheetDocumentType.Workbook);
            //    WorkbookPart workbookpart = spreadsheetDocument.AddWorkbookPart();
            //    workbookpart.Workbook = new Workbook();
            //    WorksheetPart worksheetPart = workbookpart.AddNewPart<WorksheetPart>();
            //    worksheetPart.Worksheet = new Worksheet(new SheetData());
            //    Sheets sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild<Sheets>(new Sheets());
            //    Sheet sheet = new Sheet() { Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Отчет" };
            //    Worksheet worksheet = worksheetPart.Worksheet;
            //    SheetData sheetData = worksheet.GetFirstChild<SheetData>();
            //    Dictionary<string, object> myDic = (Dictionary<string, object>)data[0];
            //    List<string> attrs = new List<string>();
            //    for (int j = 0; j < myDic.Count; j++)
            //    {
            //        attrs.Add(myDic.ElementAt(j).Key);
            //    }
            //    Row row1 = new Row() { RowIndex = (UInt32Value)1U, Spans = new ListValue<StringValue>() { InnerText = "1:2" }, DyDescent = 0.25D };
            //    Cell cell;
            //    for (int j = 0; j < attrs.Count; j++)
            //    {
            //        cell = new Cell()
            //        {
            //            CellReference = GetExcelColumnName(j + 1) + "1",
            //            DataType = CellValues.String,
            //            CellValue = new CellValue(aliasDicAr[attrs[j]])
            //        };
            //        row1.Append(cell);
            //    }
            //    sheetData.Append(row1);
            //    Row row2;
            //    for (int i = 0; i < data.Length; i++)
            //    {
            //        myDic = (Dictionary<string, object>)data[i];
            //        row2 = new Row() { RowIndex = (UInt32Value)(i + 2U), Spans = new ListValue<StringValue>() { InnerText = "1:2" }, DyDescent = 0.25D };
            //        for (int j = 0; j < attrs.Count; j++)
            //        {
            //            if (myDic.ElementAt(j).Value != null)
            //                cell = new Cell()
            //                {
            //                    CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
            //                    DataType = CellValues.String,
            //                    CellValue = new CellValue(myDic.ElementAt(j).Value.ToString())
            //                };
            //            else
            //                cell = new Cell()
            //                {
            //                    CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
            //                    DataType = CellValues.String,
            //                    CellValue = new CellValue("")
            //                };
            //            row2.Append(cell);
            //        }
            //        sheetData.Append(row2);
            //    }
            //    sheets.Append(sheet);
            //    workbookpart.Workbook.Save();
            //    spreadsheetDocument.Close();
            //    dt1 = DateTime.Now;
            //    TimeSpan ts = new TimeSpan();
            //    ts = dt1 - dt0;
            //    System.Diagnostics.Debug.Print(ts.ToString());
            //}
            //catch (Exception ex)
            //{
            //    System.Diagnostics.Debug.Print(ex.Message);
            //}
            #endregion

            try
            {
                DateTime dt0 = new DateTime();
                DateTime dt1 = new DateTime();
                dt0 = DateTime.Now;
                SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Create(path, SpreadsheetDocumentType.Workbook);
                WorkbookPart workbookpart = spreadsheetDocument.AddWorkbookPart();
                workbookpart.Workbook = new Workbook();
                WorksheetPart worksheetPart = workbookpart.AddNewPart<WorksheetPart>();
                worksheetPart.Worksheet = new Worksheet(new SheetData());
                Sheets sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild<Sheets>(new Sheets());
                Sheet sheet = new Sheet() { Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Отчет" };
                Worksheet worksheet = worksheetPart.Worksheet;
                SheetData sheetData = worksheet.GetFirstChild<SheetData>();
                JObject jo = (JObject)data[0];
                SRow row1 = new SRow() { RowIndex = (UInt32Value)1U, Spans = new ListValue<StringValue>() { InnerText = "1:2" }, DyDescent = 0.25D };
                DocumentFormat.OpenXml.Spreadsheet.Cell cell;
                List<string> attrs = new List<string>();
                int p = 0;

                foreach (Dictionary<string, object> el in aliasDicAr)
                {

                    cell = new DocumentFormat.OpenXml.Spreadsheet.Cell()
                    {
                        CellReference = GetExcelColumnName(p + 1) + "1",
                        DataType = CellValues.String,
                        CellValue = new CellValue((string)aliasDicAr[p]["name"])
                    };

                    row1.Append(cell);
                    p++;
                }

                //SRow row1 = new SRow() { RowIndex = (UInt32Value)1U, Spans = new ListValue<StringValue>() { InnerText = "1:2" }, DyDescent = 0.25D };
                //DocumentFormat.OpenXml.Spreadsheet.Cell cell;

                sheetData.Append(row1);

                SRow row2;
                for (int i = 0; i < data.Count; i++)
                {
                    jo = (JObject)data[i];
                    row2 = new SRow() { RowIndex = (UInt32Value)(i + 2U), Spans = new ListValue<StringValue>() { InnerText = "1:2" }, DyDescent = 0.25D };
                    int j = 0;
                    while (j < aliasDicAr.Count)
                    {
                        string fieldName = (string)aliasDicAr[j]["name"];
                        double o;
                        JToken jt = jo[(string)aliasDicAr[j]["alias"]];
                        if (jt != null && jt.ToString() != "")
                        {
                            if ((fieldName.IndexOf("Дата") > -1 || fieldName.IndexOf("Срок") > -1 || fieldName.IndexOf("Год") > -1) && long.Parse(jt.ToString()) > 10000000)
                                cell = new DocumentFormat.OpenXml.Spreadsheet.Cell()
                                {
                                    CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
                                    DataType = new EnumValue<CellValues>(CellValues.String),
                                    CellValue = new CellValue(DateTime.MinValue.AddMilliseconds(long.Parse(jt.ToString())).AddYears(1969).ToString("dd.MM.yyyy"))
                                };
                            else if ((fieldName.IndexOf("Дата") > -1 || fieldName.IndexOf("Срок") > -1 || fieldName.IndexOf("Год") > -1) && long.Parse(jt.ToString()) < -10000000)
                            {
                                long subm = Math.Abs(long.Parse(jt.ToString()));
                                TimeSpan tims = TimeSpan.FromMilliseconds(subm);
                                DateTime sdatetm = DateTime.MinValue.AddYears(1969).Subtract(tims);
                                cell = new DocumentFormat.OpenXml.Spreadsheet.Cell()
                                {
                                    CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
                                    DataType = new EnumValue<CellValues>(CellValues.String),
                                    CellValue = new CellValue(sdatetm.ToString("dd.MM.yyyy"))
                                };
                            }
                            else
                            {
                                string num = jt.ToString().Replace('.', ',');
                                int dotIndex = num.IndexOf(',');
                                int dotLast = num.LastIndexOf(',');

                                if (dotIndex == dotLast && Double.TryParse(num, out o))
                                    cell = new DocumentFormat.OpenXml.Spreadsheet.Cell()
                                    {
                                        CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
                                        DataType = new EnumValue<CellValues>(CellValues.Number),
                                        CellValue = new CellValue(o.ToString().Replace(',', '.'))
                                    };
                                else
                                    cell = new DocumentFormat.OpenXml.Spreadsheet.Cell()
                                    {
                                        CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(),
                                        DataType = new EnumValue<CellValues>(CellValues.String),
                                        CellValue = new CellValue(jt.ToString())
                                    };
                            }
                        }
                        else
                            cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellReference = GetExcelColumnName(j + 1) + (i + 2).ToString(), DataType = CellValues.String, CellValue = new CellValue("") };
                        row2.Append(cell);

                        j++;
                    }
                    sheetData.Append(row2);
                }

                sheets.Append(sheet);
                workbookpart.Workbook.Save();
                spreadsheetDocument.Close();
                dt1 = DateTime.Now;
                System.Diagnostics.Debug.Print("Файл успешно сгенерирован:" + dt1.ToLongTimeString());

                TimeSpan ts = new TimeSpan();
                ts = dt1 - dt0;
                System.Diagnostics.Debug.Print(ts.ToString());
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print(ex.Message);
            }
        }

        private static string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }

        public static ByteArray BytesToByteArray(byte[] bytes)
        {
            var ms1 = new MemoryStream(bytes);
            return new ByteArray(ms1);
        }

        public static byte[] ByteArrayToBytes(ByteArray byteArray)
        {
            uint length = byteArray.Length;
            byte[] bytes = new byte[length];
            byteArray.ReadBytes(bytes, 0, length);
            return bytes;
        }
        #endregion
        
    }
}
