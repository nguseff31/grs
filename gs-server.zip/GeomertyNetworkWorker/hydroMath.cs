﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeomertyNetworkWorker.hydroMath
{
    /// <summary>
    ///
    /// </summary>
    /// <typeparam name="V">Тип вершин</typeparam>
    /// <typeparam name="E">Тип рёбер</typeparam>
    public class Graph<V,E>
    {
        Dictionary<V,HashSet<Edge<V,E>>> g;
        public bool bidirectional;

        public IEnumerable<V> vertexes
        {
            get
            {
                foreach (V key in g.Keys)
                {
                    yield return key;
                }
            }
        }
        public Graph(bool bidirectional = true)
        {
            g = new Dictionary<V,HashSet<Edge<V,E>>>();
            this.bidirectional = bidirectional;
        }

        public void addVertex(V v) {
            g.Add(v, new HashSet<Edge<V,E>>());
        }
        public void addVertexCollection(IEnumerable<V> vertexCollection)
        {
            foreach (V v in vertexCollection)
            {
                if (!g.ContainsKey(v))
                    g.Add(v, new HashSet<Edge<V, E>>());
            }
        }
        public void removeVertex(V v)
        {
            List<Edge<V,E>> edgesToRemove = new List<Edge<V,E>>();

            foreach (Edge<V, E> e in g[v])
            {
                edgesToRemove.Add(e);
            }
            foreach (Edge<V, E> e in edgesToRemove)
            {
                this.removeEdge(e.from, e.to);
                if (this.bidirectional)
                    this.removeEdge(e.to, e.from);
            }
            g.Remove(v);
        }
        public void removeEdge(V from, V to)
        {
            g[from].RemoveWhere((v) => {
                return v.to.Equals(to);
            });
            if (this.bidirectional)
            {
                g[to].RemoveWhere((v) => {
                    return v.to.Equals(from);
                });
            }
        }
        public bool containsVertex(V v)
        {
            return g.ContainsKey(v);
        }

        public void addEdge(V from, V to, E e) 
        {
            Edge<V,E> edge1 = new Edge<V,E>() {
                from = from,
                to = to,
                e = e
            };
            g[from].Add(edge1);
            if(this.bidirectional) {
                Edge<V, E> edge2 = new Edge<V, E>()
                {
                    from = to,
                    to = from,
                    e = e
                };
                g[to].Add(edge2);
            }
        }
        public bool containsEdge(Edge<V,E> edge)
        {
            if (!g.ContainsKey(edge.from))
                return false;
            foreach (Edge<V, E> e in g[edge.from])
                if (e.to.Equals(edge.to))
                    return true;
            return false;
        }
        public bool hasEdge(V from, V to)
        {
            if (!g.ContainsKey(from))
                return false;
            foreach (Edge<V, E> e in g[from])
                if (e.to.Equals(to))
                    return true;
            return false;
        }

        public Edge<V, E> getEdge(V from, V to)
        {
            foreach (Edge<V, E> e in g[from])
            {
                if (e.to.Equals(to))
                    return e;
            }
            throw new KeyNotFoundException(String.Format("Edge {0} -> {1} does not exist", from, to));
        }

        public bool TryGetEdge(V from, V to, out Edge<V,E> edge) {
            edge = new Edge<V, E>();

            if (!g.ContainsKey(from))
                return false;
            foreach (Edge<V, E> e in g[from])
            {
                if (e.to.Equals(to))
                {
                    edge = e;
                    return true;
                }
            }
            return false;
        }
        public HashSet<Edge<V, E>> edgesOf(V from)
        {
            return g[from];
        }
        public IEnumerable<V> siblingsOf(V from)
        {
            foreach(Edge<V,E> edge in g[from]) {
                yield return edge.to;
            }
        }
    }
    /// <summary>
    /// Класс ребра графа
    /// </summary>
    /// <typeparam name="V">Тип вершин</typeparam>
    /// <typeparam name="E">Тип рёбер</typeparam>
    public struct Edge<V, E>
    {
        public V from;
        public V to;
        public E e;

        public override int GetHashCode()
        {
 	         return (from.GetHashCode() + "_" + to.GetHashCode()).GetHashCode();
        }
    }
}
