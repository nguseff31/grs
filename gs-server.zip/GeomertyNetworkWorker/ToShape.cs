﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.DataSourcesFile;
using System.Runtime.InteropServices;
using System.IO.Compression;
using ICSharpCode.SharpZipLib.Checksums;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using Newtonsoft.Json;

namespace GeomertyNetworkWorker
{
    public class ToShape
    {

        public static IField createField(string name, string alias, bool isText = true)
        {
            // Create the text field.
            IField field = new FieldClass();

            if (isText)
            {
                IFieldEdit textFieldEdit = (IFieldEdit)field;
                textFieldEdit.Length_2 = 100;
                textFieldEdit.Type_2 = esriFieldType.esriFieldTypeString;
                textFieldEdit.AliasName_2 = alias;
                textFieldEdit.Name_2 = name;
                return field;
            }
            else
            {
                IFieldEdit numberFieldEdit = (IFieldEdit)field;
                numberFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble;
                numberFieldEdit.AliasName_2 = alias;
                numberFieldEdit.Name_2 = name;
                return field;
            }
        }

        public static void SaveToShapeFile(string objects, string filePath, string fileName)
        {
            var list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(objects);

            IWorkspaceFactory workspaceFactory = new ShapefileWorkspaceFactory();

            IWorkspaceName workspaceName = workspaceFactory.Create(filePath, fileName, null, 0);
            IName name = (IName)workspaceName;
            IWorkspace workspace = (IWorkspace)name.Open();
            IFeatureWorkspace workspaceW = (IFeatureWorkspace)(workspace);

            //Точки
            IFields fieldsPoints = new FieldsClass();
            IFieldsEdit fieldsEdit = (IFieldsEdit)fieldsPoints;
            IField oidField = new FieldClass();
            IGeometryDef geometryDef = new GeometryDefClass();
            IGeometryDefEdit geometryDefEdit = (IGeometryDefEdit)geometryDef;
            geometryDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
            IField geometryField = new FieldClass();
            IFieldEdit geometryFieldEdit = (IFieldEdit)geometryField;
            geometryFieldEdit.Name_2 = "Shape";
            geometryFieldEdit.Type_2 = esriFieldType.esriFieldTypeGeometry;
            geometryFieldEdit.GeometryDef_2 = geometryDef;
            fieldsEdit.AddField(geometryField);

            fieldsEdit.AddField(createField("classidstr", "Тип узла"));            
            fieldsEdit.AddField(createField("name", "Название узла"));
            fieldsEdit.AddField(createField("status", "Статус узла"));
            fieldsEdit.AddField(createField("enabled", "Статус задвижки"));
            fieldsEdit.AddField(createField("P", "Давление на узле", false));
            fieldsEdit.AddField(createField("q", "Потребление на узле", false));

            //Линии
            IFields fieldsLines = new FieldsClass();
            IFieldsEdit fieldsEditLines = (IFieldsEdit)fieldsLines;
            IField oidFieldLines = new FieldClass();
            IGeometryDef geometryDefLines = new GeometryDefClass();
            IGeometryDefEdit geometryDefEditLines = (IGeometryDefEdit)geometryDefLines;
            geometryDefEditLines.GeometryType_2 = esriGeometryType.esriGeometryPolyline;
            IField geometryFieldLines = new FieldClass();
            IFieldEdit geometryFieldEditLines = (IFieldEdit)geometryFieldLines;
            geometryFieldEditLines.Name_2 = "Shape";
            geometryFieldEditLines.Type_2 = esriFieldType.esriFieldTypeGeometry;
            geometryFieldEditLines.GeometryDef_2 = geometryDefLines;
            fieldsEditLines.AddField(geometryFieldLines);

            fieldsEditLines.AddField(createField("nametruba", "Название газопровода"));
            fieldsEditLines.AddField(createField("status", "Статус газопровода"));
            fieldsEditLines.AddField(createField("gost", "Гост"));
            fieldsEditLines.AddField(createField("material", "Материал газопровода"));
            fieldsEditLines.AddField(createField("V", "Скорость потока", false));
            fieldsEditLines.AddField(createField("pf", "Давление газопровода фактическое", false));
            fieldsEditLines.AddField(createField("l", "Длина газопровода", false));
            fieldsEditLines.AddField(createField("d", "Диаметр газопровода", false));
            fieldsEditLines.AddField(createField("qf", "Поток газа", false));

            ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
            ISpatialReference spatialReference = spatialReferenceFactory.CreateProjectedCoordinateSystem(28410);
            geometryDefEdit.SpatialReference_2 = spatialReference;
            IFeatureClass featureClassPoints = workspaceW.CreateFeatureClass("Points", fieldsPoints, null, null, esriFeatureType.esriFTSimple, "Shape", "");

            ISpatialReferenceFactory spatialReferenceFactoryLines = new SpatialReferenceEnvironmentClass();
            ISpatialReference spatialReferenceLines = spatialReferenceFactoryLines.CreateProjectedCoordinateSystem(28410);
            geometryDefEditLines.SpatialReference_2 = spatialReferenceLines;
            IFeatureClass featureClassLines = workspaceW.CreateFeatureClass("Lines", fieldsLines, null, null, esriFeatureType.esriFTSimple, "Shape", "");

            IWorkspaceEdit workspaceEdit = (IWorkspaceEdit)workspace;
            workspaceEdit.StartEditing(false);
            workspaceEdit.StartEditOperation();

            foreach (Dictionary<string, string> point in list)
            {
                double val = 0;

                IFeature featureT = featureClassPoints.CreateFeature();
                IPoint pointt = new PointClass();
                if (point.ContainsKey("x") && Double.TryParse(point["x"].Replace('.', ','), out val))
                    pointt.X = val;
                if (point.ContainsKey("y") && Double.TryParse(point["y"].Replace('.', ','), out val))
                    pointt.Y = val;

                if (point.ContainsKey("classidstr"))
                    featureT.set_Value(featureClassPoints.FindField("classidstr"), point["classidstr"].ToString());
                if (point.ContainsKey("name"))
                    featureT.set_Value(featureClassPoints.FindField("name"), point["name"].ToString());
                if (point.ContainsKey("status"))
                    featureT.set_Value(featureClassPoints.FindField("status"), point["status"].ToString());
                if (point.ContainsKey("enabled"))
                    featureT.set_Value(featureClassPoints.FindField("enabled"), point["enabled"].ToString());
                if (point.ContainsKey("P") && Double.TryParse(point["P"].Replace('.', ','), out val))
                    featureT.set_Value(featureClassPoints.FindField("P"), val);
                if (point.ContainsKey("q") && Double.TryParse(point["q"].Replace('.', ','), out val))
                    featureT.set_Value(featureClassPoints.FindField("q"), val);

                featureT.Shape = pointt;
                featureT.Store();                

                foreach (Dictionary<string, string> point2 in list)
                {
                    if (point["parenteid"].ToString() == point2["eid"].ToString())
                    {
                        IFeature featureL = featureClassLines.CreateFeature();
                        IPolyline linee = new PolylineClass();                        

                        IPoint pointl = new PointClass();
                        if (point2.ContainsKey("x") && Double.TryParse(point2["x"].Replace('.', ','), out val))
                            pointl.X = val;
                        if (point2.ContainsKey("y") && Double.TryParse(point2["y"].Replace('.', ','), out val))
                            pointl.Y = val;

                        linee.FromPoint = pointl;
                        linee.ToPoint = pointt;

                        if (point.ContainsKey("nametruba"))
                            featureL.set_Value(featureClassLines.FindField("nametruba"), point["nametruba"].ToString());
                        if (point.ContainsKey("statustruba"))
                            featureL.set_Value(featureClassLines.FindField("status"), point["statustruba"].ToString());
                        if (point.ContainsKey("gost"))
                            featureL.set_Value(featureClassLines.FindField("gost"), point["gost"].ToString());
                        if (point.ContainsKey("material"))
                            featureL.set_Value(featureClassLines.FindField("material"), point["material"].ToString());
                        if (point.ContainsKey("V") && Double.TryParse(point["V"].Replace('.', ','), out val))
                            featureL.set_Value(featureClassLines.FindField("V"), val);
                        if (point.ContainsKey("pf") && Double.TryParse(point["pf"].Replace('.', ','), out val))
                            featureL.set_Value(featureClassLines.FindField("pf"), val);
                        if (point.ContainsKey("l") && Double.TryParse(point["l"].Replace('.', ','), out val))
                            featureL.set_Value(featureClassLines.FindField("l"), val);
                        if (point.ContainsKey("d") && Double.TryParse(point["d"].Replace('.', ','), out val))
                            featureL.set_Value(featureClassLines.FindField("d"), val);
                        if (point.ContainsKey("qf") && Double.TryParse(point["qf"].Replace('.', ','), out val))
                            featureL.set_Value(featureClassLines.FindField("qf"), val);
                        
                        featureL.Shape = linee;
                        featureL.Store();

                        Marshal.ReleaseComObject(pointl);
                        Marshal.ReleaseComObject(featureL);

                        break;
                    }
                }

                Marshal.ReleaseComObject(pointt);
                Marshal.ReleaseComObject(featureT);
            }
            workspaceEdit.StopEditOperation();
            workspaceEdit.StopEditing(true);
            /*Marshal.ReleaseComObject(workspaceW);
            Marshal.ReleaseComObject(workspaceEdit);
            Marshal.ReleaseComObject(workspaceFactory);
            Marshal.ReleaseComObject(workspaceName);
            Marshal.ReleaseComObject(workspace);
            Marshal.ReleaseComObject(workspaceW);
            Marshal.ReleaseComObject(fields);
            Marshal.ReleaseComObject(fieldsEdit);
            Marshal.ReleaseComObject(oidField);
            Marshal.ReleaseComObject(geometryDef);
            Marshal.ReleaseComObject(geometryDefEdit);
            Marshal.ReleaseComObject(geometryField);
            Marshal.ReleaseComObject(geometryFieldEdit);
            Marshal.ReleaseComObject(spatialReferenceFactory);
            Marshal.ReleaseComObject(spatialReference);*/
            Marshal.ReleaseComObject(featureClassPoints);
            Marshal.ReleaseComObject(featureClassLines);
            //Архивация
            string path = System.IO.Path.Combine(filePath, fileName);
            string zipFile = System.IO.Path.Combine(path, "Network.zip");
            ZipOutputStream s = new ZipOutputStream(System.IO.File.Create(zipFile));
            s.SetLevel(9); // 0 - store only to 9 - means best compression
            s.SetComment("shape file");
            foreach (string filename in System.IO.Directory.GetFiles(path))
            {
                if (filename != zipFile)
                {
                    System.IO.FileInfo fi = new System.IO.FileInfo(filename);

                    ZipEntry newEntry = new ZipEntry(ZipEntry.CleanName(System.IO.Path.GetFileName(filename)));
                    newEntry.DateTime = fi.LastWriteTime;

                    newEntry.Size = fi.Length;

                    s.PutNextEntry(newEntry);

                    byte[] buffer = new byte[4096];
                    using (System.IO.FileStream streamReader = System.IO.File.OpenRead(filename))
                    {
                        StreamUtils.Copy(streamReader, s, buffer);
                    }
                    s.CloseEntry();

                    System.IO.File.Delete(filename);
                }
            }
            s.IsStreamOwner = true;
            s.Close();
            s.Dispose();
        }
    }
}