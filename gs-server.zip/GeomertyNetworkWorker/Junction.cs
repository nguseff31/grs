﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace GeomertyNetworkWorker
{
    public class Junction
    {        
        [XmlElement("eid")]
        public int EID
        {
            get { return _eid; }
            set {_eid = value;}
        }

        [XmlElement("parentedgeeid")]
        public int ParentEdgeEID
        {
            get { return _parentEdgeEID; }
            set { _parentEdgeEID = value; }
        }

        [XmlElement("classid")]
        public int ClassID
        {
            get { return _classID; }
            set { _classID = value; }
        }

        [XmlElement("parenteid")]
        public int ParentEID
        {
            get { return _parentEID; }
            set { _parentEID = value; }
        }

        [XmlElement("numedges")]
        public int NumEdges
        {
            get { return _numEdges; }
            set { _numEdges = value; }
        }

        [XmlElement("numchildjunctions")]
        public int NumChildJunctions
        {
            get { return _numChildJunctions; }
            set { _numChildJunctions = value; }
        }

        [XmlElement("d")]
        public double D
        {
            get { return _diameter; }
            set { _diameter = value; }
        }

        [XmlElement("q")]
        public double Q
        {
            get { return _consumption; }
            set { _consumption = value; }
        }

        [XmlElement("qf")]
        public double QF
        {
            get { return _qfact; }
            set { _qfact = value; }
        }

        [XmlElement("l")]
        public double L
        {
            get { return _len; }
            set { _len = value; }
        }

        [XmlElement("pf")]
        public double PF
        {
            get { return _pf; }
            set { _pf = value; }
        }

        [XmlElement("gost")]
        public string GOST
        {
            get { return _gost; }
            set { _gost = value; }
        }

        [XmlElement("material")]
        public string Material
        {
            get { return _material; }
            set { _material = value; }
        }

        [XmlElement("name")]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        [XmlElement("nametruba")]
        public string Nametruba
        {
            get { return _nametruba; }
            set { _nametruba = value; }
        }

        [XmlElement("status")]
        public string status
        {
            get { return _status; }
            set { _status = value; }
        }

        [XmlElement("statustruba")]
        public string statustruba
        {
            get { return _statustruba; }
            set { _statustruba = value; }
        }

        [XmlElement("x")]
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }

        [XmlElement("y")]
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }

        [XmlElement("type")]
        public string ttype
        {
            get { return _ttype; }
            set { _ttype = value; }
        }

        public Junction()
        {
        }
        public Junction(int eid)
        {
            _eid = eid;
        }
        public Junction(int EID, int parentEdgeEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
        }
        public Junction(int EID, int parentEdgeEID, int classID, int parentEID, int numEdges, double d, double q, string gost, string material, double x, double y, double len, string name, string nametruba, double qf, string status, string statustruba, double pf, string ttype)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
            _numEdges = numEdges;
            if (numEdges > 0)
            {
                _numChildJunctions = numEdges - 1;
            }
            _diameter = d;
            _consumption = q;
            _qfact = qf;
            _gost = gost;
            _material = material;
            _x = x;
            _y = y;
            _len = len;
            _name = name;
            _nametruba = nametruba;
            _status = status;
            _statustruba = statustruba;
            _pf = pf;
            _ttype = ttype;
        }

        private int _eid = 0;
        private int _parentEdgeEID = 0;
        private int _classID = 0;
        private int _parentEID = 0;
        private int _numEdges = 0;
        private int _numChildJunctions = 0;
        private double _diameter = 0;
        private double _consumption = 0;
        private double _qfact = 0;
        private double _len = 0;
        private double _pf = 0;
        private string _gost = "";
        private string _material = "";
        private double _x = 0;
        private double _y = 0;
        private string _name = "";
        private string _nametruba = "";
        private string _status = "";
        private string _statustruba = "";
        private string _ttype = "";
    }
}
