﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;

using System.IO;

using System.Collections;

namespace GeomertyNetworkWorker
{

    public static class symbols_icons
    {
        public static string icon_break = @"~\Symbols\icons\break";
        public static string icon_valve = @"~\Symbols\icons\valve";
        public static string symbols_path = @"~\Symbols";
    }

    

    public class symbols
    {
        //HttpServerUtility Server;
        WebService SServer = new WebService();
        

        public string getSettings()
        {
            string xmlResult = "<symbols></symbols>";
            
           

            //string SymbolSettingPath = Server.MapPath("~\\Symbols");
            string SymbolSettingPath = SServer.Server.MapPath(symbols_icons.symbols_path);
            //string userName = User.Identity.Name;
            var dir = new DirectoryInfo(SymbolSettingPath);
            try
            {
                foreach (FileInfo file in dir.GetFiles())
                {
                    if ("symbolssetting" == Path.GetFileNameWithoutExtension(file.FullName).ToLower())
                    {
                        xmlResult = File.ReadAllText(file.FullName);
                        break;
                    }
                }
            }
            catch (IOException ex)
            {
                Directory.CreateDirectory(SymbolSettingPath);
            }
            if (!String.IsNullOrEmpty(xmlResult))
            {
                if (xmlResult.StartsWith("<symbols>") && xmlResult.EndsWith("</symbols>"))
                {
                    //return xmlResult;
                    return xmlResult;
                }
                else
                {
                    return "<symbols></symbols>";
                }
            }
            else
            {
                return "<symbols></symbols>";
            }
        }

        public string[] getListOfBreaks()
        {
            string SymbolSettingPath = SServer.Server.MapPath(symbols_icons.icon_break);
            var dir = new DirectoryInfo(SymbolSettingPath);
            ArrayList arrResult = new ArrayList();
            
            try
            {
                foreach (FileInfo file in dir.GetFiles())
                {
                    arrResult.Add(file.Name);
                    //arrResult.Add(file.FullName);
                    //Result = File.ReadAllText(file.Name);
                }
            }
            catch (IOException ex)
            {
                //Directory.CreateDirectory(SymbolSettingPath);
            }
            return (String[])arrResult.ToArray(typeof(string));
        }

        public string[] getListOfValves()
        {
            
            
            string SymbolSettingPath = SServer.Server.MapPath(symbols_icons.icon_valve);
            var dir = new DirectoryInfo(SymbolSettingPath);
            ArrayList arrResult = new ArrayList();

            try
            {
                foreach (FileInfo file in dir.GetFiles())
                {
                    arrResult.Add(file.Name);
                    //arrResult.Add(file.FullName);
                    //Result = File.ReadAllText(file.Name);
                }
            }
            catch (IOException ex)
            {
                //Directory.CreateDirectory(SymbolSettingPath);
            }
            return (String[])arrResult.ToArray(typeof(string));
        }

        public void saveSettings(string xmlResult)
        {
            if (!String.IsNullOrEmpty(xmlResult))
                if (xmlResult.StartsWith("<symbols>") && xmlResult.EndsWith("</symbols>"))
                {
                    //string userName = User.Identity.Name;
                    //string[] tmpName = userName.Split('\\');
                    //userName = tmpName[tmpName.Length - 1];
                    string sSettingsPath = SServer.Server.MapPath(symbols_icons.symbols_path);

                    File.WriteAllText(Path.Combine(sSettingsPath, Path.ChangeExtension("symbolssetting", "txt")), xmlResult);
                }
        }
    }
}
