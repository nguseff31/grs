﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

namespace GeomertyNetworkWorker
{
    [XmlRoot("junctions")]
    public class CommonJunctions
    {
        [XmlArray("junctionslist")]
        public List<CommonJunction> junctions { get; set; }

        [XmlElement("count")]
        public int Count
        {
            get { return junctions.Count; }
        }

        public CommonJunctions()
        {
            junctions = new List<CommonJunction>();
        }

        public CommonJunctions(int eid) : this()
        {
            Add(eid);
        }

        public CommonJunctions(CommonJunction junction) : this()
        {
            junctions.Add(junction);
        }

        public CommonJunction Add(int eid)
        {
            return Add(new CommonJunction(eid));
        }

        public CommonJunction Add(int eid, int parentEdgeEID)
        {
            return Add(new CommonJunction(eid, parentEdgeEID));
        }

        public CommonJunction Add(int eid, int ClassID, string Str)
        {
            return Add(new CommonJunction(eid,ClassID,Str));
        }

        public CommonJunction Add(int eid, int parentEdgeEID, int classID, int parentEID)
        {
            return Add(new CommonJunction(eid, parentEdgeEID, classID, parentEID));
        }

        public CommonJunction Add(int eid, int parentEdgeEID, int classID, int parentEID, int numOfArms)
        {
            return Add(new CommonJunction(eid, parentEdgeEID, classID, parentEID, numOfArms));
        }

        public CommonJunction Add(CommonJunction junction)
        {
            junctions.Add(junction);
            return junction;
        }

        public CommonJunction Add(int EID, int ClassID, string Str, int ValveEID, string ValveStr)
        {
            return Add(new CommonJunction(EID, ClassID, Str, ValveEID, ValveStr));
        }

        #region Implementation of IEnumerable
        public System.Collections.IEnumerator GetEnumerator()
        {
            return junctions.GetEnumerator();
        }
        #endregion

        public string getXML()
        {
            MemoryStream stream = new MemoryStream();
            XmlSerializer arr = new XmlSerializer(typeof(CommonJunctions));
            arr.Serialize(stream, this);
            byte[] buffer = stream.GetBuffer();
            stream.Close();
            UTF8Encoding encoding = new UTF8Encoding();
            string s = encoding.GetString(buffer);

            var xml = new XmlDocument();
            xml.LoadXml(s);
            s = Newtonsoft.Json.JsonConvert.SerializeObject(xml);

            UTF8Encoding encoder = new UTF8Encoding();
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            string utf8ReturnString = encoder.GetString(bytes);

            return utf8ReturnString;
        }

        public void SerializeToXML(String path)
        {
            using (StreamWriter w = new StreamWriter(path))
            {
                XmlSerializer s = new XmlSerializer(this.GetType());
                s.Serialize(w, this);
                w.Close();
            }
        }

        public void DeserializeFromXML(String path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                XmlTextReader xr = new XmlTextReader(sr);
                XmlSerializer xs = new XmlSerializer(this.GetType());
                object c;
                if (xs.CanDeserialize(xr))
                {
                    c = xs.Deserialize(xr);
                    Type t = this.GetType();
                    PropertyInfo[] properties = t.GetProperties();
                    foreach (PropertyInfo p in properties)
                    {
                        p.SetValue(this, p.GetValue(c, null), null);
                    }
                }
                xr.Close();
                sr.Close();
                File.Delete(path);
            }
        }
    }
}
