﻿using System;
using System.Diagnostics;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;

namespace GeomertyNetworkWorker
{
    public class SecondaryTracerAbon
    {
        protected IUtilityNetwork utilityNetwork;
        private IForwardStar forwardStar;
        private CommonJunctions abonentJunctions;
        private CommonJunctions tempJunctions;
        private CommonJunctions junctionJunctions;
        private CommonJunctions newJunctions;
        private CommonJunctions allJunctions;


        private CommonJunctions edgejunctions;

        private int consumerClassID;
        private int subscriberClassID;
        private int armaturaClassID;
        private int junctionClassID;
        private int grsClassID;
        private int[] armEIDs;
        private int armSize;

        public CommonJunctions AbonentJunctions
        {
            get { return abonentJunctions; }
        }
        public CommonJunctions JunctionJunctions
        {
            get { return junctionJunctions; }
        }
        public CommonJunctions AllJunctions
        {
            get { return allJunctions; }
        }
        public CommonJunctions TempJunctions
        {
            get { return tempJunctions; }
        }
        public IUtilityNetwork UtilityNetwork
        {
            get { return utilityNetwork; }
        }

        public SecondaryTracerAbon()
        {
        }

        public SecondaryTracerAbon(int armaturaClassID, int consumerClassID, int subscriberClassID, int junctionClassID, int grsClassID, ref IGeometricNetwork geomNet)
        {
            this.consumerClassID = consumerClassID;
            this.subscriberClassID = subscriberClassID;
            this.junctionClassID = junctionClassID;
            this.armaturaClassID = armaturaClassID;
            this.grsClassID = grsClassID;

            abonentJunctions = new CommonJunctions();
            tempJunctions = new CommonJunctions();
            junctionJunctions = new CommonJunctions();
            newJunctions = new CommonJunctions();
            allJunctions = new CommonJunctions();
            edgejunctions = new CommonJunctions();

            armEIDs = new int[10];

            //init utility network          
            utilityNetwork = geomNet.Network as IUtilityNetwork;
            if (utilityNetwork == null)
                throw (new InvalidCastException("Network не utility network"));
        }

        public void BeginTrace(int[] armEids, int SizeOfMassive)
        {
            CommonJunction topJuntion = new CommonJunction(armEids[0]);
            forwardStar = utilityNetwork.CreateForwardStar(true, null, null, null, null);
            TraceSecondaryFirst(topJuntion, AllJunctions);
            armEIDs = armEids;
            armSize = SizeOfMassive;

            foreach (CommonJunction junction in AllJunctions)
            {
                if (junction.ClassID > 2 && junction.ClassID < 6)
                    TempJunctions.Add(junction);
                junctionJunctions.junctions.Clear();
                junctionJunctions.Add(junction);
                TraceSecondary();
                bool isHaveGRS = false;
                foreach (CommonJunction tmp in TempJunctions)
                {
                    if (tmp.ClassID == 5) isHaveGRS = true;
                }
                if (!isHaveGRS)
                    AbonentJunctions.junctions.AddRange(TempJunctions.junctions);
                TempJunctions.junctions.Clear();
            }
        }

        public void TraceSecondaryFirst(CommonJunction junction, CommonJunctions newJunctions)
        {
            int numEdges;
            forwardStar.FindAdjacent(0, junction.EID, out numEdges);
            for (int i = 0; i < numEdges; i++)
            {
                int junctionEID;        object netWt;
                forwardStar.QueryAdjacentJunction(i, out junctionEID, out netWt);

                int edgeEID;        bool revOrientation;
                forwardStar.QueryAdjacentEdge(i, out edgeEID, out revOrientation, out netWt);

                if (IsTraceableEdge(edgeEID, junction, junctionEID))
                {
                    int childJuncClassID = GetClassID(junctionEID);

                    if (childJuncClassID == junctionClassID)
                        newJunctions.Add(junctionEID, edgeEID, 1, junction.EID);

                    if (childJuncClassID == armaturaClassID)
                        newJunctions.Add(junctionEID, edgeEID, 2, junction.EID);

                    if (childJuncClassID == consumerClassID)
                        newJunctions.Add(junctionEID, edgeEID, 3, junction.EID);

                    if (childJuncClassID == subscriberClassID)
                        newJunctions.Add(junctionEID, edgeEID, 4, junction.EID);

                    if (childJuncClassID == grsClassID)
                        newJunctions.Add(junctionEID, edgeEID, 5, junction.EID);
                }
            }
        }

        private void TraceSecondary()
        {
            while (junctionJunctions.Count > 0)
            {
                //if (junctionJunctions.Count > 20)
                  //  return;
                foreach (CommonJunction junction in junctionJunctions)
                {
                    TraceSecondary(junction);
                }
                junctionJunctions.junctions.Clear();
                if (newJunctions.Count > 0)
                {
                    junctionJunctions.junctions.AddRange(newJunctions.junctions);
                    
                }
                newJunctions.junctions.Clear();
            }
        }

        private void TraceSecondary(CommonJunction junction)
        {
            int numEdges;
            forwardStar.FindAdjacent(0, junction.EID, out numEdges);            
            for (int i = 0; i < numEdges; i++)
            {
                int junctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out junctionEID, out netWt);

                int edgeEID; bool revOrientation;
                forwardStar.QueryAdjacentEdge(i, out edgeEID, out revOrientation, out netWt);
                if (edgeEID != null)
                {
                    edgejunctions.Add(edgeEID);
                }
                if (IsTraceableEdge(edgeEID, junction, junctionEID) && !isHaveEID(junctionEID) && !isHaveEID(edgeEID))
                {
                    int childJuncClassID = GetClassID(junctionEID);

                    if (childJuncClassID == junctionClassID)
                        newJunctions.Add(junctionEID, edgeEID, 1, junction.EID);

                    if (childJuncClassID == armaturaClassID)
                    {
                        bool isBlockedArm = false;
                        for (int j = 0; j < armSize; j++)
                        {
                            if (armEIDs[j] == junctionEID)
                                isBlockedArm = true;
                        }
                        if (!isBlockedArm)
                            newJunctions.Add(junctionEID, edgeEID, 2, junction.EID);
                    }

                    if (childJuncClassID == consumerClassID)
                    {
                            newJunctions.Add(junctionEID, edgeEID, 3, junction.EID);
                            TempJunctions.Add(junctionEID, edgeEID, 3, junction.EID);
                    }
                    if (childJuncClassID == subscriberClassID)
                    {
                            newJunctions.Add(junctionEID, edgeEID, 4, junction.EID);
                            TempJunctions.Add(junctionEID, edgeEID, 4, junction.EID);
                    }
                    if (childJuncClassID == grsClassID)
                    {
                            newJunctions.Add(junctionEID, edgeEID, 5, junction.EID);
                            TempJunctions.Add(junctionEID, edgeEID, 5, junction.EID);
                    }
                }
            }
        }

        private bool IsTraceableEdge(int edgeEID, CommonJunction junction, int junctionEID)
        {
            if (edgeEID == junction.ParentEdgeEID)
                return false;

            if (edgeEID == 0)
                return false;

            if (junctionEID == 0)
                return false;

            return true;
        }

        private bool isHaveEID(int EID)
        {
            for (int i = 0; i < newJunctions.junctions.Count; i++)
            {
                if (newJunctions.junctions[i].EID == EID)
                    return true;
            }
            for (int j = 0; j < junctionJunctions.junctions.Count; j++)
            {
                if (junctionJunctions.junctions[j].EID == EID)
                    return true;
            }
            return false;
        }

        private bool isEID(int EID)
        {
            for (int i = 0; i < edgejunctions.junctions.Count; i++)
            {
                if (edgejunctions.junctions[i].ClassID == EID)
                {
                    return true;
                }
            }
            return false;
        }

        private int GetClassID(int eid)
        {
            try
            {
                INetElements netElements = (INetElements)utilityNetwork;
                int classID; int userID; int userSubID;
                netElements.QueryIDs(eid, esriElementType.esriETJunction, out classID, out userID, out userSubID);
                return classID;
            }
            catch (Exception e)
            {
                Trace.WriteLine(e.ToString());
                return -1;
            }
        }

        public static int ClassIDFromName(string featureClassName, IWorkspace mapWksp)
        {
            string name = featureClassName;
            int periodIndex = name.IndexOf(".", 0);
            if (periodIndex != -1)
            {
                name = name.Substring(periodIndex + 1);
            }

            IEnumDatasetName featureDatasetNames = mapWksp.get_DatasetNames(esriDatasetType.esriDTFeatureDataset);
            IDatasetName featureDatasetName = featureDatasetNames.Next();
            while (featureDatasetName != null)
            {
                int classID = ClassIDFromName(featureDatasetName, name);
                if (classID != 0)
                {
                    Marshal.ReleaseComObject(featureDatasetNames);
                    Marshal.ReleaseComObject(featureDatasetName);
                    return classID;
                }

                featureDatasetName = featureDatasetNames.Next();
            }
            Marshal.ReleaseComObject(featureDatasetNames);
            Marshal.ReleaseComObject(featureDatasetName);
            return 0;
        }

        private static int ClassIDFromName(IDatasetName featureDatasetName, string className)
        {
            int classID = 0;
            IEnumDatasetName featureClassNames = featureDatasetName.SubsetNames;
            IDatasetName featureClassName = featureClassNames.Next();
            while (featureClassName != null)
            {
                string name = featureClassName.Name;
                int periodIndex = name.IndexOf(".", 0);
                if (periodIndex != -1)
                {
                    name = name.Substring(periodIndex + 1);
                }
                if (string.Compare(name, className, true) == 0)
                {
                    IObjectClassName objClassName = (IObjectClassName)featureClassName;
                    classID = objClassName.ObjectClassID;
                    break;
                }
                featureClassName = featureClassNames.Next();
            }
            Marshal.ReleaseComObject(featureClassNames);
            Marshal.ReleaseComObject(featureDatasetName);
            return classID;
        }


    }
}
