﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.NetworkAnalysis;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;

namespace GeomertyNetworkWorker
{
    public class GetNetworkAbon
    {
        public GetNetworkAbon()
        {
            Global.initializeLicenze();
        }
       
        private class workLayers
        {
            public const string subscriber = "subscriber";
            public const string consumer = "consumer";
            public const string gaspipeline = "gaspipeline";
            public const string grs = "grs";
            public const string stpvalve = "stpvalve";
            public const string ArmtDataSet_Net_Junctions = "ArmtDataSet_Net_Junctions";
        }

        private AbonJunctions resultAbonJuncs;
        private IFeatureClass subscriber;
        private IFeatureClass consumer;
        private IFeatureClass gaspipeline;
        private IFeatureClass grs;
        private IFeatureClass stpvalve;
        private IFeatureClass ArmtDataSet_Net_Junctions;
        //private IUtilityNetwork utilityNetwork;

        private IWorkspace OpenWorkspace(string workspace, string type)
        {
            IWorkspace m_pWorkspace;
            try
            {
                Type factoryType = Type.GetTypeFromProgID(type);
                IWorkspaceFactory pAccessFactory = (IWorkspaceFactory)Activator.CreateInstance(factoryType);
                m_pWorkspace = pAccessFactory.OpenFromFile(workspace, 0);
            }
            catch (Exception)
            {
                return null;
            }
            return m_pWorkspace;
        }

        public void OpenFeatureClass(string dataSetName,  ref IFeatureClass subscriber, ref IFeatureClass consumer, ref IFeatureClass gaspipeline, ref IFeatureClass grs, ref IFeatureClass ArmtDataSet_Net_Junctions, ref IFeatureClass stpvalve, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {
                        switch (ids2.Name)
                        {
                            case workLayers.grs:
                            {
                                grs = (IFeatureClass)ids2;
                                break;
                            }
                            case workLayers.subscriber:
                            {
                                subscriber = (IFeatureClass)ids2;
                                break;
                            }
                            case workLayers.gaspipeline:
                            {
                                gaspipeline = (IFeatureClass)ids2;
                                break;
                            }
                            case workLayers.ArmtDataSet_Net_Junctions:
                            {
                                ArmtDataSet_Net_Junctions = (IFeatureClass)ids2;
                                break;
                            }
                            case workLayers.consumer:
                            {
                                consumer = (IFeatureClass)ids2;
                                break;
                            }
                            case workLayers.stpvalve:
                            {
                                stpvalve = (IFeatureClass)ids2;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }

        public string CreateFullGeometricNetwork(string eidArms, string layer)
        {
            //                                          C:\TestNetwork
            //IWorkspace m_pWorkspace = OpenWorkspace(@"D:\GASRB\GASArmat.gdb", "esriDataSourcesGDB.SdeWorkspaceFactory");
            IWorkspace m_pWorkspace = OpenWorkspace(@"C:\TestNetwork\GASArmat.gdb", "esriDataSourcesGDB.FileGDBWorkspaceFactory");
            OpenFeatureClass("ArmtDataSet", ref subscriber, ref consumer, ref gaspipeline, ref grs, ref ArmtDataSet_Net_Junctions, ref stpvalve, m_pWorkspace);
            IGeometricNetwork geomNet = OpenGeometricNetwork("ArmtDataSet", "ArmtDataSet_Net", m_pWorkspace);
            //INetwork net = geomNet.Network;
            //utilityNetwork = net as IUtilityNetwork;
            //IQueryFilter pQueryFilter = new QueryFilterClass();
            //IFeatureCursor pFeatureCursor = null;
            //pFeatureCursor = stpvalve.Search(pQueryFilter, false);
            //IFeature iFeature = pFeatureCursor.NextFeature();
            //IPoint source = null;
            resultAbonJuncs = new AbonJunctions();

            SecondaryTracerAbon secondaryTracer = new SecondaryTracerAbon();
            int consumerClassID = 0;
            int armaturaClassID = 0;
            int junctionClassID = 0;
            int subsciberClassID = 0;
            int grsClassID = 0;
            consumerClassID = SecondaryTracerAbon.ClassIDFromName(workLayers.consumer, m_pWorkspace);
            subsciberClassID = SecondaryTracerAbon.ClassIDFromName(workLayers.subscriber, m_pWorkspace);
            armaturaClassID = SecondaryTracerAbon.ClassIDFromName(workLayers.stpvalve, m_pWorkspace);
            junctionClassID = SecondaryTracerAbon.ClassIDFromName(workLayers.ArmtDataSet_Net_Junctions, m_pWorkspace);
            grsClassID = SecondaryTracerAbon.ClassIDFromName(workLayers.grs, m_pWorkspace);
            secondaryTracer = new SecondaryTracerAbon(armaturaClassID, consumerClassID, subsciberClassID, junctionClassID, grsClassID, ref geomNet);
            
            string[] Arms = eidArms.Split(' ');              // строка со списком EID задвижек делится на массив строк
            int SizeOfMassive = Arms.Count();               // определяется размер полученного массива, т.е. кол-во задвижек
            int[] EIDs = new int[10];                // массив EIDов - номеров задвижек в сети

            for (int i = 0; i < SizeOfMassive; i++)                 // конвертация массива строк в массив чисел
            { EIDs[i] = Convert.ToInt32(Arms[i]); }

            //for (int i = 0; i < SizeOfMassive; i++)
            //{                                               // для каждого OID в целочисленном массиве... 
            //    while (iFeature != null)
            //    {                                                   // производится поиск по геометрии...
            //        if (iFeature.OID == SelOIDs[i])     
            //        {                                                           // и для найденных точек производится поиск...
            //            source = (IPoint)iFeature.Shape;                        // по сети с определением их EID
            //            EIDs[i] = geomNet.get_JunctionElement(source);
            //            break;
            //        }
            //        iFeature = pFeatureCursor.NextFeature();
            //    }
            //}

            secondaryTracer.BeginTrace(EIDs, SizeOfMassive);
            for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
            {
                resultAbonJuncs.Add(secondaryTracer.AbonentJunctions.junctions[i].EID);
            }
            

            # region Заполнение атрибутики
            if (secondaryTracer.AbonentJunctions !=null)
                for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
                {
                    IGeometry geom = geomNet.get_GeometryForJunctionEID(secondaryTracer.AbonentJunctions.junctions[i].EID);
               
                    IPoint point = geom as IPoint;
                    //Находим потребителя
                    ISpatialFilter pSpatialFilter2;
                    IFeatureCursor pFCursor2;
                    pSpatialFilter2 = new SpatialFilter();
                    pSpatialFilter2.Geometry = geom;
                    pSpatialFilter2.set_OutputSpatialReference(consumer.ShapeFieldName, ((IGeoDataset)consumer).SpatialReference);
                    pSpatialFilter2.GeometryField = consumer.ShapeFieldName;
                    pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursor2 = consumer.Search(pSpatialFilter2, false);
                    IFeature result2 = pFCursor2.NextFeature();
                    //Берем атрибуты
                    if (result2 != null)
                    {
                        if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].name = (string)(result2.get_Value(result2.Fields.FindField("NAME")));
                        if (result2.get_Value(result2.Fields.FindField("BRANCH")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].branch = (string)(result2.get_Value(result2.Fields.FindField("BRANCH")));
                        if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].region = (string)(result2.get_Value(result2.Fields.FindField("REGION")));
                        if (result2.get_Value(result2.Fields.FindField("OTRASL")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].otrasl = (string)(result2.get_Value(result2.Fields.FindField("OTRASL")));
                        if (result2.get_Value(result2.Fields.FindField("QFACTYEAR")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].qfactyear = (result2.get_Value(result2.Fields.FindField("QFACTYEAR"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("BOILERAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].boileramount = (result2.get_Value(result2.Fields.FindField("BOILERAMOUNT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("GRU")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].gru = (result2.get_Value(result2.Fields.FindField("GRU"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("QPROJYEAR")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].qprojyear = (result2.get_Value(result2.Fields.FindField("QPROJYEAR"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("QFACTHOUR")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].qfacthour = (result2.get_Value(result2.Fields.FindField("QFACTHOUR"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("INLETPRESS")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].inletpress = (result2.get_Value(result2.Fields.FindField("INLETPRESS"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("OUTLETPRESS")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].outletpress = (result2.get_Value(result2.Fields.FindField("OUTLETPRESS"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("SETTLEMENT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].settlement = (result2.get_Value(result2.Fields.FindField("SETTLEMENT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("REGULATOR")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].regulator = (result2.get_Value(result2.Fields.FindField("REGULATOR"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("OBJ")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].obj = (result2.get_Value(result2.Fields.FindField("OBJ"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("NN")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].nn = (result2.get_Value(result2.Fields.FindField("NN"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("NDOGOVOR")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].ndogovor = (result2.get_Value(result2.Fields.FindField("NDOGOVOR"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("PZK")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].pzk = (result2.get_Value(result2.Fields.FindField("PZK"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("PSK")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].psk = (result2.get_Value(result2.Fields.FindField("PSK"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("BRAND")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].brand = (result2.get_Value(result2.Fields.FindField("BRAND"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("OBORUD")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].oborud = (result2.get_Value(result2.Fields.FindField("OBORUD"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("GRS")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].grs = (result2.get_Value(result2.Fields.FindField("GRS"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("GRSLINES")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].grslines = (result2.get_Value(result2.Fields.FindField("GRSLINES"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("USELUCHET")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].useluchet = (result2.get_Value(result2.Fields.FindField("USELUCHET"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("SEZON")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].sezon = (result2.get_Value(result2.Fields.FindField("SEZON"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("DURATION")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].duration = (result2.get_Value(result2.Fields.FindField("DURATION"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("INN")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].inn = (result2.get_Value(result2.Fields.FindField("INN"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("KPP")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].kpp = (result2.get_Value(result2.Fields.FindField("KPP"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("UPDATES")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].updates = (result2.get_Value(result2.Fields.FindField("UPDATES"))).ToString();

                        resultAbonJuncs.junctions[i].X = point.X;
                        resultAbonJuncs.junctions[i].Y = point.Y;
                    }

                    pSpatialFilter2 = new SpatialFilter();
                    pSpatialFilter2.Geometry = geom;
                    pSpatialFilter2.set_OutputSpatialReference(subscriber.ShapeFieldName, ((IGeoDataset)subscriber).SpatialReference);
                    pSpatialFilter2.GeometryField = subscriber.ShapeFieldName;
                    pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursor2 = subscriber.Search(pSpatialFilter2, false);
                    result2 = null;
                    result2 = pFCursor2.NextFeature();
                    //Берем атрибуты
                    if (result2 != null)
                    {
                        if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].name = (string)(result2.get_Value(result2.Fields.FindField("NAME")));
                        if (result2.get_Value(result2.Fields.FindField("BRANCH")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].branch = (string)(result2.get_Value(result2.Fields.FindField("BRANCH")));
                        if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].region = (string)(result2.get_Value(result2.Fields.FindField("REGION")));
                        if (result2.get_Value(result2.Fields.FindField("ORGANIZATION")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].organization = (string)(result2.get_Value(result2.Fields.FindField("ORGANIZATION")));
                        if (result2.get_Value(result2.Fields.FindField("CODE")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].code = (string)(result2.get_Value(result2.Fields.FindField("CODE")));
                        if (result2.get_Value(result2.Fields.FindField("VALVEAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].valveamont = (result2.get_Value(result2.Fields.FindField("VALVEAMOUNT"))).ToString();
                            //resultAbonJuncs.junctions[i].valveamont = (string)(result2.get_Value(result2.Fields.FindField("VALVEAMOUNT")));
                        if (result2.get_Value(result2.Fields.FindField("CONSUMERAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].consumeramount = (result2.get_Value(result2.Fields.FindField("CONSUMERAMOUNT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("FRYERAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].fryeramount = (result2.get_Value(result2.Fields.FindField("FRYERAMOUNT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("NSWATERHEATERAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].nswaterheateramount = (result2.get_Value(result2.Fields.FindField("NSWATERHEATERAMOUNT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("SWATERHEATERAMOUNT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].swaterheateramount = (result2.get_Value(result2.Fields.FindField("SWATERHEATERAMOUNT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMAX")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].hconsumptionfactmax = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMAX"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMIN")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].hconsumptionfactmin = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMIN"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("SETTLEMENT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].settlement = (result2.get_Value(result2.Fields.FindField("SETTLEMENT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("SETTLEMENTDISTRICT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].settlementdistrict = (result2.get_Value(result2.Fields.FindField("SETTLEMENTDISTRICT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONPRJ")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].hconsumptionprj = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONPRJ"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("YCONSUMPTIONFACT")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].yconsumptionfact = (result2.get_Value(result2.Fields.FindField("YCONSUMPTIONFACT"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("HOUSENUMBER")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].housenumber = (result2.get_Value(result2.Fields.FindField("HOUSENUMBER"))).ToString();
                        if (result2.get_Value(result2.Fields.FindField("STREET")).ToString().Length != 0)
                            resultAbonJuncs.junctions[i].street = (result2.get_Value(result2.Fields.FindField("STREET"))).ToString();

                        resultAbonJuncs.junctions[i].X = point.X;
                        resultAbonJuncs.junctions[i].Y = point.Y;
                    }

                    Marshal.ReleaseComObject(pSpatialFilter2);
                    Marshal.ReleaseComObject(pFCursor2);
                    if (result2 != null)
                    Marshal.ReleaseComObject(result2);
                }
            # endregion

            if (m_pWorkspace != null) Marshal.ReleaseComObject(m_pWorkspace);
            if (grs != null) Marshal.ReleaseComObject(grs);
            if (subscriber != null) Marshal.ReleaseComObject(subscriber);
            if (gaspipeline != null) Marshal.ReleaseComObject(gaspipeline);
            if (ArmtDataSet_Net_Junctions != null) Marshal.ReleaseComObject(ArmtDataSet_Net_Junctions);
            //if (utilityNetwork != null) Marshal.ReleaseComObject(utilityNetwork);
            if (geomNet != null) Marshal.ReleaseComObject(geomNet);
            //if (net != null) Marshal.ReleaseComObject(net);
            //if (secondaryTracer != null) Marshal.ReleaseComObject(secondaryTracer);
            //if (pQueryFilter != null) Marshal.ReleaseComObject(pQueryFilter);
            //if (pFeatureCursor != null) Marshal.ReleaseComObject(pFeatureCursor);
            //if (iFeature != null) Marshal.ReleaseComObject(iFeature);
            //if (source != null) Marshal.ReleaseComObject(source);
            //if (secondaryTracer.AbonentJunctions != null) return secondaryTracer.AbonentJunctions.getXML();
            if (resultAbonJuncs != null) return resultAbonJuncs.getXML();
            else return null;
        }

        public static IGeometricNetwork OpenGeometricNetwork(string dataSetName, string featureClassName, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {
                        if (ids2.Name.ToLower() == featureClassName.ToLower())
                        {
                            return (IGeometricNetwork)ids2;
                        }
                    }
                    break;
                }
            }
            return null;
        }
    }
}
