﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using ESRI.ArcGIS.Geodatabase;
//using ESRI.ArcGIS.NetworkAnalysis;
//using ESRI.ArcGIS.esriSystem;
//using ESRI.ArcGIS.Geometry;
//using System.Runtime.InteropServices;
//using Newtonsoft.Json;
//using System.Diagnostics;
//using GazServiceTools;

//namespace GeomertyNetworkWorker
//{

//    public class GetNetworkArmat
//    {
//        public GetNetworkArmat()
//        {
//            Global.initializeLicenze();
//        }

//        public static class workLayers
//        {
//            public static string subscriber = "subscriber";
//            public static string consumer = "consumer";
//            public static string gaspipeline = "gaspipeline";
//            public static string grs = "grs";
//            public static string stpvalve = "stpvalve";
//            public static string ArmtDataSet_Net_Junctions = "ArmtDataSet_Net_Junctions";
//            public static string prg = "prg";
//        }



//        public static string workspace = @"C:\TestNetwork\GASArmat.gdb";
//        public static string type = "esriDataSourcesGDB.FileGDBWorkspaceFactory";
//        public static string datasetname = "ArmtDataSet";
//        public static string geometrynetwork = "ArmtDataSet_Net";


//        private ArmatJunctions resultArmJuncs;
//        private AbonJunctions resultAbonJuncs;
//        private ArmatJunctions resPoints;
//        private IFeatureClass subscriber;
//        private IFeatureClass consumer;
//        private IFeatureClass gaspipeline;
//        private IFeatureClass grs;
//        private IFeatureClass stpvalve;
//        private IFeatureClass prg;
//        private IFeatureClass ArmtDataSet_Net_Junctions;
//        private IUtilityNetwork utilityNetwork;

//        private IWorkspace OpenWorkspace(string workspace, string type)
//        {
//            IWorkspace m_pWorkspace;
//            try
//            {
//                Type factoryType = Type.GetTypeFromProgID(type);
//                IWorkspaceFactory pAccessFactory = (IWorkspaceFactory)Activator.CreateInstance(factoryType);
//                m_pWorkspace = pAccessFactory.OpenFromFile(workspace, 0);
//            }
//            catch (Exception)
//            {
//                return null;
//            }
//            return m_pWorkspace;
//        }

//        public void OpenFeatureClass(string dataSetName, ref IFeatureClass subscriber, ref IFeatureClass consumer, ref IFeatureClass gaspipeline, ref IFeatureClass grs, ref IFeatureClass ArmtDataSet_Net_Junctions, ref IFeatureClass stpvalve, IWorkspace m_pWorkspace)
//        {
//            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
//            IDatasetName idn;
//            IFeatureDataset ifds;

//            while ((idn = ied.Next()) != null)
//            {
//                if (idn.Name.ToLower() == dataSetName.ToLower())
//                {
//                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
//                    ifds = ifs.OpenFeatureDataset(dataSetName);
//                    IEnumDataset ied2 = ifds.Subsets;
//                    IDataset ids2;
//                    while ((ids2 = ied2.Next()) != null)
//                    {

//                        if (ids2.Name == workLayers.grs)
//                        {
//                            grs = (IFeatureClass)ids2;
//                            continue;
//                        }

//                        if (ids2.Name == workLayers.subscriber)
//                        {
//                            subscriber = (IFeatureClass)ids2;
//                            continue;
//                        }

//                        if (ids2.Name == workLayers.gaspipeline)
//                        {
//                            gaspipeline = (IFeatureClass)ids2;
//                            continue;
//                        }

//                        if (ids2.Name == workLayers.ArmtDataSet_Net_Junctions)
//                        {
//                            ArmtDataSet_Net_Junctions = (IFeatureClass)ids2;
//                            continue;
//                        }

//                        if (ids2.Name == workLayers.consumer)
//                        {
//                            consumer = (IFeatureClass)ids2;
//                            continue;
//                        }

//                        if (ids2.Name == workLayers.stpvalve)
//                        {
//                            stpvalve = (IFeatureClass)ids2;
//                            continue;
//                        }
//                        if (ids2.Name == workLayers.prg)
//                        {
//                            prg = (IFeatureClass)ids2;
//                            continue;
//                        }
//                        #region old

//                        #endregion
//                    }
//                    //break;
//                }
//            }
//        }

//        public string[] CreateFullGeometricNetwork(int x, int y, string layer, string JIDs)
//        {
//            if (JIDs == null)
//                JIDs = "";
//            //                                          C:\TestNetwork
//            //IWorkspace m_pWorkspace = OpenWorkspace(@"D:\GASRB\GASArmat.gdb", "esriDataSourcesGDB.SdeWorkspaceFactory");
//            string profileMessage = "";
//            Tracer tracer = new Tracer();

//            tracer.StartTrace("Create full netwok");
//            tracer.StartTrace("Initialize");
//            IWorkspace m_pWorkspace = OpenWorkspace(@workspace, type);
//            OpenFeatureClass(datasetname, ref subscriber, ref consumer, ref gaspipeline, ref grs, ref ArmtDataSet_Net_Junctions, ref stpvalve, m_pWorkspace);
//            IGeometricNetwork geomNet = OpenGeometricNetwork(datasetname, geometrynetwork, m_pWorkspace);
//            INetwork net = geomNet.Network;

//            utilityNetwork = net as IUtilityNetwork;
//            SecondaryTracerArmatura secondaryTracer = new SecondaryTracerArmatura();
//            resultArmJuncs = new ArmatJunctions();
//            resultAbonJuncs = new AbonJunctions();
//            resPoints = new ArmatJunctions();
//            IPoint originalPoint = new Point();
//            originalPoint.X = x;
//            originalPoint.Y = y;
//            IFeature iFeatureGeom = null;
//            try
//            {
//                if (layer == "gaspipeline") iFeatureGeom = FindFeature(3.1, originalPoint, gaspipeline);
//            }
//            catch (Exception ex)
//            {

//            }
//            int[] junction = new int[2];
//            //int sourceEID1 = 0;
//            //int sourceEID2 = 0;
//            int armaturaClassID = 0;
//            int consumerClassID = 0;
//            int subsciberClassID = 0;
//            int grsClassID = 0;
//            int junctionClassID = 0;
//            int prgClassID = 0;

//            List<int> intJIDs = new List<int>();
//            int[] arrJIDs;
//            IPointCollection source = null;
//            IPoint medianPoint = null;
//            IPoint realPoint = null;
//            IPolyline poly = null;

//            if (iFeatureGeom != null)
//            {

//                source = (IPointCollection)iFeatureGeom.Shape;
//                poly = (IPolyline)iFeatureGeom.Shape;
//                medianPoint = new Point();
//                realPoint = new Point();

//                medianPoint.X = source.get_Point(0).X;
//                medianPoint.Y = source.get_Point(0).Y;

//                //sourceEID1 = geomNet.get_JunctionElement(medianPoint);
//                junction[0] = geomNet.get_JunctionElement(medianPoint);
//                //realPoint.X = (source.get_Point(0).X + source.get_Point(1).X)/2;
//                //realPoint.Y = (source.get_Point(0).Y + source.get_Point(1).Y)/2;
//                double distAlongcurve = 0;
//                double distFromcurve = 0;
//                bool bRightSide = true;
//                IPoint outpoint = new Point();
//                poly.QueryPointAndDistance(esriSegmentExtension.esriExtendEmbedded, originalPoint, true, outpoint, ref distAlongcurve, ref distFromcurve, ref bRightSide);

//                realPoint = outpoint;

//                medianPoint.X = source.get_Point(source.PointCount - 1).X;
//                medianPoint.Y = source.get_Point(source.PointCount - 1).Y;
//                //sourceEID2 = geomNet.get_JunctionElement(medianPoint);
//                junction[1] = geomNet.get_JunctionElement(medianPoint);

//                //JIDs = "76523;48264;78541;";


//                arrJIDs = new int[JIDs.Split(';').Length];

//                for (int i = 0; i < JIDs.Split(';').Length; i++)
//                {
//                    string tmp = JIDs.Split(';')[i];
//                    if (tmp != "")
//                        arrJIDs[i] = (int.Parse(tmp));
//                }




//                armaturaClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.stpvalve, m_pWorkspace);
//                consumerClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.consumer, m_pWorkspace);
//                subsciberClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.subscriber, m_pWorkspace);
//                grsClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.grs, m_pWorkspace);
//                junctionClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.ArmtDataSet_Net_Junctions, m_pWorkspace);
//                prgClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.prg, m_pWorkspace);
//                secondaryTracer = new SecondaryTracerArmatura(armaturaClassID, consumerClassID, subsciberClassID, grsClassID, junctionClassID, prgClassID, ref geomNet);
//                //secondaryTracer.BeginTrace(sourceEID1, sourceEID2);
//                tracer.StopTrace();

//                tracer.StartTrace("Call secondary tracer");
//                if (JIDs == "")
//                    secondaryTracer.ATrace(junction, geomNet.get_EdgeElement(realPoint));
//                else secondaryTracer.ATrace(junction, geomNet.get_EdgeElement(realPoint), arrJIDs);
//                tracer.StopTrace();

//                for (int i = 0; i < secondaryTracer.ArmaturaJunctions.junctions.Count; i++)
//                {
//                    resultArmJuncs.Add(secondaryTracer.ArmaturaJunctions.junctions[i].EID);
//                }
//                for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
//                {

//                    resultAbonJuncs.Add(secondaryTracer.AbonentJunctions.junctions[i].EID);
//                }

//                for (int i = 0; i < secondaryTracer.SGMEDGE.Count; i++)
//                {
//                    resPoints.Add(secondaryTracer.SGMEDGE.junctions[i].EID);
//                }


//            }
//            tracer.StartTrace("Get Armat junctions");
//            int[] armatjuncIds = new int[secondaryTracer.ArmaturaJunctions.junctions.Count];
//            //<OID, index в ArmatJunctions>
//            Dictionary<int, int> armatIndexes = new Dictionary<int, int>();

//            INetElements netEl = (INetElements)utilityNetwork;
//            int classID; int userID; int userSubID;

//            for (int i = 0; i < secondaryTracer.ArmaturaJunctions.junctions.Count; i++)
//            {
//                netEl.QueryIDs(secondaryTracer.ArmaturaJunctions.junctions[i].EID, esriElementType.esriETJunction, out classID, out userID, out userSubID);
//                armatjuncIds[i] = userID;
//                if (!armatIndexes.ContainsKey(userID))
//                    armatIndexes.Add(userID, i);
//            }
//            IGeoDatabaseBridge2 bridge = new GeoDatabaseHelperClass();
//            tracer.StopTrace();
//            tracer.StartTrace("Armatura");
//            # region Заполнение атрибутики по задвижке
//            if (secondaryTracer.ArmaturaJunctions != null && secondaryTracer.ArmaturaJunctions.junctions.Count != 0)
//            {
//                IFeatureCursor pFCursor2 = bridge.GetFeatures(stpvalve, ref armatjuncIds, true);
//                IFeature result2;
//                IPoint point;
//                while ((result2 = pFCursor2.NextFeature()) != null)
//                {
//                    int index = armatIndexes[result2.OID];
//                    //resultArmJuncs.junctions[i].objectid = result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString();
//                    if (result2.Fields.FindField("REGION") != -1)
//                        if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].raion = (result2.get_Value(result2.Fields.FindField("REGION"))).ToString();
//                    if (result2.Fields.FindField("TYPE") != -1)
//                        if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
//                    if (result2.Fields.FindField("NAME") != -1)
//                        if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].name = (result2.get_Value(result2.Fields.FindField("NAME"))).ToString();
//                    //if (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString().Length != 0)
//                    //resultArmJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString());
//                    point = (IPoint)result2.Shape;
//                    resultArmJuncs.junctions[index].X = point.X;
//                    resultArmJuncs.junctions[index].Y = point.Y;
//                }
//                Marshal.ReleaseComObject(pFCursor2);
//                if (result2 != null)
//                    Marshal.ReleaseComObject(result2);
//                #region PRG
//                IFeatureCursor pFCursor = bridge.GetFeatures(prg, ref armatjuncIds, true);
//                IFeature result3;

//                while ((result3 = pFCursor.NextFeature()) != null)
//                {
//                    int index = armatIndexes[result2.OID];
//                    //resultArmJuncs.junctions[i].objectid = result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString();
//                    if (result3.Fields.FindField("REGION") != -1)
//                        if (result3.get_Value(result3.Fields.FindField("REGION")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].raion = (result3.get_Value(result3.Fields.FindField("REGION"))).ToString();
//                    if (result3.Fields.FindField("TYPE") != -1)
//                        if (result3.get_Value(result3.Fields.FindField("TYPE")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].type = (result3.get_Value(result3.Fields.FindField("TYPE"))).ToString();
//                    if (result3.Fields.FindField("NAME") != -1)
//                        if (result3.get_Value(result3.Fields.FindField("NAME")).ToString().Length != 0)
//                            resultArmJuncs.junctions[index].name = (result3.get_Value(result3.Fields.FindField("NAME"))).ToString();
//                    //if (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString().Length != 0)
//                    //resultArmJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString());
//                    point = (IPoint)result2.Shape;

//                    resultArmJuncs.junctions[index].X = point.X;
//                    resultArmJuncs.junctions[index].Y = point.Y;
//                }
//                Marshal.ReleaseComObject(pFCursor);
//                if (result3 != null)
//                    Marshal.ReleaseComObject(result3);
//                #endregion
//            }
//            # endregion
//            tracer.StopTrace();
//            #region Газопровод
//            tracer.StartTrace("Pipelines");
//            string strError = "";
//            int number = 0;
//            int[] sgmIds = new int[secondaryTracer.SGMEDGE.junctions.Count];
//            //<OID, index в ArmatJunctions>
//            Dictionary<int, int> sgmIndexes = new Dictionary<int, int>();
//            List<int> repeats = new List<int>(10);
//            List<int> repeatsIndexes = new List<int>(10);
//            StatisticTracer statTracer = new StatisticTracer();
//            for (int i = 0; i < secondaryTracer.SGMEDGE.junctions.Count; i++)
//            {
//                netEl.QueryIDs(secondaryTracer.SGMEDGE.junctions[i].EID, esriElementType.esriETEdge, out classID, out userID, out userSubID);
//                sgmIds[i] = userID;
//                if (!sgmIndexes.ContainsKey(userID))
//                {
//                    sgmIndexes.Add(userID, i);
//                }
//                else
//                {
//                    repeats.Add(i);
//                    repeatsIndexes.Add(userID);
//                }
//            }

//            tracer.StartTrace("Pipeline query ids");
//            IFeatureCursor pFCursor3 = bridge.GetFeatures(gaspipeline, ref sgmIds, true);
//            tracer.StopTrace();
//            IFeature iresult3 = null;
//            IPolyline pline;
//            int count_pipe = 0;
//            int repeats_iterator = 0;
//            try
//            {
//                IGeometryBridge geometryBridge = new GeometryEnvironmentClass();
//                Dictionary<int, double> domainCodes = new Dictionary<int, double>();
//                Dictionary<string, int> gasFields = new Dictionary<string, int>() { 
//                   {"NAME", gaspipeline.Fields.FindField("NAME")},
//                   {"LENGTHPART", gaspipeline.Fields.FindField("LENGTHPART")},
//                   {"PRESSUREFACT", gaspipeline.Fields.FindField("PRESSUREFACT")},
//                   {"DIAMETERNOMINAL", gaspipeline.Fields.FindField("DIAMETERNOMINAL")},
//               };
//                int fieldNumber = gasFields["DIAMETERNOMINAL"];
//                IDomain domain = gaspipeline.Fields.get_Field(fieldNumber).Domain;
//                ICodedValueDomain codeVDomain = domain as ICodedValueDomain;
//                for (int zz = 0; zz < codeVDomain.CodeCount; zz++)
//                {
//                    Int16 val = Convert.ToInt16(codeVDomain.get_Value(zz).ToString());
//                    domainCodes.Add(val, CalculateGasReserve.convertToMeter(Convert.ToDouble(codeVDomain.get_Name(zz))));
//                }
//                while ((iresult3 = pFCursor3.NextFeature()) != null || (repeatsIndexes.Count > repeats_iterator))
//                {
//                    statTracer.Start("Pipeline iteration");
//                    count_pipe++;
//                    statTracer.Start("Pipeline get IFearure");
//                    IGeometry mygeom;
//                    int i;
//                    if (iresult3 == null)
//                    {
//                        int oid = repeatsIndexes[repeats_iterator];
//                        iresult3 = gaspipeline.GetFeature(oid);
//                        i = repeats[repeats_iterator];
//                        repeats_iterator++;
//                    }
//                    else
//                    {
//                        i = sgmIndexes[iresult3.OID];
//                    }

//                    mygeom = iresult3.Shape;
//                    number = i;

//                    IPointCollection2 ipcollection = mygeom as IPointCollection2;
//                    statTracer.Stop("Pipeline get IFearure");
//                    #region code

//                    statTracer.Start("Pipeline attributes");
//                    if (gasFields["NAME"] != -1)
//                        if (iresult3.get_Value(gasFields["NAME"]).ToString().Length != 0)
//                            resPoints.junctions[i].name = (iresult3.get_Value(gasFields["NAME"])).ToString();
//                    if (gasFields["DIAMETERNOMINAL"] != -1)
//                        if (iresult3.get_Value(gasFields["DIAMETERNOMINAL"]).ToString().Length != 0)
//                        {
//                            /*int fieldNumber = iresult3.Fields.FindField("DIAMETERNOMINAL");
//                            int domainCode = Convert.ToInt16(iresult3.get_Value(fieldNumber));
//                            IDomain domain = iresult3.Fields.get_Field(fieldNumber).Domain;
//                            ICodedValueDomain codeVDomain = domain as ICodedValueDomain;
//                            statTracer.Start("Domain");
//                            List<string> codeN = new List<string>();
//                            List<string> codeV = new List<string>();
//                            for (int zz = 0; zz < codeVDomain.CodeCount; zz++)
//                            {
//                                codeN.Add(codeVDomain.get_Name(zz));

//                                codeV.Add(codeVDomain.get_Value(zz).ToString());
//                            }
//                            statTracer.Stop("Domain");*/
//                            int domainCode = Convert.ToInt16(iresult3.get_Value(fieldNumber));
//                            try
//                            {

//                                resPoints.junctions[i].Diameter = domainCodes[domainCode];
//                            }
//                            catch (Exception ex)
//                            {
//                                strError = "Ошибка в исходных данных! OID газопровода : " + iresult3.OID.ToString();

//                            }
//                        }
//                    resPoints.junctions[i].StartTemperature = 280.15;
//                    resPoints.junctions[i].EndTemperature = 281.15;
//                    resPoints.junctions[i].GroundTemperature = 293.15;
//                    if (gasFields["LENGTHPART"] != -1)
//                        if (iresult3.get_Value(gasFields["LENGTHPART"]).ToString().Length != 0)
//                            resPoints.junctions[i].Length = Convert.ToDouble(iresult3.get_Value(gasFields["LENGTHPART"]));
//                    if (gasFields["PRESSUREFACT"] != -1)
//                        if (iresult3.get_Value(gasFields["PRESSUREFACT"]).ToString().Length != 0)
//                        {
//                            resPoints.junctions[i].StartPressure = Convert.ToDouble(iresult3.get_Value(gasFields["PRESSUREFACT"]));
//                            resPoints.junctions[i].EndPressure = Convert.ToDouble(iresult3.get_Value(gasFields["PRESSUREFACT"]));
//                        }
//                    statTracer.Stop("Pipeline attributes");
//                    // ыыыы
//                    statTracer.Start("Pipeline calculations");
//                    double cStartTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].StartTemperature);
//                    double cEndTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].EndTemperature);
//                    double cGroundTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].GroundTemperature);

//                    double middleTemperature = CalculateGasReserve.calculateMiddleTemperature(cStartTemperature, cEndTemperature, cGroundTemperature);
//                    double mDiameter = resPoints.junctions[i].Diameter;
//                    double Volume = CalculateGasReserve.calculateVolume(mDiameter, resPoints.junctions[i].Length);
//                    double kgscmStartPressure = CalculateGasReserve.convertFromMPaToKGS_CM2(resPoints.junctions[i].StartPressure);
//                    double kgscmEndPressure = CalculateGasReserve.convertFromMPaToKGS_CM2(resPoints.junctions[i].EndPressure);
//                    double middlePressure = CalculateGasReserve.calculateFactMiddlePressure(kgscmStartPressure, kgscmEndPressure);
//                    //double cmiddlePressure = CalculateGasReserve.convertFromKGS_CM2ToMPa(middlePressure);
//                    if (middlePressure > 10)
//                    {
//                        double absMiddlePressure = CalculateGasReserve.calculateAbsMiddlePressure(middlePressure);
//                        double gascompfactor = CalculateGasReserve.calculateGasCompressFactor(middleTemperature, absMiddlePressure);
//                        resPoints.junctions[i].GasReserve = CalculateGasReserve.calculateGasReserve(Volume, absMiddlePressure, gascompfactor, middleTemperature);
//                    }
//                    else if (middlePressure < 10)
//                    {
//                        double absMiddlePressure = CalculateGasReserve.calculateAbsMiddlePressure(middlePressure);
//                        resPoints.junctions[i].GasReserve = CalculateGasReserve.calculateGasReserve(Volume, absMiddlePressure, 1, middleTemperature);
//                    }
//                    statTracer.Stop("Pipeline calculations");
//                    statTracer.Start("Pipeline points");
//                    #endregion
//                    string temp = "";

//                    int point_count = ipcollection.PointCount;

//                    IPoint[] points = new IPoint[point_count];
//                    IPoint point;
//                    for (int z = 0; z < point_count; z++)
//                    {
//                        point = ipcollection.Point[z];
//                        double xP = point.X;
//                        double yP = point.Y;
//                        temp = temp + (xP + "|" + yP + ";");
//                    }

//                    resPoints.junctions[i].EID = i;
//                    resPoints.junctions[i].Points = temp;
//                    statTracer.Stop("Pipeline points");
//                    statTracer.Stop("Pipeline iteration");
//                }

//            }
//            catch (Exception ex)
//            {
//                strError = number.ToString();
//                strError = "Обнаружена ошибка в исходных данных! Проверьте сеть! Результаты, выданные системой, могут быть некорректны.";
//            }
//            finally
//            {
//                Marshal.ReleaseComObject(pFCursor3);
//                if (iresult3 != null)
//                    Marshal.ReleaseComObject(iresult3);
//            }
//            #endregion
//            tracer.StopTrace();
//            tracer.StartTrace("Cunsumers");
//            int[] abonIds = new int[secondaryTracer.AbonentJunctions.junctions.Count];
//            //<OID, index в ArmatJunctions>
//            Dictionary<int, int> abonIndexes = new Dictionary<int, int>();

//            for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
//            {
//                netEl.QueryIDs(secondaryTracer.AbonentJunctions.junctions[i].EID, esriElementType.esriETJunction, out classID, out userID, out userSubID);
//                abonIds[i] = userID;
//                if (!abonIndexes.ContainsKey(userID))
//                    abonIndexes.Add(userID, i);
//            }

//            # region Заполнение атрибутики по абонентам
//            IFeatureCursor pFCursor4 = bridge.GetFeatures(consumer, ref abonIds, true);
//            IFeature result4 = null;
//            int count_abon = 0;
//            Dictionary<string, int> abonFields = new Dictionary<string, int>();
//            for (int i = 0; i < consumer.Fields.FieldCount; i++)
//            {
//                abonFields.Add(consumer.Fields.get_Field(i).AliasName, i);
//            }

//            if (secondaryTracer.AbonentJunctions != null && secondaryTracer.AbonentJunctions.junctions.Count != 0)

//                while ((result4 = pFCursor4.NextFeature()) != null)
//                {
//                    count_abon++;
//                    int i = abonIndexes[result4.OID];
//                    IGeometry geom = geomNet.get_GeometryForJunctionEID(secondaryTracer.AbonentJunctions.junctions[i].EID);
//                    IPoint point = geom as IPoint;

//                    //Берем атрибуты
//                    if (result4 != null)
//                    {
//                        if (abonFields["NAME"] != -1)
//                            if (result4.get_Value(abonFields["NAME"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].name = (result4.get_Value(abonFields["NAME"])).ToString();
//                        if (abonFields["BRANCH"] != -1)
//                            if (result4.get_Value(abonFields["BRANCH"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].branch = (result4.get_Value(abonFields["BRANCH"])).ToString();
//                        if (abonFields["REGION"] != -1)
//                            if (result4.get_Value(abonFields["REGION"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].region = (result4.get_Value(abonFields["REGION"])).ToString();
//                        if (abonFields["OTRASL"] != -1)
//                            if (result4.get_Value(abonFields["OTRASL"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].otrasl = (result4.get_Value(abonFields["OTRASL"])).ToString();
//                        if (abonFields["QFACTYEAR"] != -1)
//                            if (result4.get_Value(abonFields["QFACTYEAR"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].qfactyear = (result4.get_Value(abonFields["QFACTYEAR"])).ToString();
//                        if (abonFields["BOILERAMOUNT"] != -1)
//                            if (result4.get_Value(abonFields["BOILERAMOUNT"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].boileramount = (result4.get_Value(abonFields["BOILERAMOUNT"])).ToString();
//                        if (abonFields["GRU"] != -1)
//                            if (result4.get_Value(abonFields["GRU"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].gru = (result4.get_Value(abonFields["GRU"])).ToString();
//                        if (abonFields["QPROJYEAR"] != -1)
//                            if (result4.get_Value(abonFields["QPROJYEAR"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].qprojyear = (result4.get_Value(abonFields["QPROJYEAR"])).ToString();
//                        if (abonFields["QFACTHOUR"] != -1)
//                            if (result4.get_Value(abonFields["QFACTHOUR"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].qfacthour = (result4.get_Value(abonFields["QFACTHOUR"])).ToString();
//                        if (abonFields["INLETPRESS"] != -1)
//                            if (result4.get_Value(abonFields["INLETPRESS"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].inletpress = (result4.get_Value(abonFields["INLETPRESS"])).ToString();
//                        if (abonFields["OUTLETPRESS"] != -1)
//                            if (result4.get_Value(abonFields["OUTLETPRESS"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].outletpress = (result4.get_Value(abonFields["OUTLETPRESS"])).ToString();
//                        if (abonFields["SETTLEMENT"] != -1)
//                            if (result4.get_Value(abonFields["SETTLEMENT"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].settlement = (result4.get_Value(abonFields["SETTLEMENT"])).ToString();
//                        if (abonFields["TYPE"] != -1)
//                            if (result4.get_Value(abonFields["TYPE"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].type = (result4.get_Value(abonFields["TYPE"])).ToString();
//                        if (abonFields["REGULATOR"] != -1)
//                            if (result4.get_Value(abonFields["REGULATOR"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].regulator = (result4.get_Value(abonFields["REGULATOR"])).ToString();
//                        if (abonFields["OBJ"] != -1)
//                            if (result4.get_Value(abonFields["OBJ"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].obj = (result4.get_Value(abonFields["OBJ"])).ToString();
//                        if (abonFields["NN"] != -1)
//                            if (result4.get_Value(abonFields["NN"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].nn = (result4.get_Value(abonFields["NN"])).ToString();
//                        if (abonFields["NDOGOVOR"] != -1)
//                            if (result4.get_Value(abonFields["NDOGOVOR"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].ndogovor = (result4.get_Value(abonFields["NDOGOVOR"])).ToString();
//                        if (abonFields["PZK"] != -1)
//                            if (result4.get_Value(abonFields["PZK"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].pzk = (result4.get_Value(abonFields["PZK"])).ToString();
//                        if (abonFields["PSK"] != -1)
//                            if (result4.get_Value(abonFields["PSK"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].psk = (result4.get_Value(abonFields["PSK"])).ToString();
//                        if (abonFields["BRAND"] != -1)
//                            if (result4.get_Value(abonFields["BRAND"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].brand = (result4.get_Value(abonFields["BRAND"])).ToString();
//                        if (abonFields["OBORUD"] != -1)
//                            if (result4.get_Value(abonFields["OBORUD"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].oborud = (result4.get_Value(abonFields["OBORUD"])).ToString();
//                        if (abonFields["GRS"] != -1)
//                            if (result4.get_Value(abonFields["GRS"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].grs = (result4.get_Value(abonFields["GRS"])).ToString();
//                        if (abonFields["GRSLINES"] != -1)
//                            if (result4.get_Value(abonFields["GRSLINES"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].grslines = (result4.get_Value(abonFields["GRSLINES"])).ToString();
//                        if (abonFields["USELUCHET"] != -1)
//                            if (result4.get_Value(abonFields["USELUCHET"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].useluchet = (result4.get_Value(abonFields["USELUCHET"])).ToString();
//                        if (abonFields["SEZON"] != -1)
//                            if (result4.get_Value(abonFields["SEZON"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].sezon = (result4.get_Value(abonFields["SEZON"])).ToString();
//                        if (abonFields["DURATION"] != -1)
//                            if (result4.get_Value(abonFields["DURATION"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].duration = (result4.get_Value(abonFields["DURATION"])).ToString();
//                        if (abonFields["INN"] != -1)
//                            if (result4.get_Value(abonFields["INN"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].inn = (result4.get_Value(abonFields["INN"])).ToString();
//                        if (abonFields["KPP"] != -1)
//                            if (result4.get_Value(abonFields["KPP"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].kpp = (result4.get_Value(abonFields["KPP"])).ToString();
//                        if (abonFields["UPDATES"] != -1)
//                            if (result4.get_Value(abonFields["UPDATES"]).ToString().Length != 0)
//                                resultAbonJuncs.junctions[i].updates = (result4.get_Value(abonFields["UPDATES"])).ToString();

//                        resultAbonJuncs.junctions[i].X = point.X;
//                        resultAbonJuncs.junctions[i].Y = point.Y;
//                    }
//                }
//            IFeatureCursor pFCursor5 = bridge.GetFeatures(subscriber, ref abonIds, true);
//            IFeature result5 = null;
//            //Берем атрибуты
//            Dictionary<string, int> abon2Fields = new Dictionary<string, int>();
//            for (int i = 0; i < subscriber.Fields.FieldCount; i++)
//            {
//                abon2Fields.Add(subscriber.Fields.get_Field(i).AliasName, i);
//            }

//            while ((result5 = pFCursor5.NextFeature()) != null)
//            {
//                count_abon++;
//                int i = abonIndexes[result5.OID];
//                IPoint point = result5.Shape as IPoint;
//                if (abon2Fields.ContainsKey("NAME"))
//                    if (result5.get_Value(abon2Fields["NAME"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].name = (result5.get_Value(abon2Fields["NAME"])).ToString();
//                if (abon2Fields.ContainsKey("BRANCH"))
//                    if (result5.get_Value(abon2Fields["BRANCH"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].branch = (result5.get_Value(abon2Fields["BRANCH"])).ToString();
//                if (abon2Fields.ContainsKey("REGION"))
//                    if (result5.get_Value(abon2Fields["REGION"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].region = (result5.get_Value(abon2Fields["REGION"])).ToString();
//                if (abon2Fields.ContainsKey("ORGANIZATION"))
//                    if (result5.get_Value(abon2Fields["ORGANIZATION"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].organization = (result5.get_Value(abon2Fields["ORGANIZATION"])).ToString();
//                if (abon2Fields.ContainsKey("CODE"))
//                    if (result5.get_Value(abon2Fields["CODE"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].code = (result5.get_Value(abon2Fields["CODE"])).ToString();
//                if (abon2Fields.ContainsKey("VALVEAMOUNT"))
//                    if (result5.get_Value(abon2Fields["VALVEAMOUNT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].valveamont = (result5.get_Value(abon2Fields["VALVEAMOUNT"])).ToString();
//                //resultAbonJuncs.junctions[i].valveamont = (string)(result5.get_Value(abon2Fields["VALVEAMOUNT"]));
//                if (abon2Fields.ContainsKey("CONSUMERAMOUNT"))
//                    if (result5.get_Value(abon2Fields["CONSUMERAMOUNT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].consumeramount = (result5.get_Value(abon2Fields["CONSUMERAMOUNT"])).ToString();
//                if (abon2Fields.ContainsKey("FRYERAMOUNT"))
//                    if (result5.get_Value(abon2Fields["FRYERAMOUNT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].fryeramount = (result5.get_Value(abon2Fields["FRYERAMOUNT"])).ToString();
//                if (abon2Fields.ContainsKey("NSWATERHEATERAMOUNT"))
//                    if (result5.get_Value(abon2Fields["NSWATERHEATERAMOUNT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].nswaterheateramount = (result5.get_Value(abon2Fields["NSWATERHEATERAMOUNT"])).ToString();
//                if (abon2Fields.ContainsKey("SWATERHEATERAMOUNT"))
//                    if (result5.get_Value(abon2Fields["SWATERHEATERAMOUNT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].swaterheateramount = (result5.get_Value(abon2Fields["SWATERHEATERAMOUNT"])).ToString();
//                if (abon2Fields.ContainsKey("HCONSUMPTIONFACTMAX"))
//                    if (result5.get_Value(abon2Fields["HCONSUMPTIONFACTMAX"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].hconsumptionfactmax = (result5.get_Value(abon2Fields["HCONSUMPTIONFACTMAX"])).ToString();
//                if (abon2Fields.ContainsKey("HCONSUMPTIONFACTMIN"))
//                    if (result5.get_Value(abon2Fields["HCONSUMPTIONFACTMIN"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].hconsumptionfactmin = (result5.get_Value(abon2Fields["HCONSUMPTIONFACTMIN"])).ToString();
//                if (abon2Fields.ContainsKey("SETTLEMENT"))
//                    if (result5.get_Value(abon2Fields["SETTLEMENT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].settlement = (result5.get_Value(abon2Fields["SETTLEMENT"])).ToString();
//                if (abon2Fields.ContainsKey("TYPE"))
//                    if (result5.get_Value(abon2Fields["TYPE"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].type = (result5.get_Value(abon2Fields["TYPE"])).ToString();
//                if (abon2Fields.ContainsKey("SETTLEMENTDISTRICT"))
//                    if (result5.get_Value(abon2Fields["SETTLEMENTDISTRICT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].settlementdistrict = (result5.get_Value(abon2Fields["SETTLEMENTDISTRICT"])).ToString();
//                if (abon2Fields.ContainsKey("HCONSUMPTIONPRJ"))
//                    if (result5.get_Value(abon2Fields["HCONSUMPTIONPRJ"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].hconsumptionprj = (result5.get_Value(abon2Fields["HCONSUMPTIONPRJ"])).ToString();
//                if (abon2Fields.ContainsKey("YCONSUMPTIONFACT"))
//                    if (result5.get_Value(abon2Fields["YCONSUMPTIONFACT"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].yconsumptionfact = (result5.get_Value(abon2Fields["YCONSUMPTIONFACT"])).ToString();
//                if (abon2Fields.ContainsKey("HOUSENUMBER"))
//                    if (result5.get_Value(abon2Fields["HOUSENUMBER"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].housenumber = (result5.get_Value(abon2Fields["HOUSENUMBER"])).ToString();
//                if (abon2Fields.ContainsKey("STREET"))
//                    if (result5.get_Value(abon2Fields["STREET"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].street = (result5.get_Value(abon2Fields["STREET"])).ToString();
//                if (abon2Fields.ContainsKey("gasconsfacthour"))
//                    if (result5.get_Value(abon2Fields["gasconsfacthour"]).ToString().Length != 0)
//                        resultAbonJuncs.junctions[i].qfacthour = (result5.get_Value(abon2Fields["gasconsfacthour"])).ToString();

//                resultAbonJuncs.junctions[i].X = point.X;
//                resultAbonJuncs.junctions[i].Y = point.Y;
//            }
//            Marshal.ReleaseComObject(pFCursor4);
//            if (result4 != null)
//                Marshal.ReleaseComObject(result4);
//            Marshal.ReleaseComObject(pFCursor5);
//            if (result4 != null)
//                Marshal.ReleaseComObject(result5);
//            # endregion
//            tracer.StopTrace();

//            if (m_pWorkspace != null) Marshal.ReleaseComObject(m_pWorkspace);
//            if (grs != null) Marshal.ReleaseComObject(grs);
//            if (subscriber != null) Marshal.ReleaseComObject(subscriber);
//            if (gaspipeline != null) Marshal.ReleaseComObject(gaspipeline);
//            if (ArmtDataSet_Net_Junctions != null) Marshal.ReleaseComObject(ArmtDataSet_Net_Junctions);
//            if (utilityNetwork != null) Marshal.ReleaseComObject(utilityNetwork);
//            if (geomNet != null) Marshal.ReleaseComObject(geomNet);
//            if (net != null) Marshal.ReleaseComObject(net);
//            //if (secondaryTracer != null) Marshal.ReleaseComObject(secondaryTracer);
//            //if (pQueryFilter != null) Marshal.ReleaseComObject(pQueryFilter);
//            //if (pFeatureCursor != null) Marshal.ReleaseComObject(pFeatureCursor);
//            //if (iFeature != null) Marshal.ReleaseComObject(iFeature);
//            if (iFeatureGeom != null) Marshal.ReleaseComObject(iFeatureGeom);
//            if (source != null) Marshal.ReleaseComObject(source);

//            if (resultArmJuncs != null)
//            {
//                tracer.StartTrace("Serialize data");
//                string[] str = new string[4];
//                str[0] = resultArmJuncs.getXML();
//                str[1] = resultAbonJuncs.getXML();
//                str[2] = resPoints.getXML();
//                if (strError != "")
//                    str[3] = strError;
//                tracer.StopTrace();
//                tracer.StopTrace();
//                System.Diagnostics.Trace.WriteLine(tracer.getMessage());
//                System.Diagnostics.Trace.WriteLine(statTracer.getAllStatistic());
//                //return resultArmJuncs.getXML();
//                return str;
//            }
//            else { tracer.StopTrace(); return null; }
//            //if (resultAbonJuncs != null) return resultAbonJuncs.getXML();
//            //else return null;
//        }

//        private static IFeature FindFeature(double SearchTol, IPoint pPoint, IFeatureClass pFeatureClass)
//        {
//            ISpatialFilter pSpatialFilter;
//            IFeatureCursor pFCursor;
//            IEnvelope pEnv;
//            ISpatialReference spRef;

//            IGeoDataset pGeoDataset = (IGeoDataset)pFeatureClass;
//            spRef = pGeoDataset.SpatialReference;
//            pEnv = pPoint.Envelope;
//            pEnv.Expand(SearchTol, SearchTol, false);
//            pSpatialFilter = new SpatialFilter();
//            pSpatialFilter.Geometry = pEnv;
//            pSpatialFilter.set_OutputSpatialReference(pFeatureClass.ShapeFieldName, spRef);
//            pSpatialFilter.GeometryField = pFeatureClass.ShapeFieldName;
//            pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelRelation;
//            pSpatialFilter.SpatialRelDescription = "T********";
//            pFCursor = pFeatureClass.Search(pSpatialFilter, false);
//            IFeature result = pFCursor.NextFeature();
//            System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
//            return result;
//        }

//        public static IGeometricNetwork OpenGeometricNetwork(string dataSetName, string featureClassName, IWorkspace m_pWorkspace)
//        {
//            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
//            IDatasetName idn;
//            IFeatureDataset ifds;

//            while ((idn = ied.Next()) != null)
//            {
//                if (idn.Name.ToLower() == dataSetName.ToLower())
//                {
//                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
//                    ifds = ifs.OpenFeatureDataset(dataSetName);
//                    IEnumDataset ied2 = ifds.Subsets;
//                    IDataset ids2;
//                    while ((ids2 = ied2.Next()) != null)
//                    {
//                        if (ids2.Name.ToLower() == featureClassName.ToLower())
//                        {
//                            return (IGeometricNetwork)ids2;
//                        }
//                    }
//                    break;
//                }
//            }
//            return null;
//        }
//    }
//}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.NetworkAnalysis;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;
using Newtonsoft.Json;

namespace GeomertyNetworkWorker
{



    public class GetNetworkArmat
    {
        public GetNetworkArmat()
        {
            Global.initializeLicenze();
        }

        public static class workLayers
        {
            public static string subscriber = "subscriber";
            public static string consumer = "consumer";
            public static string gaspipeline = "gaspipeline";
            public static string grs = "grs";
            public static string stpvalve = "stpvalve";
            public static string ArmtDataSet_Net_Junctions = "ArmtDataSet_Net_Junctions";
            public static string prg = "prg";
        }



        public static string workspace = @"C:\TestNetwork\GASArmat.gdb";
        public static string type = "esriDataSourcesGDB.FileGDBWorkspaceFactory";
        public static string datasetname = "ArmtDataSet";
        public static string geometrynetwork = "ArmtDataSet_Net";


        private ArmatJunctions resultArmJuncs;
        private AbonJunctions resultAbonJuncs;
        private ArmatJunctions resPoints;
        private IFeatureClass subscriber;
        private IFeatureClass consumer;
        private IFeatureClass gaspipeline;
        private IFeatureClass grs;
        private IFeatureClass stpvalve;
        private IFeatureClass prg;
        private IFeatureClass ArmtDataSet_Net_Junctions;
        private IUtilityNetwork utilityNetwork;

        private IWorkspace OpenWorkspace(string workspace, string type)
        {
            IWorkspace m_pWorkspace;
            try
            {
                Type factoryType = Type.GetTypeFromProgID(type);
                IWorkspaceFactory pAccessFactory = (IWorkspaceFactory)Activator.CreateInstance(factoryType);
                m_pWorkspace = pAccessFactory.OpenFromFile(workspace, 0);
            }
            catch (Exception)
            {
                return null;
            }
            return m_pWorkspace;
        }

        public void OpenFeatureClass(string dataSetName, ref IFeatureClass subscriber, ref IFeatureClass consumer, ref IFeatureClass gaspipeline, ref IFeatureClass grs, ref IFeatureClass ArmtDataSet_Net_Junctions, ref IFeatureClass stpvalve, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {

                        if (ids2.Name == workLayers.grs)
                        {
                            grs = (IFeatureClass)ids2;
                            continue;
                        }

                        if (ids2.Name == workLayers.subscriber)
                        {
                            subscriber = (IFeatureClass)ids2;
                            continue;
                        }

                        if (ids2.Name == workLayers.gaspipeline)
                        {
                            gaspipeline = (IFeatureClass)ids2;
                            continue;
                        }

                        if (ids2.Name == workLayers.ArmtDataSet_Net_Junctions)
                        {
                            ArmtDataSet_Net_Junctions = (IFeatureClass)ids2;
                            continue;
                        }

                        if (ids2.Name == workLayers.consumer)
                        {
                            consumer = (IFeatureClass)ids2;
                            continue;
                        }

                        if (ids2.Name == workLayers.stpvalve)
                        {
                            stpvalve = (IFeatureClass)ids2;
                            continue;
                        }
                        if (ids2.Name == workLayers.prg)
                        {
                            prg = (IFeatureClass)ids2;
                            continue;
                        }
                        #region old

                        #endregion
                    }
                    //break;
                }
            }
        }

        public string[] CreateFullGeometricNetwork(int x, int y, string layer, string JIDs)
        {
            if (JIDs == null)
                JIDs = "";
            //                                          C:\TestNetwork
            //IWorkspace m_pWorkspace = OpenWorkspace(@"D:\GASRB\GASArmat.gdb", "esriDataSourcesGDB.SdeWorkspaceFactory");
            IWorkspace m_pWorkspace = OpenWorkspace(@workspace, type);
            OpenFeatureClass(datasetname, ref subscriber, ref consumer, ref gaspipeline, ref grs, ref ArmtDataSet_Net_Junctions, ref stpvalve, m_pWorkspace);
            IGeometricNetwork geomNet = OpenGeometricNetwork(datasetname, geometrynetwork, m_pWorkspace);
            INetwork net = geomNet.Network;

            utilityNetwork = net as IUtilityNetwork;
            SecondaryTracerArmatura secondaryTracer = new SecondaryTracerArmatura();
            resultArmJuncs = new ArmatJunctions();
            resultAbonJuncs = new AbonJunctions();
            resPoints = new ArmatJunctions();
            IPoint originalPoint = new Point();
            originalPoint.X = x;
            originalPoint.Y = y;
            IFeature iFeatureGeom = null;
            try
            {
                if (layer == "gaspipeline") iFeatureGeom = FindFeature(3.1, originalPoint, gaspipeline);
            }
            catch (Exception ex)
            {

            }
            int[] junction = new int[2];
            //int sourceEID1 = 0;
            //int sourceEID2 = 0;
            int armaturaClassID = 0;
            int consumerClassID = 0;
            int subsciberClassID = 0;
            int grsClassID = 0;
            int junctionClassID = 0;
            int prgClassID = 0;

            List<int> intJIDs = new List<int>();
            int[] arrJIDs;
            IPointCollection source = null;
            IPoint medianPoint = null;
            IPoint realPoint = null;
            IPolyline poly = null;

            if (iFeatureGeom != null)
            {

                source = (IPointCollection)iFeatureGeom.Shape;
                poly = (IPolyline)iFeatureGeom.Shape;
                medianPoint = new Point();
                realPoint = new Point();

                medianPoint.X = source.get_Point(0).X;
                medianPoint.Y = source.get_Point(0).Y;

                //sourceEID1 = geomNet.get_JunctionElement(medianPoint);
                junction[0] = geomNet.get_JunctionElement(medianPoint);
                //realPoint.X = (source.get_Point(0).X + source.get_Point(1).X)/2;
                //realPoint.Y = (source.get_Point(0).Y + source.get_Point(1).Y)/2;
                double distAlongcurve = 0;
                double distFromcurve = 0;
                bool bRightSide = true;
                IPoint outpoint = new Point();
                poly.QueryPointAndDistance(esriSegmentExtension.esriExtendEmbedded, originalPoint, true, outpoint, ref distAlongcurve, ref distFromcurve, ref bRightSide);

                realPoint = outpoint;

                medianPoint.X = source.get_Point(source.PointCount - 1).X;
                medianPoint.Y = source.get_Point(source.PointCount - 1).Y;
                //sourceEID2 = geomNet.get_JunctionElement(medianPoint);
                junction[1] = geomNet.get_JunctionElement(medianPoint);

                //JIDs = "76523;48264;78541;";


                arrJIDs = new int[JIDs.Split(';').Length];

                for (int i = 0; i < JIDs.Split(';').Length; i++)
                {
                    string tmp = JIDs.Split(';')[i];
                    if (tmp != "")
                        arrJIDs[i] = (int.Parse(tmp));
                }




                armaturaClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.stpvalve, m_pWorkspace);
                consumerClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.consumer, m_pWorkspace);
                subsciberClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.subscriber, m_pWorkspace);
                grsClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.grs, m_pWorkspace);
                junctionClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.ArmtDataSet_Net_Junctions, m_pWorkspace);
                prgClassID = SecondaryTracerArmatura.ClassIDFromName(workLayers.prg, m_pWorkspace);
                secondaryTracer = new SecondaryTracerArmatura(armaturaClassID, consumerClassID, subsciberClassID, grsClassID, junctionClassID, prgClassID, ref geomNet);
                //secondaryTracer.BeginTrace(sourceEID1, sourceEID2);

                if (JIDs == "")
                    secondaryTracer.ATrace(junction, geomNet.get_EdgeElement(realPoint));
                else secondaryTracer.ATrace(junction, geomNet.get_EdgeElement(realPoint), arrJIDs);


                for (int i = 0; i < secondaryTracer.ArmaturaJunctions.junctions.Count; i++)
                {
                    resultArmJuncs.Add(secondaryTracer.ArmaturaJunctions.junctions[i].EID);
                }
                for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
                {

                    resultAbonJuncs.Add(secondaryTracer.AbonentJunctions.junctions[i].EID);
                }

                for (int i = 0; i < secondaryTracer.SGMEDGE.Count; i++)
                {
                    resPoints.Add(secondaryTracer.SGMEDGE.junctions[i].EID);
                }


            }

            # region Заполнение атрибутики по задвижке
            if (secondaryTracer.ArmaturaJunctions != null)
                for (int i = 0; i < secondaryTracer.ArmaturaJunctions.junctions.Count; i++)
                {
                    IGeometry geom = geomNet.get_GeometryForJunctionEID(secondaryTracer.ArmaturaJunctions.junctions[i].EID);

                    IPoint point = geom as IPoint;
                    //Находим потребителя
                    ISpatialFilter pSpatialFilter2;
                    IFeatureCursor pFCursor2;
                    pSpatialFilter2 = new SpatialFilter();
                    pSpatialFilter2.Geometry = geom;
                    pSpatialFilter2.set_OutputSpatialReference(stpvalve.ShapeFieldName, ((IGeoDataset)stpvalve).SpatialReference);
                    pSpatialFilter2.GeometryField = stpvalve.ShapeFieldName;
                    pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursor2 = stpvalve.Search(pSpatialFilter2, false);
                    IFeature result2 = pFCursor2.NextFeature();
                    //Берем атрибуты
                    while (result2 != null)
                    {
                        //resultArmJuncs.junctions[i].objectid = result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString();
                        if (result2.Fields.FindField("REGION") != -1)
                            if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
                                resultArmJuncs.junctions[i].raion = (result2.get_Value(result2.Fields.FindField("REGION"))).ToString();
                        if (result2.Fields.FindField("TYPE") != -1)
                            if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
                                resultArmJuncs.junctions[i].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
                        if (result2.Fields.FindField("NAME") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
                                resultArmJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("NAME"))).ToString();
                        //if (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString().Length != 0)
                        //resultArmJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString());

                        resultArmJuncs.junctions[i].X = point.X;
                        resultArmJuncs.junctions[i].Y = point.Y;
                        result2 = pFCursor2.NextFeature();
                    }

                    for (int z = 0; z < secondaryTracer.ArmaturaJunctions.junctions.Count; z++)
                    {
                        IGeometry geom2 = geomNet.get_GeometryForJunctionEID(secondaryTracer.ArmaturaJunctions.junctions[z].EID);

                        IPoint point2 = geom2 as IPoint;
                        //Находим потребителя
                        ISpatialFilter pSpatFilter;
                        IFeatureCursor pFCursor;
                        pSpatFilter = new SpatialFilter();
                        pSpatFilter.Geometry = geom2;
                        pSpatFilter.set_OutputSpatialReference(prg.ShapeFieldName, ((IGeoDataset)prg).SpatialReference);
                        pSpatFilter.GeometryField = prg.ShapeFieldName;
                        pSpatFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                        //pSpatialFilter.SpatialRelDescription = "T********";
                        pFCursor = prg.Search(pSpatFilter, false);
                        IFeature result3 = pFCursor.NextFeature();
                        //Берем атрибуты
                        while (result3 != null)
                        {
                            //resultArmJuncs.junctions[i].objectid = result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString();
                            if (result3.Fields.FindField("REGION") != -1)
                                if (result3.get_Value(result3.Fields.FindField("REGION")).ToString().Length != 0)
                                    resultArmJuncs.junctions[z].raion = (result3.get_Value(result3.Fields.FindField("REGION"))).ToString();
                            if (result3.Fields.FindField("TYPE") != -1)
                                if (result3.get_Value(result3.Fields.FindField("TYPE")).ToString().Length != 0)
                                    resultArmJuncs.junctions[z].type = (result3.get_Value(result3.Fields.FindField("TYPE"))).ToString();
                            if (result3.Fields.FindField("NAME") != -1)
                                if (result3.get_Value(result3.Fields.FindField("NAME")).ToString().Length != 0)
                                    resultArmJuncs.junctions[z].name = (result3.get_Value(result3.Fields.FindField("NAME"))).ToString();
                            //if (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString().Length != 0)
                            //resultArmJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("OBJECTID")).ToString());

                            resultArmJuncs.junctions[z].X = point2.X;
                            resultArmJuncs.junctions[z].Y = point2.Y;
                            result3 = pFCursor.NextFeature();
                        }
                    }

                    Marshal.ReleaseComObject(pSpatialFilter2);
                    Marshal.ReleaseComObject(pFCursor2);
                    if (result2 != null)
                        Marshal.ReleaseComObject(result2);
                }
            # endregion

            #region Газопровод
            string strError = "";
            try
            {

                for (int i = 0; i < secondaryTracer.SGMEDGE.junctions.Count; i++)
                {
                    IGeometry mygeom;
                    IPolyline pline;

                    //IGeometry geom = geomNet.get_GeometryForJunctionEID(secondaryTracer.ArmaturaJunctions.junctions[i].EID);
                    try
                    {
                        mygeom = geomNet.get_GeometryForEdgeEID(secondaryTracer.SGMEDGE.junctions[i].EID);


                    }
                    catch (COMException xc)
                    {

                        mygeom = geomNet.get_GeometryForEdgeEID(secondaryTracer.SGMEDGE.junctions[0].EID);

                        strError = "Обнаружена ошибка в исходных данных! Проверьте сеть! Результаты, выданные системой, могут быть некорректны.";
                    }
                    IPointCollection ipcollection = mygeom as IPointCollection;

                    pline = mygeom as IPolyline;

                    ISpatialFilter pSpatialFilterPLine;
                    IFeatureCursor pFCursorPline;
                    pSpatialFilterPLine = new SpatialFilter();
                    pSpatialFilterPLine.Geometry = mygeom;
                    pSpatialFilterPLine.set_OutputSpatialReference(gaspipeline.ShapeFieldName, ((IGeoDataset)gaspipeline).SpatialReference);
                    pSpatialFilterPLine.GeometryField = gaspipeline.ShapeFieldName;
                    pSpatialFilterPLine.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursorPline = gaspipeline.Search(pSpatialFilterPLine, false);
                    IFeature Iresult = pFCursorPline.NextFeature();
                    #region code

                    while (Iresult != null)
                    {

                        if (Iresult.Fields.FindField("NAME") != -1)
                            if (Iresult.get_Value(Iresult.Fields.FindField("NAME")).ToString().Length != 0)
                                resPoints.junctions[i].name = (Iresult.get_Value(Iresult.Fields.FindField("NAME"))).ToString();
                        if (Iresult.Fields.FindField("DIAMETERNOMINAL") != -1)
                            if (Iresult.get_Value(Iresult.Fields.FindField("DIAMETERNOMINAL")).ToString().Length != 0)
                            {
                                int fieldNumber = Iresult.Fields.FindField("DIAMETERNOMINAL");
                                int domainCode = Convert.ToInt16(Iresult.get_Value(fieldNumber));
                                IDomain domain = Iresult.Fields.get_Field(fieldNumber).Domain;
                                ICodedValueDomain codeVDomain = domain as ICodedValueDomain;
                                List<string> codeN = new List<string>();
                                List<string> codeV = new List<string>();


                                for (int zz = 0; zz < codeVDomain.CodeCount; zz++)
                                {
                                    codeN.Add(codeVDomain.get_Name(zz));

                                    codeV.Add(codeVDomain.get_Value(zz).ToString());
                                }



                                try
                                {

                                    for (int val = 0; val < codeVDomain.CodeCount; val++)
                                    {
                                        if (Convert.ToInt16(codeV[val]) == domainCode)
                                        {
                                            resPoints.junctions[i].Diameter = CalculateGasReserve.convertToMeter(Convert.ToDouble(codeN[val]));

                                        }
                                    }

                                }
                                catch (Exception ex)
                                {
                                    strError = "Ошибка в исходных данных! OID газопровода : " + Iresult.OID.ToString();

                                }
                            }
                        resPoints.junctions[i].StartTemperature = 280.15;
                        resPoints.junctions[i].EndTemperature = 281.15;
                        resPoints.junctions[i].GroundTemperature = 293.15;
                        if (Iresult.Fields.FindField("LENGTHPART") != -1)
                            if (Iresult.get_Value(Iresult.Fields.FindField("LENGTHPART")).ToString().Length != 0)
                                resPoints.junctions[i].Length = Convert.ToDouble(Iresult.get_Value(Iresult.Fields.FindField("LENGTHPART")));
                        if (Iresult.Fields.FindField("PRESSUREFACT") != -1)
                            if (Iresult.get_Value(Iresult.Fields.FindField("PRESSUREFACT")).ToString().Length != 0)
                            {
                                resPoints.junctions[i].StartPressure = Convert.ToDouble(Iresult.get_Value(Iresult.Fields.FindField("PRESSUREFACT")));
                                resPoints.junctions[i].EndPressure = Convert.ToDouble(Iresult.get_Value(Iresult.Fields.FindField("PRESSUREFACT")));
                            }

                        // ыыыы
                        double cStartTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].StartTemperature);
                        double cEndTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].EndTemperature);
                        double cGroundTemperature = CalculateGasReserve.convertToCelsius(resPoints.junctions[i].GroundTemperature);

                        double middleTemperature = CalculateGasReserve.calculateMiddleTemperature(cStartTemperature, cEndTemperature, cGroundTemperature);
                        //double mDiameter = CalculateGasReserve.convertToMeter(resPoints.junctions[i].Diameter);
                        double mDiameter = resPoints.junctions[i].Diameter;
                        double Volume = CalculateGasReserve.calculateVolume(mDiameter, resPoints.junctions[i].Length);
                        double kgscmStartPressure = CalculateGasReserve.convertFromMPaToKGS_CM2(resPoints.junctions[i].StartPressure);
                        double kgscmEndPressure = CalculateGasReserve.convertFromMPaToKGS_CM2(resPoints.junctions[i].EndPressure);
                        double middlePressure = CalculateGasReserve.calculateFactMiddlePressure(kgscmStartPressure, kgscmEndPressure);
                        //double cmiddlePressure = CalculateGasReserve.convertFromKGS_CM2ToMPa(middlePressure);
                        if (middlePressure > 10)
                        {
                            double absMiddlePressure = CalculateGasReserve.calculateAbsMiddlePressure(middlePressure);
                            double gascompfactor = CalculateGasReserve.calculateGasCompressFactor(middleTemperature, absMiddlePressure);
                            resPoints.junctions[i].GasReserve = CalculateGasReserve.calculateGasReserve(Volume, absMiddlePressure, gascompfactor, middleTemperature);
                        }
                        else if (middlePressure < 10)
                        {
                            double absMiddlePressure = CalculateGasReserve.calculateAbsMiddlePressure(middlePressure);
                            resPoints.junctions[i].GasReserve = CalculateGasReserve.calculateGasReserve(Volume, absMiddlePressure, 1, middleTemperature);
                        }



                        Iresult = pFCursorPline.NextFeature();
                    }


                    #endregion
                    string temp = "";

                    for (int z = 0; z < ipcollection.PointCount; z++)
                    {
                        double xP = ipcollection.Point[z].X;
                        double yP = ipcollection.Point[z].Y;
                        temp = temp + (xP + "|" + yP + ";");


                    }

                    resPoints.junctions[i].EID = i;
                    resPoints.junctions[i].Points = temp;

                }
            }
            catch (Exception ex)
            {

                strError = "Обнаружена ошибка в исходных данных! Проверьте сеть! Результаты, выданные системой, могут быть некорректны.";
            }
            #endregion



            # region Заполнение атрибутики по абонентам
            if (secondaryTracer.AbonentJunctions != null)
                for (int i = 0; i < secondaryTracer.AbonentJunctions.junctions.Count; i++)
                {
                    IGeometry geom = geomNet.get_GeometryForJunctionEID(secondaryTracer.AbonentJunctions.junctions[i].EID);

                    IPoint point = geom as IPoint;
                    //Находим потребителя
                    ISpatialFilter pSpatialFilter2;
                    IFeatureCursor pFCursor2;
                    pSpatialFilter2 = new SpatialFilter();
                    pSpatialFilter2.Geometry = geom;
                    pSpatialFilter2.set_OutputSpatialReference(consumer.ShapeFieldName, ((IGeoDataset)consumer).SpatialReference);
                    pSpatialFilter2.GeometryField = consumer.ShapeFieldName;
                    pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursor2 = consumer.Search(pSpatialFilter2, false);
                    IFeature result2 = pFCursor2.NextFeature();
                    //Берем атрибуты
                    if (result2 != null)
                    {
                        if (result2.Fields.FindField("NAME") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("NAME"))).ToString();
                        if (result2.Fields.FindField("BRANCH") != -1)
                            if (result2.get_Value(result2.Fields.FindField("BRANCH")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].branch = (result2.get_Value(result2.Fields.FindField("BRANCH"))).ToString();
                        if (result2.Fields.FindField("REGION") != -1)
                            if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].region = (result2.get_Value(result2.Fields.FindField("REGION"))).ToString();
                        if (result2.Fields.FindField("OTRASL") != -1)
                            if (result2.get_Value(result2.Fields.FindField("OTRASL")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].otrasl = (result2.get_Value(result2.Fields.FindField("OTRASL"))).ToString();
                        if (result2.Fields.FindField("QFACTYEAR") != -1)
                            if (result2.get_Value(result2.Fields.FindField("QFACTYEAR")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].qfactyear = (result2.get_Value(result2.Fields.FindField("QFACTYEAR"))).ToString();
                        if (result2.Fields.FindField("BOILERAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("BOILERAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].boileramount = (result2.get_Value(result2.Fields.FindField("BOILERAMOUNT"))).ToString();
                        if (result2.Fields.FindField("GRU") != -1)
                            if (result2.get_Value(result2.Fields.FindField("GRU")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].gru = (result2.get_Value(result2.Fields.FindField("GRU"))).ToString();
                        if (result2.Fields.FindField("QPROJYEAR") != -1)
                            if (result2.get_Value(result2.Fields.FindField("QPROJYEAR")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].qprojyear = (result2.get_Value(result2.Fields.FindField("QPROJYEAR"))).ToString();
                        if (result2.Fields.FindField("QFACTHOUR") != -1)
                            if (result2.get_Value(result2.Fields.FindField("QFACTHOUR")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].qfacthour = (result2.get_Value(result2.Fields.FindField("QFACTHOUR"))).ToString();
                        if (result2.Fields.FindField("INLETPRESS") != -1)
                            if (result2.get_Value(result2.Fields.FindField("INLETPRESS")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].inletpress = (result2.get_Value(result2.Fields.FindField("INLETPRESS"))).ToString();
                        if (result2.Fields.FindField("OUTLETPRESS") != -1)
                            if (result2.get_Value(result2.Fields.FindField("OUTLETPRESS")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].outletpress = (result2.get_Value(result2.Fields.FindField("OUTLETPRESS"))).ToString();
                        if (result2.Fields.FindField("SETTLEMENT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("SETTLEMENT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].settlement = (result2.get_Value(result2.Fields.FindField("SETTLEMENT"))).ToString();
                        if (result2.Fields.FindField("TYPE") != -1)
                            if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
                        if (result2.Fields.FindField("REGULATOR") != -1)
                            if (result2.get_Value(result2.Fields.FindField("REGULATOR")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].regulator = (result2.get_Value(result2.Fields.FindField("REGULATOR"))).ToString();
                        if (result2.Fields.FindField("OBJ") != -1)
                            if (result2.get_Value(result2.Fields.FindField("OBJ")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].obj = (result2.get_Value(result2.Fields.FindField("OBJ"))).ToString();
                        if (result2.Fields.FindField("NN") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NN")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].nn = (result2.get_Value(result2.Fields.FindField("NN"))).ToString();
                        if (result2.Fields.FindField("NDOGOVOR") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NDOGOVOR")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].ndogovor = (result2.get_Value(result2.Fields.FindField("NDOGOVOR"))).ToString();
                        if (result2.Fields.FindField("PZK") != -1)
                            if (result2.get_Value(result2.Fields.FindField("PZK")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].pzk = (result2.get_Value(result2.Fields.FindField("PZK"))).ToString();
                        if (result2.Fields.FindField("PSK") != -1)
                            if (result2.get_Value(result2.Fields.FindField("PSK")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].psk = (result2.get_Value(result2.Fields.FindField("PSK"))).ToString();
                        if (result2.Fields.FindField("BRAND") != -1)
                            if (result2.get_Value(result2.Fields.FindField("BRAND")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].brand = (result2.get_Value(result2.Fields.FindField("BRAND"))).ToString();
                        if (result2.Fields.FindField("OBORUD") != -1)
                            if (result2.get_Value(result2.Fields.FindField("OBORUD")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].oborud = (result2.get_Value(result2.Fields.FindField("OBORUD"))).ToString();
                        if (result2.Fields.FindField("GRS") != -1)
                            if (result2.get_Value(result2.Fields.FindField("GRS")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].grs = (result2.get_Value(result2.Fields.FindField("GRS"))).ToString();
                        if (result2.Fields.FindField("GRSLINES") != -1)
                            if (result2.get_Value(result2.Fields.FindField("GRSLINES")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].grslines = (result2.get_Value(result2.Fields.FindField("GRSLINES"))).ToString();
                        if (result2.Fields.FindField("USELUCHET") != -1)
                            if (result2.get_Value(result2.Fields.FindField("USELUCHET")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].useluchet = (result2.get_Value(result2.Fields.FindField("USELUCHET"))).ToString();
                        if (result2.Fields.FindField("SEZON") != -1)
                            if (result2.get_Value(result2.Fields.FindField("SEZON")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].sezon = (result2.get_Value(result2.Fields.FindField("SEZON"))).ToString();
                        if (result2.Fields.FindField("DURATION") != -1)
                            if (result2.get_Value(result2.Fields.FindField("DURATION")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].duration = (result2.get_Value(result2.Fields.FindField("DURATION"))).ToString();
                        if (result2.Fields.FindField("INN") != -1)
                            if (result2.get_Value(result2.Fields.FindField("INN")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].inn = (result2.get_Value(result2.Fields.FindField("INN"))).ToString();
                        if (result2.Fields.FindField("KPP") != -1)
                            if (result2.get_Value(result2.Fields.FindField("KPP")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].kpp = (result2.get_Value(result2.Fields.FindField("KPP"))).ToString();
                        if (result2.Fields.FindField("UPDATES") != -1)
                            if (result2.get_Value(result2.Fields.FindField("UPDATES")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].updates = (result2.get_Value(result2.Fields.FindField("UPDATES"))).ToString();

                        resultAbonJuncs.junctions[i].X = point.X;
                        resultAbonJuncs.junctions[i].Y = point.Y;
                    }

                    pSpatialFilter2 = new SpatialFilter();
                    pSpatialFilter2.Geometry = geom;
                    pSpatialFilter2.set_OutputSpatialReference(subscriber.ShapeFieldName, ((IGeoDataset)subscriber).SpatialReference);
                    pSpatialFilter2.GeometryField = subscriber.ShapeFieldName;
                    pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
                    //pSpatialFilter.SpatialRelDescription = "T********";
                    pFCursor2 = subscriber.Search(pSpatialFilter2, false);
                    result2 = null;
                    result2 = pFCursor2.NextFeature();
                    //Берем атрибуты
                    if (result2 != null)
                    {
                        if (result2.Fields.FindField("NAME") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NAME")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].name = (result2.get_Value(result2.Fields.FindField("NAME"))).ToString();
                        if (result2.Fields.FindField("BRANCH") != -1)
                            if (result2.get_Value(result2.Fields.FindField("BRANCH")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].branch = (result2.get_Value(result2.Fields.FindField("BRANCH"))).ToString();
                        if (result2.Fields.FindField("REGION") != -1)
                            if (result2.get_Value(result2.Fields.FindField("REGION")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].region = (result2.get_Value(result2.Fields.FindField("REGION"))).ToString();
                        if (result2.Fields.FindField("ORGANIZATION") != -1)
                            if (result2.get_Value(result2.Fields.FindField("ORGANIZATION")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].organization = (result2.get_Value(result2.Fields.FindField("ORGANIZATION"))).ToString();
                        if (result2.Fields.FindField("CODE") != -1)
                            if (result2.get_Value(result2.Fields.FindField("CODE")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].code = (result2.get_Value(result2.Fields.FindField("CODE"))).ToString();
                        if (result2.Fields.FindField("VALVEAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("VALVEAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].valveamont = (result2.get_Value(result2.Fields.FindField("VALVEAMOUNT"))).ToString();
                        //resultAbonJuncs.junctions[i].valveamont = (string)(result2.get_Value(result2.Fields.FindField("VALVEAMOUNT")));
                        if (result2.Fields.FindField("CONSUMERAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("CONSUMERAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].consumeramount = (result2.get_Value(result2.Fields.FindField("CONSUMERAMOUNT"))).ToString();
                        if (result2.Fields.FindField("FRYERAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("FRYERAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].fryeramount = (result2.get_Value(result2.Fields.FindField("FRYERAMOUNT"))).ToString();
                        if (result2.Fields.FindField("NSWATERHEATERAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("NSWATERHEATERAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].nswaterheateramount = (result2.get_Value(result2.Fields.FindField("NSWATERHEATERAMOUNT"))).ToString();
                        if (result2.Fields.FindField("SWATERHEATERAMOUNT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("SWATERHEATERAMOUNT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].swaterheateramount = (result2.get_Value(result2.Fields.FindField("SWATERHEATERAMOUNT"))).ToString();
                        if (result2.Fields.FindField("HCONSUMPTIONFACTMAX") != -1)
                            if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMAX")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].hconsumptionfactmax = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMAX"))).ToString();
                        if (result2.Fields.FindField("HCONSUMPTIONFACTMIN") != -1)
                            if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMIN")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].hconsumptionfactmin = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONFACTMIN"))).ToString();
                        if (result2.Fields.FindField("SETTLEMENT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("SETTLEMENT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].settlement = (result2.get_Value(result2.Fields.FindField("SETTLEMENT"))).ToString();
                        if (result2.Fields.FindField("TYPE") != -1)
                            if (result2.get_Value(result2.Fields.FindField("TYPE")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].type = (result2.get_Value(result2.Fields.FindField("TYPE"))).ToString();
                        if (result2.Fields.FindField("SETTLEMENTDISTRICT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("SETTLEMENTDISTRICT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].settlementdistrict = (result2.get_Value(result2.Fields.FindField("SETTLEMENTDISTRICT"))).ToString();
                        if (result2.Fields.FindField("HCONSUMPTIONPRJ") != -1)
                            if (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONPRJ")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].hconsumptionprj = (result2.get_Value(result2.Fields.FindField("HCONSUMPTIONPRJ"))).ToString();
                        if (result2.Fields.FindField("YCONSUMPTIONFACT") != -1)
                            if (result2.get_Value(result2.Fields.FindField("YCONSUMPTIONFACT")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].yconsumptionfact = (result2.get_Value(result2.Fields.FindField("YCONSUMPTIONFACT"))).ToString();
                        if (result2.Fields.FindField("HOUSENUMBER") != -1)
                            if (result2.get_Value(result2.Fields.FindField("HOUSENUMBER")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].housenumber = (result2.get_Value(result2.Fields.FindField("HOUSENUMBER"))).ToString();
                        if (result2.Fields.FindField("STREET") != -1)
                            if (result2.get_Value(result2.Fields.FindField("STREET")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].street = (result2.get_Value(result2.Fields.FindField("STREET"))).ToString();
                        if (result2.Fields.FindField("gasconsfacthour") != -1)
                            if (result2.get_Value(result2.Fields.FindField("gasconsfacthour")).ToString().Length != 0)
                                resultAbonJuncs.junctions[i].qfacthour = (result2.get_Value(result2.Fields.FindField("gasconsfacthour"))).ToString();

                        resultAbonJuncs.junctions[i].X = point.X;
                        resultAbonJuncs.junctions[i].Y = point.Y;
                    }

                    Marshal.ReleaseComObject(pSpatialFilter2);
                    Marshal.ReleaseComObject(pFCursor2);
                    if (result2 != null)
                        Marshal.ReleaseComObject(result2);
                }
            # endregion


            if (m_pWorkspace != null) Marshal.ReleaseComObject(m_pWorkspace);
            if (grs != null) Marshal.ReleaseComObject(grs);
            if (subscriber != null) Marshal.ReleaseComObject(subscriber);
            if (gaspipeline != null) Marshal.ReleaseComObject(gaspipeline);
            if (ArmtDataSet_Net_Junctions != null) Marshal.ReleaseComObject(ArmtDataSet_Net_Junctions);
            if (utilityNetwork != null) Marshal.ReleaseComObject(utilityNetwork);
            if (geomNet != null) Marshal.ReleaseComObject(geomNet);
            if (net != null) Marshal.ReleaseComObject(net);
            //if (secondaryTracer != null) Marshal.ReleaseComObject(secondaryTracer);
            //if (pQueryFilter != null) Marshal.ReleaseComObject(pQueryFilter);
            //if (pFeatureCursor != null) Marshal.ReleaseComObject(pFeatureCursor);
            //if (iFeature != null) Marshal.ReleaseComObject(iFeature);
            if (iFeatureGeom != null) Marshal.ReleaseComObject(iFeatureGeom);
            if (source != null) Marshal.ReleaseComObject(source);

            if (resultArmJuncs != null)
            {
                string[] str = new string[4];
                str[0] = resultArmJuncs.getXML();
                str[1] = resultAbonJuncs.getXML();
                str[2] = resPoints.getXML();
                if (strError != "")
                    str[3] = strError;
                //return resultArmJuncs.getXML();
                return str;
            }
            else return null;
            //if (resultAbonJuncs != null) return resultAbonJuncs.getXML();
            //else return null;


        }

        private static IFeature FindFeature(double SearchTol, IPoint pPoint, IFeatureClass pFeatureClass)
        {
            ISpatialFilter pSpatialFilter;
            IFeatureCursor pFCursor;
            IEnvelope pEnv;
            ISpatialReference spRef;

            IGeoDataset pGeoDataset = (IGeoDataset)pFeatureClass;
            spRef = pGeoDataset.SpatialReference;
            pEnv = pPoint.Envelope;
            pEnv.Expand(SearchTol, SearchTol, false);
            pSpatialFilter = new SpatialFilter();
            pSpatialFilter.Geometry = pEnv;
            pSpatialFilter.set_OutputSpatialReference(pFeatureClass.ShapeFieldName, spRef);
            pSpatialFilter.GeometryField = pFeatureClass.ShapeFieldName;
            pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelRelation;
            pSpatialFilter.SpatialRelDescription = "T********";
            pFCursor = pFeatureClass.Search(pSpatialFilter, false);
            IFeature result = pFCursor.NextFeature();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
            return result;
        }

        public static IGeometricNetwork OpenGeometricNetwork(string dataSetName, string featureClassName, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {
                        if (ids2.Name.ToLower() == featureClassName.ToLower())
                        {
                            return (IGeometricNetwork)ids2;
                        }
                    }
                    break;
                }
            }
            return null;
        }
    }
}

