﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace GeomertyNetworkWorker
{
    public class AbonJunction
    {        
        [XmlElement("eid")]
        public int EID
        {
            get { return _eid; }
            set {_eid = value;}
        }

        [XmlElement("parentedgeeid")]
        public int ParentEdgeEID
        {
            get { return _parentEdgeEID; }
            set { _parentEdgeEID = value; }
        }

        [XmlElement("classid")]
        public int ClassID
        {
            get { return _classID; }
            set { _classID = value; }
        }

        [XmlElement("parenteid")]
        public int ParentEID
        {
            get { return _parentEID; }
            set { _parentEID = value; }
        }

        [XmlElement("numedges")]
        public int NumEdges
        {
            get { return _numEdges; }
            set { _numEdges = value; }
        }

        [XmlElement("numchildjunctions")]
        public int NumChildJunctions
        {
            get { return _numChildJunctions; }
            set { _numChildJunctions = value; }
        }
        
        [XmlElement("name")]
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        [XmlElement("branch")]
        public string branch
        {
            get { return _branch; }
            set { _branch = value; }
        }
        
        [XmlElement("region")]
        public string region
        {
            get { return _region; }
            set { _region = value; }
        }

        [XmlElement("organization")]
        public string organization
        {
            get { return _organization; }
            set { _organization = value; }
        }

        [XmlElement("code")]
        public string code
        {
            get { return _code; }
            set { _code = value; }
        }

        [XmlElement("valveamont")]
        public string valveamont
        {
            get { return _valveamont; }
            set { _valveamont = value; }
        }

        [XmlElement("consumeramount")]
        public string consumeramount
        {
            get { return _consumeramount; }
            set { _consumeramount = value; }
        }

        [XmlElement("fryeramount")]
        public string fryeramount
        {
            get { return _fryeramount; }
            set { _fryeramount = value; }
        }

        [XmlElement("nswaterheateramount")]
        public string nswaterheateramount
        {
            get { return _nswaterheateramount; }
            set { _nswaterheateramount = value; }
        }

        [XmlElement("swaterheateramount")]
        public string swaterheateramount
        {
            get { return _swaterheateramount; }
            set { _swaterheateramount = value; }
        }

        [XmlElement("hconsumptionfactmax")]
        public string hconsumptionfactmax
        {
            get { return _hconsumptionfactmax; }
            set { _hconsumptionfactmax = value; }
        }

        [XmlElement("hconsumptionfactmin")]
        public string hconsumptionfactmin
        {
            get { return _hconsumptionfactmin; }
            set { _hconsumptionfactmin = value; }
        }

        [XmlElement("otrasl")]
        public string otrasl
        {
            get { return _otrasl; }
            set { _otrasl = value; }
        }

        [XmlElement("qfactyear")]
        public string qfactyear
        {
            get { return _qfactyear; }
            set { _qfactyear = value; }
        }

        [XmlElement("boileramount")]
        public string boileramount
        {
            get { return _boileramount; }
            set { _boileramount = value; }
        }

        [XmlElement("gru")]
        public string gru
        {
            get { return _gru; }
            set { _gru = value; }
        }

        [XmlElement("qprojyear")]
        public string qprojyear
        {
            get { return _qprojyear; }
            set { _qprojyear = value; }
        }

        [XmlElement("qfacthour")]
        public string qfacthour
        {
            get { return _qfacthour; }
            set { _qfacthour = value; }
        }

        [XmlElement("qprjhour")]
        public string qprjhour
        {
            get { return _qprjhour; }
            set { _qprjhour = value; }
        }

        [XmlElement("inletpress")]
        public string inletpress
        {
            get { return _inletpress; }
            set { _inletpress = value; }
        }

        [XmlElement("outletpress")]
        public string outletpress
        {
            get { return _outletpress; }
            set { _outletpress = value; }
        }

        [XmlElement("settlement")]
        public string settlement
        {
            get { return _settlement; }
            set { _settlement = value; }
        }

        [XmlElement("type")]
        public string type
        {
            get { return _type; }
            set { _type = value; }
        }

        [XmlElement("settlementdistrict")]
        public string settlementdistrict
        {
            get { return _settlementdistrict; }
            set { _settlementdistrict = value; }
        }

        [XmlElement("hconsumptionprj")]
        public string hconsumptionprj
        {
            get { return _hconsumptionprj; }
            set { _hconsumptionprj = value; }
        }

        [XmlElement("yconsumptionfact")]
        public string yconsumptionfact
        {
            get { return _yconsumptionfact; }
            set { _yconsumptionfact = value; }
        }

        [XmlElement("housenumber")]
        public string housenumber
        {
            get { return _housenumber; }
            set { _housenumber = value; }
        }

        [XmlElement("street")]
        public string street
        {
            get { return _street; }
            set { _street = value; }
        }

        [XmlElement("regulator")]
        public string regulator
        {
            get { return _regulator; }
            set { _regulator = value; }
        }

        [XmlElement("obj")]
        public string obj
        {
            get { return _obj; }
            set { _obj = value; }
        }

        [XmlElement("nn")]
        public string nn
        {
            get { return _nn; }
            set { _nn = value; }
        }

        [XmlElement("ndogovor")]
        public string ndogovor
        {
            get { return _ndogovor; }
            set { _ndogovor = value; }
        }

        [XmlElement("pzk")]
        public string pzk
        {
            get { return _pzk; }
            set { _pzk = value; }
        }

        [XmlElement("psk")]
        public string psk
        {
            get { return _psk; }
            set { _psk = value; }
        }

        [XmlElement("brand")]
        public string brand
        {
            get { return _brand; }
            set { _brand = value; }
        }

        [XmlElement("oborud")]
        public string oborud
        {
            get { return _oborud; }
            set { _oborud = value; }
        }

        [XmlElement("grs")]
        public string grs
        {
            get { return _grs; }
            set { _grs = value; }
        }

        [XmlElement("grslines")]
        public string grslines
        {
            get { return _grslines; }
            set { _grslines = value; }
        }

        [XmlElement("useluchet")]
        public string useluchet
        {
            get { return _useluchet; }
            set { _useluchet = value; }
        }

        [XmlElement("sezon")]
        public string sezon
        {
            get { return _sezon; }
            set { _sezon = value; }
        }

        [XmlElement("duration")]
        public string duration
        {
            get { return _duration; }
            set { _duration = value; }
        }

        [XmlElement("inn")]
        public string inn
        {
            get { return _inn; }
            set { _inn = value; }
        }

        [XmlElement("kpp")]
        public string kpp
        {
            get { return _kpp; }
            set { _kpp = value; }
        }

        [XmlElement("updates")]
        public string updates
        {
            get { return _updates; }
            set { _updates = value; }
        }

        [XmlElement("x")]
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }

        [XmlElement("y")]
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }

        public AbonJunction()
        {
        }
        public AbonJunction(int eid)
        {
            _eid = eid;
        }
        public AbonJunction(int EID, int parentEdgeEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
        }
        public AbonJunction(int EID, int parentEdgeEID, int classID, int parentEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
        }
        public AbonJunction(int EID, int parentEdgeEID, int classID, int parentEID, int numEdges, string name, string branch, string region, string settlement, string type, string street, string housenumber, double x, double y)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
            _numEdges = numEdges;
            if (numEdges > 0)
            {
                _numChildJunctions = numEdges - 1;
            }
            _name = name;
            _branch = branch;
            _region = region;
            _type = type;
            _x = x;
            _y = y;
        }

        private int _eid = 0;
        private int _parentEdgeEID = 0;
        private int _classID = 0;
        private int _parentEID = 0;
        private int _numEdges = 0;
        private int _numChildJunctions = 0;
        private string _name = "";                      //  Наименование потребителя    //
        private string _branch = "";                    //  Филиал                      //  Общие
        private string _region = "";                    //  Административный район РБ   //

        private string _organization = "";              //  Управляющая компания                                                        //
        private string _code = "";                      //  Код                                                                         //
        private string _valveamont = "";                //  Количество отключаемых задвижек, кранов на вводе, подъезде, стояках         //
        private string _consumeramount = "";            //  Количество потребителей газа                                                //
        private string _fryeramount = "";               //  Количество газовых плит                                                     //  subscriber
        private string _nswaterheateramount = "";       //  Количество проточных водонагревателей                                       //
        private string _swaterheateramount = "";        //  Количество емкостных водонагревателей, отопительных котлов или горелок      //
        private string _hconsumptionfactmax = "";       //  Расход газа фактический максимальный часовой                                //
        private string _hconsumptionfactmin = "";       //  Расход газа фактический минимальный                                         //

        private string _otrasl = "";                    //  Отрасль                                     //
        private string _qfactyear = "";                 //  Расход фактический годовой тыс куб м/год    //
        private string _boileramount = "";              //  Количество котлов                           //
        private string _gru = "";                       //  Наличие ГРУ                                 //
        private string _qprojyear = "";                 //  Расход проектный годовой тыс куб м/год      //  consumer
        private string _qfacthour = "";                 //  Расход фактический часовой куб м/час        //
        private string _qprjhour = "";                  //  Расход проектный часовой тыс куб м/час      //
        private string _inletpress = "";                //  Входное давление                            //
        private string _outletpress = "";               //  Выходное давление                           //

        private string _settlement = "";                //  Населенный пункт    //  Общие
        private string _type = "";                      //  Тип                 //

        private string _settlementdistrict = "";        //  Район населенного пункта          //
        private string _hconsumptionprj = "";           //  Расход газа проектный часовой     //
        private string _yconsumptionfact = "";          //  Расход газа фактический годовой   //  subscriber
        private string _housenumber = "";               //  Номер дома                        //
        private string _street = "";                    //  Название улицы                    //

        private string _regulator = "";                 //  Регулятор давления                                 //
        private string _obj = "";                       //  Объект обслуживания                                //
        private string _nn = "";                        //  № пп                                               //
        private string _ndogovor = "";                  //  Номер договора                                     //
        private string _pzk = "";                       //  ПЗК                                                //
        private string _psk = "";                       //  ПСК                                                //
        private string _brand = "";                     //  Марка оборудования                                 //
        private string _oborud = "";                    //  Оборудование                                       //
        private string _grs = "";                       //  ГРС                                                //  consumer
        private string _grslines = "";                  //  Выходная линия ГРС                                 //
        private string _useluchet = "";                 //  Узел учета газа                                    //
        private string _sezon = "";                     //  Сезонное потребление                               //
        private string _duration = "";                  //  Продолжительность потребления (количество месяцев) //
        private string _inn = "";                       //  ИНН                                                //
        private string _kpp = "";                       //  КПП                                                //
        private string _updates = "";                   //  Дата последнего обновления                         //

        private double _x = 0;
        private double _y = 0;
    }
}
