﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.NetworkAnalysis;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;
using System.IO;

namespace GeomertyNetworkWorker
{
    public class GeometryNetworkWorker
    {
        public GeometryNetworkWorker()
        {
            Global.initializeLicenze();
        }

        public static class workLayers
        {
            public static string grs = "grs2";
            public static string prg = "prg2";
            public static string subscriber = "subscriber2";
            public static string consumer = "consumer2";
            public static string gaspipeline = "gaspipeline2";
            public static string network_Net_Junctions = "network2_Net_Junctions";
        }
        public static class workAttributes
        {
            public static Dictionary<string, string> pip = new Dictionary<string, string>();
            public static Dictionary<string, string> sub = new Dictionary<string, string>();
            public static Dictionary<string, string> con = new Dictionary<string, string>();
            public static Dictionary<string, string> prg = new Dictionary<string, string>();
            public static Dictionary<string, string> grs = new Dictionary<string, string>();

        }

        public static string pipeattr = "PRESSURECLASS";

        public static string workspace = @"C:\TestNetwork\Default.gdb";
        public static string type = "esriDataSourcesGDB.FileGDBWorkspaceFactory";
        public static string datasetname = "network2";
        public static string geometrynetwork = "network2_Net";

        private IFeatureClass grs;
        private IFeatureClass prg;
        private IFeatureClass subscriber;
        private IFeatureClass consumer;
        private IFeatureClass gaspipeline;
        private IFeatureClass network_Net_Junctions;

        private IUtilityNetwork utilityNetwork;

        private int pipelineCount = 0;

        public List<string> GetPressures(string layer, double x, double y)
        {
            //IWorkspace m_pWorkspace = OpenWorkspace("GASDB.sde", "esriDataSourcesGDB.SdeWorkspaceFactory");
            IWorkspace m_pWorkspace = OpenWorkspace(@workspace, type);

            OpenFeatureClass(datasetname, ref grs, ref prg, ref subscriber, ref gaspipeline, ref network_Net_Junctions, m_pWorkspace);

            IGeometricNetwork geomNet = OpenGeometricNetwork(datasetname, geometrynetwork, m_pWorkspace);
            INetwork net = geomNet.Network;
            utilityNetwork = net as IUtilityNetwork;

            SecondaryTracer secondaryTracer = new SecondaryTracer();

            //IForwardStar forwardStar = net.CreateForwardStar(true, null, null, null, null);                        
            //// get a list of the current EIDs for edges in the network
            //IEnumNetEID edgeEIDs = GetCurrentEIDs(esriElementType.esriETEdge, net);
            //// set the flow direction for each edge in the network
            //edgeEIDs.Reset();
            //for (int i = 0; i < edgeEIDs.Count; i++)
            //{
            //    int edgeEID = edgeEIDs.Next();
            //    utilNet.GetFlowDirection(edgeEID);
            //}
            IPoint originalPoint = new Point();
            originalPoint.X = x;
            originalPoint.Y = y; 
           
            IFeature iFeature = null;

            switch (layer)
            {
                case "grs":
                    {
                        //iFeature = FindFeature(1, originalPoint, grs);
                        int i = 1;
                        while (iFeature == null && i < 1000)
                        {
                            iFeature = FindFeature(i, originalPoint, grs);
                            i++;
                        }
                        break;
                    }
                case "prg":
                    {
                        int i = 1;
                        while (iFeature == null && i < 1000)
                        {
                            iFeature = FindFeature(i, originalPoint, prg);
                            i++;
                        }
                        break;
                    }
            }
            int sourceEID = 0;
            int prgClassID = 0;
            int subscriberClassID = 0;
            int consumerClassID = 0;
            int junctionClassID = 0;
            int grsClassID = 0;
            List<string> sourcePressure = new List<string>();
            IPoint source = null;
            if (iFeature != null)
            {
                source = (IPoint)iFeature.Shape;
                sourceEID = geomNet.get_JunctionElement(source);

                grsClassID = GetClassID(sourceEID);
                prgClassID = SecondaryTracer.ClassIDFromName(workLayers.prg, m_pWorkspace);
                subscriberClassID = SecondaryTracer.ClassIDFromName(workLayers.subscriber, m_pWorkspace);
                consumerClassID = SecondaryTracer.ClassIDFromName(workLayers.consumer, m_pWorkspace);

                junctionClassID = SecondaryTracer.ClassIDFromName(workLayers.network_Net_Junctions, m_pWorkspace);

                secondaryTracer = new SecondaryTracer(ref iFeature, prgClassID, grsClassID, subscriberClassID, consumerClassID, junctionClassID, ref gaspipeline, ref geomNet, sourcePressure, ref prg, ref subscriber, ref consumer, ref grs, ref network_Net_Junctions);
                secondaryTracer.GetPressures(sourceEID);
            }

            if (m_pWorkspace != null) Marshal.ReleaseComObject(m_pWorkspace);
            if (grs != null) Marshal.ReleaseComObject(grs);
            if (prg != null) Marshal.ReleaseComObject(prg);
            if (gaspipeline != null) Marshal.ReleaseComObject(gaspipeline);
            if (network_Net_Junctions != null) Marshal.ReleaseComObject(network_Net_Junctions);
            if (utilityNetwork != null) Marshal.ReleaseComObject(utilityNetwork);
            if (geomNet != null) Marshal.ReleaseComObject(geomNet);
            if (net != null) Marshal.ReleaseComObject(net);
            //Marshal.ReleaseComObject(secondaryTracer);
            //if (pQueryFilter != null) Marshal.ReleaseComObject(pQueryFilter);
            //if (pFeatureCursor != null) Marshal.ReleaseComObject(pFeatureCursor);
            if (iFeature != null) Marshal.ReleaseComObject(iFeature);
            if (source != null) Marshal.ReleaseComObject(source);
            return secondaryTracer.Pressures;
        }

        public string CreateFullGeometricNetwork(string layer, double x, double y, List<string> inputPressure, string path, double qip, double qif)
        {
            try
            {
                Log.UseSensibleDefaults(Guid.NewGuid().ToString(), path, eloglevel.error);
                Log.LogHeader(Log.LogName + ": Начало лога", elogheaderlevel.Level_1);
                //IWorkspace m_pWorkspace = OpenWorkspace("GASDB.sde", "esriDataSourcesGDB.SdeWorkspaceFactory");
                IWorkspace m_pWorkspace = OpenWorkspace(@workspace, type);

                OpenFeatureClass(datasetname, ref grs, ref prg, ref subscriber, ref gaspipeline, ref network_Net_Junctions, m_pWorkspace);

                IGeometricNetwork geomNet = OpenGeometricNetwork(datasetname, geometrynetwork, m_pWorkspace);
                INetwork net = geomNet.Network;
                utilityNetwork = net as IUtilityNetwork;
                
                SecondaryTracer secondaryTracer = new SecondaryTracer();

                //IForwardStar forwardStar = net.CreateForwardStar(true, null, null, null, null);                        
                //// get a list of the current EIDs for edges in the network
                //IEnumNetEID edgeEIDs = GetCurrentEIDs(esriElementType.esriETEdge, net);
                //// set the flow direction for each edge in the network
                //edgeEIDs.Reset();
                //for (int i = 0; i < edgeEIDs.Count; i++)
                //{
                //    int edgeEID = edgeEIDs.Next();
                //    utilNet.GetFlowDirection(edgeEID);
                //}
                IPoint originalPoint = new Point();
                originalPoint.X = x;
                originalPoint.Y = y;

                IFeature iFeature = null;

                switch (layer)
                {
                    case "grs":
                        {
                            //iFeature = FindFeature(1, originalPoint, grs);
                            int i = 1;
                            while (iFeature == null && i < 1000)
                            {
                                iFeature = FindFeature(i, originalPoint, grs);
                                i++;
                            }
                            break;
                        }
                    case "prg":
                        {
                            int i = 1;
                            while (iFeature == null && i < 1000)
                            {
                                iFeature = FindFeature(i, originalPoint, prg);
                                i++;
                            }
                            break;
                        }
                }
                int sourceEID = 0;
                int prgClassID = 0;
                int subscriberClassID = 0;
                int consumerClassID = 0;
                int junctionClassID = 0;
                int grsClassID = 0;
                //double sourcePressure = 0;
                IPoint source = null;
                if (iFeature != null)
                {
                    source = (IPoint)iFeature.Shape;
                    sourceEID = geomNet.get_JunctionElement(source);
                    //switch (layer)
                    //{
                    //    case "grs":
                    //        {
                    //            sourcePressure = (double)(iFeature.get_Value(iFeature.Fields.FindField("PRESSUREPRJ")));
                    //            break;
                    //        }
                    //    case "prg":
                    //        {
                    //            double.TryParse(iFeature.get_Value(iFeature.Fields.FindField("PRESSUREOUT")).ToString(), out sourcePressure);
                    //            break;
                    //        }
                    //}

                    grsClassID = GetClassID(sourceEID);
                    prgClassID = SecondaryTracer.ClassIDFromName(workLayers.prg, m_pWorkspace);
                    subscriberClassID = SecondaryTracer.ClassIDFromName(workLayers.subscriber, m_pWorkspace);
                    consumerClassID = SecondaryTracer.ClassIDFromName(workLayers.consumer, m_pWorkspace);

                    junctionClassID = SecondaryTracer.ClassIDFromName(workLayers.network_Net_Junctions, m_pWorkspace);

                    secondaryTracer = new SecondaryTracer(ref iFeature, prgClassID, grsClassID, subscriberClassID, consumerClassID, junctionClassID, ref gaspipeline, ref geomNet, inputPressure, ref prg, ref subscriber, ref consumer, ref grs, ref network_Net_Junctions);
                    secondaryTracer.BeginTrace(sourceEID, qip, qif);
                }

                if (m_pWorkspace != null) Marshal.ReleaseComObject(m_pWorkspace);
                if (grs != null) Marshal.ReleaseComObject(grs);
                if (prg != null) Marshal.ReleaseComObject(prg);
                if (gaspipeline != null) Marshal.ReleaseComObject(gaspipeline);
                if (network_Net_Junctions != null) Marshal.ReleaseComObject(network_Net_Junctions);
                if (utilityNetwork != null) Marshal.ReleaseComObject(utilityNetwork);
                if (geomNet != null) Marshal.ReleaseComObject(geomNet);
                if (net != null) Marshal.ReleaseComObject(net);
                //Marshal.ReleaseComObject(secondaryTracer);
                //if (pQueryFilter != null) Marshal.ReleaseComObject(pQueryFilter);
                //if (pFeatureCursor != null) Marshal.ReleaseComObject(pFeatureCursor);
                if (iFeature != null) Marshal.ReleaseComObject(iFeature);
                if (source != null) Marshal.ReleaseComObject(source);
                string result = secondaryTracer.AllJunctions.getJSON().Replace("null", "\"\"").Replace("\"\"\"\"", "\"\"");
                Log.LogHeader(Log.LogName + ": Конец лога", elogheaderlevel.Level_1);
                return result;
            }
            catch (Exception ex)
            {
                return "{\"e\":\"" + ex.Message + "\"}";
            }
        }

        private static IFeature FindFeature(double SearchTol, IPoint pPoint, IFeatureClass pFeatureClass)
        {
            ISpatialFilter pSpatialFilter;
            IFeatureCursor pFCursor;
            IEnvelope pEnv;
            ISpatialReference spRef;

            IGeoDataset pGeoDataset = (IGeoDataset)pFeatureClass;
            spRef = pGeoDataset.SpatialReference;
            pEnv = pPoint.Envelope;
            pEnv.Expand(SearchTol, SearchTol, false);
            pSpatialFilter = new SpatialFilter();
            pSpatialFilter.Geometry = pEnv;
            pSpatialFilter.set_OutputSpatialReference(pFeatureClass.ShapeFieldName, spRef);
            pSpatialFilter.GeometryField = pFeatureClass.ShapeFieldName;
            pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelRelation;
            pSpatialFilter.SpatialRelDescription = "T********";
            pFCursor = pFeatureClass.Search(pSpatialFilter, false);
            IFeature result = pFCursor.NextFeature();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
            return result;
        }

        private int GetClassID(int EID)
        {
            INetElements netElements = (INetElements)utilityNetwork;
            int classID; int userID; int userSubID;
            netElements.QueryIDs(EID, esriElementType.esriETJunction, out classID, out userID, out userSubID);
            return classID;
        }

        //
        // returns an enumeration of EIDs of the network elements of the given element type
        //
        private IEnumNetEID GetCurrentEIDs(esriElementType elementType, INetwork net)
        {
            IEnumNetEID eids = net.CreateNetBrowser(elementType);
            return eids;
        }

        private void CreateNetwork(IPoint source, int OID)
        {   
            List<IFeature> gazPipeline = FindRiver_of_ARN(1, source, gaspipeline);

            int curOID;

            for (int i = 0; i < gazPipeline.Count; i++)
            {
                curOID = gazPipeline[i].OID;
                if (OID != curOID)
                {
                    pipelineCount++;
                    CreateNetwork(FindLast(source, gazPipeline[i]), curOID);
                }
            }
        }

        private IPoint FindLast(IPoint source, IFeature gazPipeline)
        {
            IPointCollection pPointCollection = (IPointCollection)gazPipeline.Shape;

            IPoint lastPoint = pPointCollection.get_Point(pPointCollection.PointCount - 1);

            if (GetDistance(source, lastPoint) < 1)
            {
                lastPoint = pPointCollection.get_Point(0);
            }
            return lastPoint;
        }
        
        //Функция измерения расстояния между точками
        private double GetDistance(IPoint p1, IPoint p2)
        {
            return ((IProximityOperator)p1).ReturnDistance(p2);
        }

        //Функция, которая проверяет точку на пересечение с водным объектом
        private List<IFeature> FindRiver_of_ARN(double SearchTol, IPoint pPoint, IFeatureClass pFeatureClass)
        {
            List<IFeature> iFeatures = new List<IFeature>();

            ISpatialFilter pSpatialFilter;
            IFeatureCursor pFCursor;
            IEnvelope pEnv;
            ISpatialReference spRef;

            IGeoDataset pGeoDataset = (IGeoDataset)pFeatureClass;
            spRef = pGeoDataset.SpatialReference;
            pEnv = pPoint.Envelope;
            pEnv.Expand(SearchTol, SearchTol, false);
            pSpatialFilter = new SpatialFilter();
            pSpatialFilter.Geometry = pEnv;
            pSpatialFilter.set_OutputSpatialReference(pFeatureClass.ShapeFieldName, spRef);
            pSpatialFilter.GeometryField = pFeatureClass.ShapeFieldName;
            pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelRelation;
            pSpatialFilter.SpatialRelDescription = "TF**F****";
            pFCursor = pFeatureClass.Search(pSpatialFilter, false);
            IFeature result = pFCursor.NextFeature();
            while (result != null)
            {
                iFeatures.Add(result);
                result = pFCursor.NextFeature();
            }
            System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
            return iFeatures;
        }

        public static IGeometricNetwork OpenGeometricNetwork(string dataSetName, string featureClassName, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {
                        if (ids2.Name.ToLower() == featureClassName.ToLower())
                        {
                            return (IGeometricNetwork)ids2;
                        }
                    }
                    break;
                }
            }
            return null;
        }

        public void OpenFeatureClass(string dataSetName, ref IFeatureClass grs, ref IFeatureClass prg, ref IFeatureClass subscriber, ref IFeatureClass gaspipeline, ref IFeatureClass network_Net_Junctions, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;
            IFeatureDataset ifds;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    IFeatureWorkspace ifs = (IFeatureWorkspace)m_pWorkspace;
                    ifds = ifs.OpenFeatureDataset(dataSetName);
                    IEnumDataset ied2 = ifds.Subsets;
                    IDataset ids2;
                    while ((ids2 = ied2.Next()) != null)
                    {
                        if (workLayers.grs == ids2.Name)
                            {
                                grs = (IFeatureClass)ids2;
                            }
                        else if (workLayers.prg == ids2.Name)
                            {
                                prg = (IFeatureClass)ids2;
                            }
                        else if (workLayers.subscriber == ids2.Name)
                            {
                                subscriber = (IFeatureClass)ids2;
                            }
                        else if (workLayers.consumer == ids2.Name)
                            {
                                consumer = (IFeatureClass)ids2;
                            }
                        else if (workLayers.gaspipeline == ids2.Name)
                            {
                                gaspipeline = (IFeatureClass)ids2;
                            }
                        else if (workLayers.network_Net_Junctions == ids2.Name)
                            {
                                network_Net_Junctions = (IFeatureClass)ids2;
                            }
                    }
                    break;
                }
            }
        }

        private IDatasetName OpenDataset(string dataSetName, IWorkspace m_pWorkspace)
        {
            IEnumDatasetName ied = m_pWorkspace.get_DatasetNames(esriDatasetType.esriDTAny);
            IDatasetName idn;

            while ((idn = ied.Next()) != null)
            {
                if (idn.Name.ToLower() == dataSetName.ToLower())
                {
                    return idn;
                }
            }

            return null;
        }

        public static IWorkspace OpenWorkspace(string workspace, string type)
        {
            IWorkspace m_pWorkspace;
            try
            {
                Type factoryType = Type.GetTypeFromProgID(type);
                IWorkspaceFactory pAccessFactory = (IWorkspaceFactory)Activator.CreateInstance(factoryType);
                m_pWorkspace = pAccessFactory.OpenFromFile(workspace, 0);
            }
            catch (Exception)
            {
                return null;
            }
            return m_pWorkspace;
        }

    }
}
