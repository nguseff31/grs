﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.esriSystem;

namespace GeomertyNetworkWorker
{
    public static class Global
    {
        private static LicenseInitializer _aoLicenseInitializer;

        public static void initializeLicenze()
        {
            if (_aoLicenseInitializer == null)
            {
                if (!ESRI.ArcGIS.RuntimeManager.Bind(ESRI.ArcGIS.ProductCode.Engine))
                {
                    if (!ESRI.ArcGIS.RuntimeManager.Bind(ESRI.ArcGIS.ProductCode.Desktop) && !ESRI.ArcGIS.RuntimeManager.Bind(ESRI.ArcGIS.ProductCode.Server))
                    {
                        //Это приложение не могло загрузить корректную версию ArcGIS.
                    }
                }

                _aoLicenseInitializer = new LicenseInitializer();

                _aoLicenseInitializer.InitializeApplication(new esriLicenseProductCode[] { esriLicenseProductCode.esriLicenseProductCodeEngine, esriLicenseProductCode.esriLicenseProductCodeBasic, esriLicenseProductCode.esriLicenseProductCodeStandard, esriLicenseProductCode.esriLicenseProductCodeAdvanced, esriLicenseProductCode.esriLicenseProductCodeArcServer },
                new esriLicenseExtensionCode[] { esriLicenseExtensionCode.esriLicenseExtensionCodeNetwork });
            }
        }

        public static void deinitializeLicenze()
        {
            if (_aoLicenseInitializer != null)
            {
                _aoLicenseInitializer.ShutdownApplication();
            }
        }
    }
}
