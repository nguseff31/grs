﻿using System;
using System.Diagnostics;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace GeomertyNetworkWorker
{
    public delegate void TraceEventHandler(object sender, TraceEventArgs e);

    public class SecondaryTracer
    {
        public event TraceEventHandler BeforeTrace;
        public event TraceEventHandler AfterTrace;

        protected bool IsWhatJunction(int eid, int whatClassID)
        {
            try
            {
                INetElements netElements = (INetElements)_utilityNetwork;
                int classID; int userID; int userSubID;

                netElements.QueryIDs(eid, esriElementType.esriETJunction, out classID, out userID, out userSubID);

                return (classID == whatClassID);
            }
            catch (Exception e)
            {
                Trace.WriteLine(e.ToString());
                return false;
            }
        }

        protected int IsWhatJunction(int eid)
        {
            try
            {
                INetElements netElements = (INetElements)_utilityNetwork;
                int classID; int userID; int userSubID;

                netElements.QueryIDs(eid, esriElementType.esriETJunction, out classID, out userID, out userSubID);

                return classID;
            }
            catch (Exception e)
            {
                Trace.WriteLine(e.ToString());
                return -1;
            }
        }

        #region Virtual Event Methods - Defualt Implementation
        public virtual void BeforeTraceEvent(TraceEventArgs e)
        {
            if (BeforeTrace != null)
            {
                BeforeTrace(this, e);
            }
        }
        public virtual void AfterTraceEvent(TraceEventArgs e)
        {
            if (AfterTrace != null)
            {
                AfterTrace(this, e);
            }
        }

        #endregion

        public JSONJunctions AllJunctions
        {
            get { return _allJunctions; }
        }

        public List<string> Pressures
        {
            get { return _pressures; }
        }

        public SecondaryTracer(ref IFeature featureOnNetwork, int prgClassID, int grsClassID, int subscriberClassID, int consumerClassID, int junctionClassID, ref IFeatureClass gaspipeline, ref IGeometricNetwork geomNet, List<string> inputPressure, ref IFeatureClass prg, ref IFeatureClass subscriber, ref IFeatureClass consumer, ref IFeatureClass grs, ref IFeatureClass network_Net_Junctions)
        {
            _prgClassID = prgClassID;
            _grsClassID = grsClassID;
            _subscriberClassID = subscriberClassID;
            _consumerClassID = consumerClassID;
            _junctionClassID = junctionClassID;
            _gaspipeline = gaspipeline;
            _geomNet = geomNet;
            _inputPressure = inputPressure;
            _prg = prg;
            _grs = grs;
            _subscriber = subscriber;
            _consumer = consumer;
            _network_Net_Junctions = network_Net_Junctions;
            _allJunctions = new JSONJunctions();
            _allallJunctions = new JSONJunctions();

            _pressures = new List<string>();

            IGeoDataset pGeoDataset = (IGeoDataset)_gaspipeline;
            spRef = pGeoDataset.SpatialReference;
            if (pGeoDataset != null) Marshal.ReleaseComObject(pGeoDataset);

            try
            {
                //инициализация utility network
                INetworkFeature netFeature = featureOnNetwork as INetworkFeature;
                if (netFeature == null)
                    throw (new ArgumentException("Ожидается INetworkFeature", "featureOnNetwork"));

                _utilityNetwork = netFeature.GeometricNetwork.Network as IUtilityNetwork;
                if (_utilityNetwork == null)
                    throw (new InvalidCastException("Network не utility network"));

                //инициализация workspace
                _mapWksp = ((IDataset)featureOnNetwork.Class).Workspace;

                if (netFeature != null) Marshal.ReleaseComObject(netFeature);
            }
            catch (Exception e)
            {
                throw (new Exception("Ошибка инициализации", e));
            }
        }

        public SecondaryTracer()
        {
        }

        public void BeginTrace(Dictionary<string, object> startJunction)
        {
            TraceEventArgs eventArgs = new TraceEventArgs();
            JSONJunctions StartJunctions = new JSONJunctions(startJunction);

            BeforeTraceEvent(eventArgs);

            TraceSecondary(StartJunctions);

            AfterTraceEvent(eventArgs);

            if (_isError == true)
            {
                throw (new Exception(String.Format("Информация об ошибке в файле: {0}", Log.LogName)));
            }
        }
        public void BeginTrace(int eid, double qip, double qif)
        {
            _firstEID = eid;
            _firstCLASS = IsWhatJunction(_firstEID);
            _isFirst = true;
            Dictionary<string, object> junc = new Dictionary<string, object>();
            //CustomCodeParameters
            junc.Add("eid", eid);
            junc.Add("parentedgeeid", 0);
            junc.Add("classid", -1);
            junc.Add("parenteid", 0);
            junc.Add("numedges", 0);
            //numedges - 1
            junc.Add("numchildjunctions", 0);
            junc.Add("d", 0);
            junc.Add("q", 0);
            junc.Add("gost", "");
            junc.Add("material", "");
            junc.Add("x", 0);
            junc.Add("y", 0);
            junc.Add("l", 0);
            junc.Add("name", "");
            junc.Add("nametruba", "");
            junc.Add("qf", 0);
            junc.Add("status", "");
            junc.Add("statustruba", "");
            junc.Add("pf", 0);
            junc.Add("type", "");
            junc.Add("qip", qip);
            junc.Add("qif", qif);

            BeginTrace(junc);
        }
        public IUtilityNetwork UtilityNetwork
        {
            get { return _utilityNetwork; }
        }


        public static int ClassIDFromName(string featureClassName, IWorkspace mapWksp)
        {
            string name = featureClassName;
            int periodIndex = name.IndexOf(".", 0);
            if (periodIndex != -1)
            {
                name = name.Substring(periodIndex + 1);
            }

            IEnumDatasetName featureDatasetNames = mapWksp.get_DatasetNames(esriDatasetType.esriDTFeatureDataset);
            IDatasetName featureDatasetName = featureDatasetNames.Next();
            while (featureDatasetName != null)
            {
                int classID = ClassIDFromName(featureDatasetName, name);
                if (classID != 0)
                {
                    if (featureDatasetNames != null) Marshal.ReleaseComObject(featureDatasetNames);
                    if (featureDatasetName != null) Marshal.ReleaseComObject(featureDatasetName);
                    return classID;
                }

                featureDatasetName = featureDatasetNames.Next();
            }
            if (featureDatasetNames != null) Marshal.ReleaseComObject(featureDatasetNames);
            if (featureDatasetName != null) Marshal.ReleaseComObject(featureDatasetName);
            return 0;
        }
        private static int ClassIDFromName(IDatasetName featureDatasetName, string className)
        {
            int classID = 0;
            IEnumDatasetName featureClassNames = featureDatasetName.SubsetNames;
            IDatasetName featureClassName = featureClassNames.Next();
            while (featureClassName != null)
            {
                string name = featureClassName.Name;
                int periodIndex = name.IndexOf(".", 0);
                if (periodIndex != -1)
                {
                    name = name.Substring(periodIndex + 1);
                }
                if (string.Compare(name, className, true) == 0)
                {
                    IObjectClassName objClassName = (IObjectClassName)featureClassName;
                    classID = objClassName.ObjectClassID;
                    break;
                }
                featureClassName = featureClassNames.Next();
            }
            if (featureClassNames != null) Marshal.ReleaseComObject(featureClassNames);
            if (featureDatasetName != null) Marshal.ReleaseComObject(featureDatasetName);
            return classID;
        }
        private void TraceSecondary(JSONJunctions inputJunctions)
        {
            if (inputJunctions.Count == 0)
                return;

            try
            {
                if (inputJunctions.Count > 10000)
                    throw (new TraceException("Зацикливание в процессе трассировки"));

                IForwardStar forwardStar = _utilityNetwork.CreateForwardStar(true, null, null, null, null);
                JSONJunctions newJunctions = new JSONJunctions();

                foreach (Dictionary<string, object> junction in inputJunctions)
                {
                    TraceSecondary(junction, newJunctions, forwardStar);
                }
                TraceSecondary(newJunctions);
            }
            catch (Exception e)
            {
                string inf = String.Format("Ошибка: {0}", e.Message);
                inf += String.Format("\r\nStackTrace: {0}", e.StackTrace);
                Log.LogThis(inf, eloglevel.error);
                _isError = true;
            }
        }

        private string _pipePressure = "";
        private double _pipeLen = 0;
        private double _pipePF = 0;
        private double _pipeDiameter = 0;
        private string _pipeGOST = "";
        private string _pipeMaterial = "";
        private string _pipeStatus = "";

        public void GetPressures(int sourceEID)
        {
            IForwardStar forwardStar = _utilityNetwork.CreateForwardStar(true, null, null, null, null);
            int numEdges;
            string pipePressure;
            forwardStar.FindAdjacent(0, sourceEID, out numEdges);
            for (int i = 0; i < numEdges; i++)
            {
                int junctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out junctionEID, out netWt);

                int edgeEID; bool revOrientation;
                forwardStar.QueryAdjacentEdge(i, out edgeEID, out revOrientation, out netWt);

                //Находим трубопровод
                IFeature result = FindFeature(_geomNet.get_GeometryForEdgeEID(edgeEID), _gaspipeline);
                //Берем атрибуты
                if (result != null)
                {
                    pipePressure = result.get_Value(result.Fields.FindField(GeomertyNetworkWorker.GeometryNetworkWorker.pipeattr)).ToString();
                    if (!string.IsNullOrEmpty(pipePressure) && pipePressure != "" && pipePressure != " ")
                            _pressures.Add(pipePressure);
                }
                if (result != null) Marshal.ReleaseComObject(result);
            }
        }

        private void GetObjectInfo(ref string pointInfo, ref IGeometry geom, ref IFeatureClass lyr)
        {
            //Находим Объект
            IFeature result2 = FindFeature(geom, lyr);
            //Берем атрибуты
            if (result2 != null)
            {
                pointInfo += String.Format("\r\nLAYER: {0}\r\nOBJECTID: {1}", lyr.AliasName, result2.OID);
            }
        }

        private void AddObjectAttributes(ref IGeometry geom, ref IFeatureClass lyr, ref Dictionary<string, string> dic, ref Dictionary<string, object> attrs, ref JSONJunctions newJunctions, int classid)
        {
            //Находим Объект
            IFeature result2 = FindFeature(geom, lyr);
            //Берем атрибуты
            if (result2 != null)
            {
                foreach (KeyValuePair<string, string> pair in dic)
                {
                    AddAttributes(ref result2, pair, ref attrs);
                }
            }

            if (result2 != null) Marshal.ReleaseComObject(result2);

            //CustomCodeParameters
            attrs.Add("classid", classid);
            newJunctions.Add(attrs);

            _allallJunctions.Add(attrs);
        }

        private void AddAttributes(ref IFeature result, KeyValuePair<string, string> pair, ref Dictionary<string, object> attrs)
        {
            string[] arr = pair.Value.Split(',');

            int fieldNum = result.Fields.FindField(arr[0]);
            //object obj = result.get_Value(fieldNum);
            IField fld = result.Fields.get_Field(fieldNum);
            IDomain dmn = fld.Domain;
            string val = result.get_Value(fieldNum).ToString();
            double tmpd;
            if (dmn != null)
            {
                //+++ QI for the ICodedValueDomain interface
                ICodedValueDomain pCodedValueDomain;
                pCodedValueDomain = dmn as ICodedValueDomain;

                int ii;
                bool isHave = false;
                for (ii = 0; ii < pCodedValueDomain.CodeCount - 1; ii++)
                {
                    if (pCodedValueDomain.get_Value(ii).ToString() == val)
                    {
                        isHave = true;
                        val = pCodedValueDomain.get_Name(ii).ToString();
                        if (double.TryParse(val, out tmpd))
                            attrs.Add(pair.Key, tmpd);
                        else
                            attrs.Add(pair.Key, val);
                        break;
                    }
                }
                if (!isHave)
                {
                    if (double.TryParse(val, out tmpd))
                        attrs.Add(pair.Key, tmpd);
                    else
                        attrs.Add(pair.Key, val);
                }
            }
            else
                if (double.TryParse(val, out tmpd))
                    attrs.Add(pair.Key, tmpd);
                else
                    attrs.Add(pair.Key, val);
        }

        private void TraceSecondary(Dictionary<string, object> junction, JSONJunctions newJunctions, IForwardStar forwardStar)
        {
            int numEdges;
            string pipePressure = "";
            /*double pipeLen = 0;
            double pipePF = 0;
            double pipeDiameter = 0;
            string pipeGOST = "";
            string pipeMaterial = "";
            string pipeName = "";*/
            string pipeStatus = "";
            forwardStar.FindAdjacent(0, (int)junction["eid"], out numEdges);
            if (_isFirst)
            {
                IGeometry geomSS = _geomNet.get_GeometryForJunctionEID((int)junction["eid"]);
                IPoint pointSS = geomSS as IPoint;

                //CustomCodeParameters
                Dictionary<string, object> jun = new Dictionary<string, object>();
                jun.Add("eid", junction["eid"]);
                jun.Add("parentedgeeid", 0);
                jun.Add("parenteid", 0);
                jun.Add("numedges", numEdges);
                //numedges - 1
                jun.Add("numchildjunctions", numEdges - 1);
                jun.Add("x", pointSS.X);
                jun.Add("y", pointSS.Y);

                jun.Add("d", 0);
                jun.Add("p", _inputPressure[0]);
                jun.Add("pf", _inputPressure[0]);
                jun.Add("gost", "");
                jun.Add("material", "");
                jun.Add("l", 0);
                jun.Add("nametruba", "");
                jun.Add("statustruba", "Существующий");

                if (IsWhatJunction((int)junction["eid"], _prgClassID))
                {
                    AddObjectAttributes(ref geomSS, ref _prg, ref GeometryNetworkWorker.workAttributes.prg, ref jun, ref _allJunctions, -1);
                }
                else if (IsWhatJunction((int)junction["eid"], _grsClassID))
                {
                    AddObjectAttributes(ref geomSS, ref _grs, ref GeometryNetworkWorker.workAttributes.grs, ref jun, ref _allJunctions, -1);
                }

                junction = jun;

                //_allJunctions.Add(jun);
                //_allJunctions.Add(junction["eid"], 0, -1, 0, numEdges, 0, 0, "нет", "нет", pointSS.X, pointSS.Y, 0, "", "", 0, "", "", 0, "");
                if (geomSS != null) Marshal.ReleaseComObject(geomSS);
                if (pointSS != null) Marshal.ReleaseComObject(pointSS);                
            }
            else
            {
                junction["numedges"] = numEdges;
                //numedges - 1
                junction["numchildjunctions"] = numEdges - 1;
            }
            for (int i = 0; i < numEdges; i++)
            {
                int junctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out junctionEID, out netWt);

                int edgeEID; bool revOrientation;
                forwardStar.QueryAdjacentEdge(i, out edgeEID, out revOrientation, out netWt);

                if (IsTraceableEdge(edgeEID, junction, junctionEID) && !isConnected(junctionEID, (int)junction["eid"], _allallJunctions))
                {
                    //Находим трубопровод
                    IFeature result;
                    try
                    {
                        result = FindFeature(_geomNet.get_GeometryForEdgeEID(edgeEID), _gaspipeline);
                    }
                    catch (Exception e)
                    {
                        String pointInfo = "x: error\r\ny: error";
                        try
                        {
                            IGeometry geom = _geomNet.get_GeometryForJunctionEID(junctionEID);
                            IPoint point = geom as IPoint;
                            pointInfo = String.Format("x: {0}\r\ny: {1}", point.X, point.Y);

                            if (IsWhatJunction(junctionEID, _prgClassID))
                            {
                                GetObjectInfo(ref pointInfo, ref geom, ref _prg);
                            }
                            else if (IsWhatJunction(junctionEID, _subscriberClassID))
                            {
                                GetObjectInfo(ref pointInfo, ref geom, ref _subscriber);
                            }
                            else if (IsWhatJunction(junctionEID, _consumerClassID))
                            {
                                GetObjectInfo(ref pointInfo, ref geom, ref _consumer);
                            }
                            else if (IsWhatJunction(junctionEID, _grsClassID))
                            {
                                GetObjectInfo(ref pointInfo, ref geom, ref _grs);
                            }
                            else if (IsWhatJunction(junctionEID, _junctionClassID))
                            {
                                GetObjectInfo(ref pointInfo, ref geom, ref _network_Net_Junctions);
                            }
                        }
                        catch
                        { }
                        pointInfo += String.Format("\r\nStackTrace: {0}", e.StackTrace);
                        Log.LogThis(String.Format("Ошибка: {0}\r\njunctionEID: {1}\r\nedgeEID: {2}\r\n{3}", e.Message, junctionEID, edgeEID, pointInfo), eloglevel.error);
                        result = null;
                        _isError = true;
                    }
                    //Берем атрибуты
                    if (result != null)
                    {
                        pipePressure = result.get_Value(result.Fields.FindField(GeomertyNetworkWorker.GeometryNetworkWorker.pipeattr)).ToString();
                        if (string.IsNullOrEmpty(pipePressure) || pipePressure == "" || pipePressure == " ")
                            pipePressure = "0";

                        pipeStatus = result.get_Value(result.Fields.FindField("STATUS")).ToString();
                        if (!string.IsNullOrEmpty(pipeStatus) && pipeStatus != "" && pipeStatus != " ")
                            _pipeStatus = pipeStatus;
                        else
                            pipeStatus = _pipeStatus;

                        //Сравниваем значения
                        if (_inputPressure.Contains(pipePressure))
                        {
                            Dictionary<string, object> attrs = new Dictionary<string, object>();
                            //Считываем параметры газопровода
                            foreach (KeyValuePair<string, string> pair in GeometryNetworkWorker.workAttributes.pip)
                            {
                                AddAttributes(ref result, pair, ref attrs);
                            }

                            if (result != null) Marshal.ReleaseComObject(result);
                            IGeometry geom = _geomNet.get_GeometryForJunctionEID(junctionEID);
                            IPoint point = geom as IPoint;

                            //CustomCodeParameters
                            attrs.Add("eid", junctionEID);
                            attrs.Add("parentedgeeid", edgeEID);
                            attrs.Add("parenteid", junction["eid"]);
                            attrs.Add("numedges", 0);
                            //numedges - 1
                            attrs.Add("numchildjunctions", 0);
                            attrs.Add("x", point.X);
                            attrs.Add("y", point.Y);

                            if (IsWhatJunction(junctionEID, _prgClassID))
                            {
                                AddObjectAttributes(ref geom, ref _prg, ref GeometryNetworkWorker.workAttributes.prg, ref attrs, ref newJunctions, 2);
                            }
                            else if (IsWhatJunction(junctionEID, _subscriberClassID))
                            {
                                AddObjectAttributes(ref geom, ref _subscriber, ref GeometryNetworkWorker.workAttributes.sub, ref attrs, ref newJunctions, 3);
                            }
                            else if (IsWhatJunction(junctionEID, _consumerClassID))
                            {
                                AddObjectAttributes(ref geom, ref _consumer, ref GeometryNetworkWorker.workAttributes.con, ref attrs, ref newJunctions, 3);
                            }
                            else if (IsWhatJunction(junctionEID, _grsClassID))
                            {
                                if (IsWhatJunction(junctionEID, _firstCLASS))
                                    AddObjectAttributes(ref geom, ref _grs, ref GeometryNetworkWorker.workAttributes.grs, ref attrs, ref newJunctions, -1);
                                else
                                    AddObjectAttributes(ref geom, ref _grs, ref GeometryNetworkWorker.workAttributes.grs, ref attrs, ref newJunctions, 1);
                            }
                            else if (IsWhatJunction(junctionEID, _junctionClassID))
                            {
                                //CustomCodeParameters
                                attrs.Add("classid", 5);
                                attrs.Add("status", pipeStatus);
                                newJunctions.Add(attrs);

                                _allallJunctions.Add(attrs);
                            }
                            else
                            {
                                //CustomCodeParameters
                                attrs.Add("classid", 0);
                                newJunctions.Add(attrs);

                                _allallJunctions.Add(attrs);
                            }
                            if (geom != null) Marshal.ReleaseComObject(geom);
                            if (point != null) Marshal.ReleaseComObject(point);
                        }
                        else if (isSource(_inputPressure, pipePressure))
                        {
                            if (IsWhatJunction((int)junction["eid"], _firstCLASS))
                                junction["classid"] = -1;
                        }
                    }
                }
            }
            if (!_isFirst)
            {
                _allJunctions.Add(junction);
            }
            else
            {
                _isFirst = false;
            }
        }

        private Boolean isSource(List<string> inputPressure, string pressure)
        {
            for (int i = 0; i < inputPressure.Count; i++)
            {
                if (double.Parse(pressure) > double.Parse(inputPressure[i]))
                {
                    return true;
                }
            }
            return false;
        }

        private IFeature FindFeature(IGeometry geometry, IFeatureClass pFeatureClass)
        {
            ISpatialFilter pSpatialFilter2;
            IFeatureCursor pFCursor2;
            pSpatialFilter2 = new SpatialFilter();
            pSpatialFilter2.Geometry = geometry;
            pSpatialFilter2.set_OutputSpatialReference(pFeatureClass.ShapeFieldName, spRef);
            pSpatialFilter2.GeometryField = pFeatureClass.ShapeFieldName;
            pSpatialFilter2.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin;
            //pSpatialFilter.SpatialRelDescription = "T********";
            pFCursor2 = pFeatureClass.Search(pSpatialFilter2, false);
            IFeature result2 = pFCursor2.NextFeature();
            if (pSpatialFilter2 != null) Marshal.ReleaseComObject(pSpatialFilter2);
            if (pFCursor2 != null) Marshal.ReleaseComObject(pFCursor2);
            return result2;
        }

        /*private bool isHaveEID(int EID, int ParentEID, JSONJunctions jns)
        {
            for (int i = 0; i < jns.junctions.Count; i++)
            {
                if ((int)(jns.junctions[i]["eid"]) == EID)
                    return true;
            }
            return false;
        }*/

        private bool isConnected(int EID, int ParentEID, JSONJunctions jns)
        {
            for (int i = 0; i < jns.junctions.Count; i++)
            {
                if (((int)(jns.junctions[i]["eid"]) == EID && (int)(jns.junctions[i]["parenteid"]) == ParentEID) || ((int)(jns.junctions[i]["parenteid"]) == EID && (int)(jns.junctions[i]["eid"]) == ParentEID))
                    return true;
            }
            return false;
        }

        private bool IsTraceableEdge(int edgeEID, Dictionary<string, object> junction, int junctionEID)
        {
            if (edgeEID == (int)junction["parentedgeeid"])
                return false;

            if (edgeEID == 0)
                return false;

            if (junctionEID == 0)
                return false;

                return true;
        }
       
        protected IUtilityNetwork _utilityNetwork;
        protected IWorkspace _mapWksp;

        private List<string> _pressures;
        private JSONJunctions _allJunctions;

        private JSONJunctions _allallJunctions;

        private int _prgClassID;
        private int _grsClassID;
        private int _subscriberClassID;
        private int _consumerClassID;
        private int _junctionClassID;

        private bool _isFirst = true;
        private int _firstEID = 0;
        private int _firstCLASS = -1;

        private IFeatureClass _gaspipeline;
        private IFeatureClass _grs;
        private IFeatureClass _prg;
        private IFeatureClass _subscriber;
        private IFeatureClass _consumer;
        private IFeatureClass _network_Net_Junctions;
        private IGeometricNetwork _geomNet;
        private ISpatialReference spRef;

        private List<string> _inputPressure;

        private Boolean _isError = false;
    }
}
