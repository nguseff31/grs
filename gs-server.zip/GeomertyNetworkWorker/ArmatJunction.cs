﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace GeomertyNetworkWorker
{
    public class ArmatJunction
    {        
        [XmlElement("eid")]
        public int EID
        {
            get { return _eid; }
            set {_eid = value;}
        }

        [XmlElement("parentedgeeid")]
        public int ParentEdgeEID
        {
            get { return _parentEdgeEID; }
            set { _parentEdgeEID = value; }
        }

        [XmlElement("classid")]
        public int ClassID
        {
            get { return _classID; }
            set { _classID = value; }
        }

        [XmlElement("parenteid")]
        public int ParentEID
        {
            get { return _parentEID; }
            set { _parentEID = value; }
        }

        [XmlElement("numedges")]
        public int NumEdges
        {
            get { return _numEdges; }
            set { _numEdges = value; }
        }

        [XmlElement("numchildjunctions")]
        public int NumChildJunctions
        {
            get { return _numChildJunctions; }
            set { _numChildJunctions = value; }
        }


        [XmlElement("objectid")]
        public string objectid
        {
            get { return _objectid; }
            set { _objectid = value; }
        }

        //[XmlElement("PPoints")]
        //public List<doubleList> PPoints
        //{
        //    get { return _pipeline; }
        //    set { _pipeline = value; }
        //}

        [XmlElement("raion")]
        public string raion
        {
            get { return _raion; }
            set { _raion = value; }
        }

        [XmlElement("name")]
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        [XmlElement("type")]
        public string type
        {
            get { return _type; }
            set { _type = value; }
        }

        [XmlElement("x")]
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }

        [XmlElement("Points")]
        public string Points
        {
            get { return _points; }
            set { _points = value; }
        }

        [XmlElement("y")]
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }

        [XmlElement("Diameter")]
        public double Diameter
        {
            get { return _diameter; }
            set { _diameter = value; }
        }

        [XmlElement("StartTemperature")]
        public double StartTemperature
        {
            get { return _starttemperature; }
            set { _starttemperature = value; }
        }
        [XmlElement("EndTemperature")]
        public double EndTemperature
        {
            get { return _endtemperature; }
            set { _endtemperature = value; }
        }
        [XmlElement("GroundTemperature")]
        public double GroundTemperature
        {
            get { return _groundtemperature; }
            set { _groundtemperature = value; }
        }

        [XmlElement("Length")]
        public double Length
        {
            get { return _length; }
            set { _length = value; }
        }

        [XmlElement("StartPressure")]
        public double StartPressure
        {
            get { return _startpressure; }
            set { _startpressure = value; }
        }

        [XmlElement("EndPressure")]
        public double EndPressure
        {
            get { return _endpressure; }
            set { _endpressure = value; }
        }


        [XmlElement("GasReserve")]
        public double GasReserve
        {
            get { return _gasreserve; }
            set { _gasreserve = value; }
        }

        public ArmatJunction()
        {
        }
        public ArmatJunction(int eid)
        {
            _eid = eid;
        }
        public ArmatJunction(int EID, int parentEdgeEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
        }

        public ArmatJunction(string points, string type, bool ispoint)
        {
            _points = points;
            _ispoint = ispoint;
            _type = type;
        }

        public ArmatJunction(int EID, int parentEdgeEID, int classID, int parentEID, int numEdges, string objid, string raion, string name, string type, double x, double y)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
            _numEdges = numEdges;
            if (numEdges > 0)
            {
                _numChildJunctions = numEdges - 1;
            }
            _objectid = objid;
            _raion = raion;
            _name = name;
            _type = type;
            _x = x;
            _y = y;
        }

        private int _eid = 0;
        private int _parentEdgeEID = 0;
        private int _classID = 0;
        private int _parentEID = 0;
        private int _numEdges = 0;
        private int _numChildJunctions = 0;
        private string _objectid = "";
        private string _raion = "";
        private string _name = "";
        private string _type = "";
        private double _x = 0;
        private double _y = 0;
        private string _points = "";
        private bool _ispoint;
        private double _diameter = 0;
        private double _length = 0;
        //private double _pressure = 0;
        private double _starttemperature = 293.15;
        private double _endtemperature = 293.15;
        private double _groundtemperature = 293.15;
        private double _startpressure=0;
        private double _endpressure=0;
        private double _gasreserve=0;
        //private List<doubleList> _pipeline = new List<doubleList>();
    }
}
