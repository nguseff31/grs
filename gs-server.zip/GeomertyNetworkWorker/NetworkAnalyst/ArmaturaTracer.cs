﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;

namespace GeomertyNetworkWorker.NetworkAnalyst
{
    /*class ArmatNetwork : IGeometricNetwork<CommonJunction, CommonJunction>
    {
        private IUtilityNetwork utilityNetwork;
        private IForwardStar forwardStar;
        private CommonJunctions armaturaJunctions;
        private CommonJunctions temp1Junctions;
        private CommonJunctions temp2Junctions;
        private CommonJunctions junctionJunctions;
        private CommonJunctions newJunctions;
        //private CommonJunctions allArmJunctions;

        //----------Потребители------------------------
        //private CommonJunctions consumerJunctions;
        //private CommonJunctions subscriberJunctions;
        private CommonJunctions abonJunctions;
        private CommonJunctions abon2Junctions;

        //--------------------------------------------

        //----------ГРС--------------------------------
        private CommonJunctions grsOutJunctions;
        private CommonJunctions grs2Junctions;
        //--------------------------------------------

        //----------Задвижки---------------------------
        private CommonJunctions allArmJunctions;
        private CommonJunctions ArmGRSJunctions;

        //--------------------------------------------
        private CommonJunctions edgejunctions;
        //--------------------------------------------
        //private List<int> eidArm = new List<int>();
        //private int numberOfArms;

        private CommonJunctions Spoints;
        private CommonJunctions SPV;
        private CommonJunctions VSUP;

        private CommonJunctions pass2;
        private CommonJunctions Psup;
        private CommonJunctions Sgm;
        private CommonJunctions Sgm2;
        private CommonJunctions prgjunction;
        private CommonJunctions tmpList;
        //--------------------------------------------

        public int grsClassID;
        public int consumerClassID;
        public int subscriberClassID;
        public int armaturaClassID;
        public int junctionClassID;
        public int prgClassID;

        public IUtilityNetwork UtilityNetwork
        {
            get { return utilityNetwork; }
        }
        public CommonJunctions ArmaturaJunctions
        {
            get { return armaturaJunctions; }
        }
        public CommonJunctions Temp1Junctions
        {
            get { return temp1Junctions; }
        }
        public CommonJunctions Temp2Junctions
        {
            get { return temp2Junctions; }
        }

        //public CommonJunctions ConsumerJunctions
        //{
        //    get { return consumerJunctions; }
        //}

        //public CommonJunctions SubscriberJunctions
        //{
        //    get { return subscriberJunctions; }
        //}
        public CommonJunctions AbonentJunctions
        {
            get { return abonJunctions; }
        }

        public CommonJunctions SGMEDGE
        {
            get { return Sgm; }
        }

        public ArmatNetwork()
        {
        }

        public ArmatNetwork(int armClassID, int consClassID, int subsClassID, int grsClassID, int juncClassID, int prgClassID, ref IGeometricNetwork geomNet)
        {
            this.armaturaClassID = armClassID;
            this.consumerClassID = consClassID;
            this.subscriberClassID = subsClassID;
            this.grsClassID = grsClassID;
            this.junctionClassID = juncClassID;
            this.prgClassID = prgClassID;
            armaturaJunctions = new CommonJunctions();
            //temp1Junctions = new CommonJunctions();
            //temp2Junctions = new CommonJunctions();
            junctionJunctions = new CommonJunctions();
            newJunctions = new CommonJunctions();
            allArmJunctions = new CommonJunctions();
            prgjunction = new CommonJunctions();
            tmpList = new CommonJunctions();
            edgejunctions = new CommonJunctions();
            //ArmGRSJunctions = new CommonJunctions();
            
            abonJunctions = new CommonJunctions();
            grsOutJunctions = new CommonJunctions();
            abon2Junctions = new CommonJunctions();
            grs2Junctions = new CommonJunctions();
            //arJunctions = new CommonJunctions();
            //---------------------------------

            Spoints = new CommonJunctions();
            SPV = new CommonJunctions();
            VSUP = new CommonJunctions();

            pass2 = new CommonJunctions();
            Psup = new CommonJunctions();
            Sgm = new CommonJunctions();
            Sgm2 = new CommonJunctions();

            utilityNetwork = geomNet.Network as IUtilityNetwork;

            forwardStar = utilityNetwork.CreateForwardStar(true, null, null, null, null);

            if (utilityNetwork == null)
                throw (new InvalidCastException("Network не utility network"));
        }

        public IEnumerable<int> getAdjacentVertex(int vertexID) 
        {
            int edgesCount;
            forwardStar.FindAdjacent(0, vertexID, out edgesCount);
            for (int i = 0; i < edgesCount; i++)
            {
                object weight;
                int eid;
                forwardStar.QueryAdjacentJunction(i, out eid, out weight);
                yield return eid;
            }
        }

        private int GetClassID(int eid)
        {
            try
            {
                INetElements netElements = (INetElements)utilityNetwork;
                int classID; int userID; int userSubID;
                netElements.QueryIDs(eid, esriElementType.esriETJunction, out classID, out userID, out userSubID);
                return classID;
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.ToString());
                return -1;
            }
        }

        public CommonJunction getVertex(int vertexID)
        {
            int classID;
            string className = "";

            if ((classID = GetClassID(vertexID)) == -1)
            {
                return null;
            }
            if (classID == armaturaClassID)
            {
                className = "Valve";
            }

            if (classID == prgClassID)
            {
                className = "PRG";

            }

            if (classID == grsClassID)
                className = "GRS";

            if (classID == junctionClassID)
                className = "Junction";

            if (classID == consumerClassID)
                className = "Consumer";

            if (classID == subscriberClassID)
                className = "Subscriber";

            return new CommonJunction(vertexID, classID, className);
        }

        /// <summary>
        /// Рёбра пока не нужны, так что тут заглушка
        /// </summary>
        /// <param name="fromID"></param>
        /// <param name="toID"></param>
        /// <returns>-1</returns>
        public int getEdge(int fromID, int toID)
        {
            return -1;
        }
        /// <summary>
        /// Заглушка, outEdge = -1. Возвращает true
        /// </summary>
        /// 
        /// <param name="toID"></param>
        /// <param name="outEdge"></param>
        /// <returns>true</returns>
        public bool tryGetEdge(int fromID, int toID, out int outEdge)
        {
            outEdge = -1;
            return true;
        }
        /// <summary>
        /// Заглушка
        /// </summary>
        /// <param name="vertexID"></param>
        /// <returns></returns>
        public bool containsVertex(int vertexID)
        {
            return true;
        }

        //пока не нужно
        //public bool containsVertex(TVertex vertex);

        /// <summary>
        /// Заглушка
        /// </summary>
        /// <param name="edgeID"></param>
        /// <returns></returns>
        public bool tryGetEdgeFeature(int edgeID, out CommonJunction edge)
        {
            edge = null;
            return true;
        }
    }

    */
    public class ArmaturaTracer : NetworkTracer<CommonJunction, CommonJunction>
    {
        public ArmaturaTracer(IGeometricNetwork<CommonJunction, CommonJunction> network)
        {
            this.network = network;
        }
        protected override void processEdge(Edge<CommonJunction> edge, int edgeID)
        {
            
        }
        
        protected override void processVertex(Vertex<CommonJunction> vertex, int vertexID)
        {
            
        }
        
        protected override bool adjacentContract(int current, int adjacent)
        {
            return true;
        }

        public IEnumerable<int> getArmat(int startID)
        {
            List<int> arm_junctions = new List<int>();

            this.BFS(startID, (junction, junctionID) =>
            {
                if (junction.value.ClassID == 3)
                    arm_junctions.Add(junction.id);
            },
            (edge, edgeID) => { },
            (cur, adj) => true);

            return arm_junctions;
        }
        public List<int> armatTrace(int startID)
        {
            List<int> edges = new List<int>();

            HashSet<int> visited2 = new HashSet<int>();

            //Для всех задвижек
            foreach (int armID in getArmat(startID))
            {
                visited2.Add(armID);

                foreach (int eid in network.getAdjacentVertex(armID))
                {
                    bool is_grs = false;
                    
                    List<int> v_edges = new List<int>();
                    this.BFS(eid, (junction, junctionID) =>
                    {
                        visited2.Add(junctionID);
                        switch (junction.value.ClassID)
                        {
                            case 1:
                                is_grs = true;
                                break;
                        }
                    },
                    (edge, edgeID) => 
                    { 
                        v_edges.Add(edgeID);
                    },
                    (cur, adj) => adj!=armID && !visited2.Contains(eid));

                    if(is_grs) 
                    {
                        edges.AddRange(v_edges);
                    }
                }
                //visited2.Clear();
            }
            return edges;
        }

    }
}
