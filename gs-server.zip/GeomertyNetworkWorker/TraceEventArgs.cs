﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeomertyNetworkWorker
{
    public class TraceEventArgs : EventArgs
    {
        public TraceEventArgs()
            : base()
        {
            try
            {
            }
            catch
            {
            }
        }
    }
}
