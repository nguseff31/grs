﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Serialization;
using System.IO;
using System.Xml;
using System.Reflection;

namespace GeomertyNetworkWorker
{
    [XmlRoot("junctions")]
    public class Junctions
    {
        [XmlArray("junctionslist")]
        public List<Junction> junctions { get; set; }

        [XmlElement("count")]
        public int Count
        {
            get { return junctions.Count; }
        }

        public Junctions()
        {
            junctions = new List<Junction>();
        }
        public Junctions(int eid)
            : this()
        {
            Add(eid);
        }
        public Junctions(Junction junction)
            : this()
        {
            junctions.Add(junction);
        }
        public Junction Add(int eid)
        {
            return Add(new Junction(eid));
        }
        public Junction Add(int eid, int parentEdgeEID)
        {
            return Add(new Junction(eid, parentEdgeEID));
        }
        public Junction Add(int eid, int parentEdgeEID, int classID, int parentEID, int numEdges, double d, double q, string gost, string material, double x, double y, double len, string name, string nametruba, double qf, string status, string statustruba, double pf, string ttype)
        {
            return Add(new Junction(eid, parentEdgeEID, classID, parentEID, numEdges, d, q, gost, material, x, y, len, name, nametruba, qf, status, statustruba, pf, ttype));
        }

        public Junction Add(Junction junction)
        {
            junctions.Add(junction);
            return junction;
        }

        #region Implementation of IEnumerable
        public System.Collections.IEnumerator GetEnumerator()
        {
            return junctions.GetEnumerator();
        }
        #endregion

        public string getXML()
        {
            MemoryStream stream = new MemoryStream();
            XmlSerializer arr = new XmlSerializer(typeof(Junctions));
            arr.Serialize(stream, this);
            byte[] buffer = stream.GetBuffer();
            stream.Close();
            UTF8Encoding encoding = new UTF8Encoding();
            string s = encoding.GetString(buffer);

            var xml = new XmlDocument();
            xml.LoadXml(s);
            s = Newtonsoft.Json.JsonConvert.SerializeObject(xml);

            UTF8Encoding encoder = new UTF8Encoding();
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            string utf8ReturnString = encoder.GetString(bytes);

            return utf8ReturnString;
        }

        public void SerializeToXML(String path)
        {
            using (StreamWriter w = new StreamWriter(path))
            {
                XmlSerializer s = new XmlSerializer(this.GetType());
                s.Serialize(w, this);
                w.Close();
            }
        }

        public void DeserializeFromXML(String path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                XmlTextReader xr = new XmlTextReader(sr);
                XmlSerializer xs = new XmlSerializer(this.GetType());
                object c;
                if (xs.CanDeserialize(xr))
                {
                    c = xs.Deserialize(xr);
                    Type t = this.GetType();
                    PropertyInfo[] properties = t.GetProperties();
                    foreach (PropertyInfo p in properties)
                    {
                        p.SetValue(this, p.GetValue(c, null), null);
                    }
                }
                xr.Close();
                sr.Close();
                File.Delete(path);
            }
        }

    }
}
