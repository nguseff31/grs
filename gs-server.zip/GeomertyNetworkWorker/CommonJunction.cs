﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace GeomertyNetworkWorker
{
    public class CommonJunction
    {
        [XmlElement("eid")]
        public int EID
        {
            get { return _eid; }
            set {_eid = value;}
        }
        [XmlElement("numberOfArms")]
        public int numberOfArms
        {
            get { return _numOfArms; }
            set { _numOfArms = value; }
        }

        [XmlElement("parentedgeeid")]
        public int ParentEdgeEID
        {
            get { return _parentEdgeEID; }
            set { _parentEdgeEID = value; }
        }

        [XmlElement("classid")]
        public int ClassID
        {
            get { return _classID; }
            set { _classID = value; }
        }

        [XmlElement("parenteid")]
        public int ParentEID
        {
            get { return _parentEID; }
            set { _parentEID = value; }
        }
        [XmlElement("SPointValve")]
        public int SpointValve
        {
            get { return _ValveEID;}
            set { _ValveEID = value; }
        }
        public CommonJunction()
        {
        }

        public CommonJunction(int eid)
        {
            _eid = eid;
        }

        public CommonJunction(int EID, int parentEdgeEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
        }

        public override int GetHashCode()
        {
            return this.EID.GetHashCode();
        }

        public CommonJunction(int EID, int parentEdgeEID, int classID, int parentEID)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
        }
        public CommonJunction(int EID, int parentEdgeEID, int classID, int parentEID, int numOfArms)
        {
            _parentEdgeEID = parentEdgeEID;
            _eid = EID;
            _classID = classID;
            _parentEID = parentEID;
            _numOfArms = numOfArms;
        }
        public CommonJunction(int EID, int ClassID, string Str)
        {
            
            _eid = EID;
            _Str = Str;
            _classID = ClassID;
        }
        public CommonJunction(int EID, int ClassID, string Str, int ValveEID, string ValveStr)
        {
            _eid = EID;
            _classID = ClassID;
            _Str = Str;
            _ValveEID = ValveEID;
           
            _ValveStr = ValveStr;
           
        }
        private int _eid = 0;
        private int _parentEdgeEID = 0;
        private int _classID = 0;
        private int _parentEID = 0;
        private int _numOfArms = 0;
        private string _Str = "";
        private int _ValveEID = 0;
      
        private string _ValveStr = "";
      
    }
}
