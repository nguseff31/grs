﻿using System;
using System.Diagnostics;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace GeomertyNetworkWorker
{
    public delegate void TraceArmaturaEventHandler(object sender, TraceEventArgs e);

    //А ещё больше запутать не могли ?
    public class SecondaryTracerArmatura
    {
        private IUtilityNetwork utilityNetwork;
        private IForwardStar forwardStar;
        private CommonJunctions armaturaJunctions;
        private CommonJunctions temp1Junctions;
        private CommonJunctions temp2Junctions;
        private CommonJunctions junctionJunctions;
        private CommonJunctions newJunctions;
        //private CommonJunctions allArmJunctions;

        //----------Потребители------------------------
        //private CommonJunctions consumerJunctions;
        //private CommonJunctions subscriberJunctions;
        private CommonJunctions abonJunctions;
        private CommonJunctions abon2Junctions;

        //--------------------------------------------
       
        //----------ГРС--------------------------------
        private CommonJunctions grsOutJunctions;
        private CommonJunctions grs2Junctions;
        //--------------------------------------------

        //----------Задвижки---------------------------
        private CommonJunctions allArmJunctions;
        private CommonJunctions ArmGRSJunctions;
        
        //--------------------------------------------
        private CommonJunctions edgejunctions;
        //--------------------------------------------
        //private List<int> eidArm = new List<int>();
        //private int numberOfArms;

        private CommonJunctions Spoints;
        private CommonJunctions SPV;
        private CommonJunctions VSUP;

        private CommonJunctions pass2;
        private CommonJunctions Psup;
        private CommonJunctions Sgm;
        private CommonJunctions Sgm2;
        private CommonJunctions prgjunction;
        private CommonJunctions tmpList;
        //--------------------------------------------

        private int grsClassID;
        private int consumerClassID;
        private int subscriberClassID;
        private int armaturaClassID;
        private int junctionClassID;
        private int prgClassID;

        public IUtilityNetwork UtilityNetwork
        {
            get { return utilityNetwork; }
        }
        public CommonJunctions ArmaturaJunctions
        {
            get { return armaturaJunctions; }
        }
        public CommonJunctions Temp1Junctions
        {
            get { return temp1Junctions; }
        }
        public CommonJunctions Temp2Junctions
        {
            get { return temp2Junctions; }
        }

        //public CommonJunctions ConsumerJunctions
        //{
        //    get { return consumerJunctions; }
        //}

        //public CommonJunctions SubscriberJunctions
        //{
        //    get { return subscriberJunctions; }
        //}
        public CommonJunctions AbonentJunctions
        {
            get { return abonJunctions; }
        }

        public CommonJunctions SGMEDGE
        {
            get { return Sgm; }
        }

        public SecondaryTracerArmatura()
        {
        }

        public SecondaryTracerArmatura(int armClassID, int consClassID, int subsClassID, int grsClassID, int juncClassID, int prgClassID, ref IGeometricNetwork geomNet)
        {
            this.armaturaClassID = armClassID;
            this.consumerClassID = consClassID;
            this.subscriberClassID = subsClassID;
            this.grsClassID = grsClassID;
            this.junctionClassID = juncClassID;
            this.prgClassID = prgClassID;
            armaturaJunctions = new CommonJunctions();
            //temp1Junctions = new CommonJunctions();
            //temp2Junctions = new CommonJunctions();
            junctionJunctions = new CommonJunctions();
            newJunctions = new CommonJunctions();
            allArmJunctions = new CommonJunctions();
            prgjunction = new CommonJunctions();
            tmpList = new CommonJunctions();
            edgejunctions = new CommonJunctions();
            //ArmGRSJunctions = new CommonJunctions();
            
            abonJunctions = new CommonJunctions();
            grsOutJunctions = new CommonJunctions();
            abon2Junctions = new CommonJunctions();
            grs2Junctions = new CommonJunctions();
            //arJunctions = new CommonJunctions();
            //---------------------------------

            Spoints = new CommonJunctions();
            SPV = new CommonJunctions();
            VSUP = new CommonJunctions();

            pass2 = new CommonJunctions();
            Psup = new CommonJunctions();
            Sgm = new CommonJunctions();
            Sgm2 = new CommonJunctions();

            utilityNetwork = geomNet.Network as IUtilityNetwork;


            if (utilityNetwork == null)
                throw (new InvalidCastException("Network не utility network"));
        }


        public void ATrace(int[] segjunction, int segment)
        {
            forwardStar = utilityNetwork.CreateForwardStar(true, null, null, null, null);
            
            newJunctions.junctions.Clear();
            for (int i = 0; i < segjunction.Length; i++)
             {
                newJunctions.Add(segjunction[i], 0, "Segments");
             }
            
            junctionJunctions.junctions.Clear();
            abonJunctions.junctions.Clear();
            allArmJunctions.junctions.Clear();
            edgejunctions.junctions.Clear();
            VSUP.junctions.Clear();
            grsOutJunctions.junctions.Clear();
            Spoints.junctions.Clear();
            SPV.junctions.Clear();
            //Sgm.junctions.Clear();

            Sgm.Add(segment, 100, "Segment");
            
            #region Первый проход

            while (newJunctions.Count > 0)
            {
                foreach (CommonJunction njunction in newJunctions)
                {

                    BTrace(njunction);
                    
                }

                newJunctions.junctions.Clear();

                if (junctionJunctions.Count != 0)
                {
                    foreach (CommonJunction jjunction in junctionJunctions)
                    {
                        GetAdjacentJunctions(jjunction);
                        if (!isSgm(jjunction.EID))
                        {
                            GetAdjacentSgmJunctions(jjunction);
                        }
                    }
                    
                }
                junctionJunctions.junctions.Clear();
                //newJunctions.junctions.AddRange(junctionJunctions.junctions);
                //junctionJunctions.junctions.Clear();
            }

            #endregion 
            #region Второй проход
            foreach (CommonJunction armjunction in allArmJunctions)
            {
                GetAdjacentArm(armjunction);
            }
           
                foreach (CommonJunction Spnt in Spoints)
                {

                    if (isPsup(Spnt.EID))
                    {
                        VSUP.Add(Spnt.SpointValve, 2, "VSUP");
                        continue;
                    }
                        //newJunctions.junctions.Clear();
                    newJunctions.Add(Spnt);
                    //GetAdjacentJunctions(armjunction);
                    abon2Junctions.junctions.Clear();
                    grs2Junctions.junctions.Clear();
                    junctionJunctions.junctions.Clear();
                    pass2.junctions.Clear();
                    Sgm2.junctions.Clear();
                    while (newJunctions.Count > 0)
                    {
                        foreach (CommonJunction njunctions in newJunctions)
                        {
                            if (GetClassID(njunctions.EID) == grsClassID)
                                grs2Junctions.Add(njunctions.EID, 4, "GRS");
                            B2Trace(njunctions);
                        }

                        //Доработка алгоритма
                        if (junctionJunctions.Count == 0 && Sgm2.Count == 0)
                        {
                            foreach (CommonJunction abon2 in abon2Junctions)
                            {
                                GetAdjacentSgm2Junctions(abon2);
                            }
                            newJunctions.junctions.Clear();
                        }
                        else
                        {
                            newJunctions.junctions.Clear();

                            foreach (CommonJunction jjunction in junctionJunctions)
                            {
                                GetAdjacentJunctions(jjunction);
                                GetAdjacentSgm2Junctions(jjunction);
                            }

                            junctionJunctions.junctions.Clear();
                        }
                    }
                    if (grs2Junctions.Count == 0)
                    {
                        abonJunctions.junctions.AddRange(abon2Junctions.junctions);
                        for (int i = 0; i < Sgm2.junctions.Count; i++)
                        {
                            if (!isSgm(Sgm2.junctions[i].EID))
                            {
                                Sgm.junctions.Add(Sgm2.junctions[i]);
                            }
                        }
                        
                    }
                    else
                    {
                        VSUP.Add(Spnt.SpointValve, 2, "VSUP");
                        Psup.junctions.AddRange(pass2.junctions);
                    }
                }
                #endregion
            
                armaturaJunctions.junctions.AddRange(VSUP.junctions);



        }

        public void ATrace(int[] segjunction, int segment,int[] junctionIDs)
        {

            for (int i = 0; i < junctionIDs.Length; i++)
            {
                tmpList.Add(junctionIDs[i]);
            }

            forwardStar = utilityNetwork.CreateForwardStar(true, null, null, null, null);

            newJunctions.junctions.Clear();
            for (int i = 0; i < segjunction.Length; i++)
            {
                newJunctions.Add(segjunction[i], 0, "Segments");
            }

            junctionJunctions.junctions.Clear();
            abonJunctions.junctions.Clear();
            allArmJunctions.junctions.Clear();
            edgejunctions.junctions.Clear();
            VSUP.junctions.Clear();
            grsOutJunctions.junctions.Clear();
            Spoints.junctions.Clear();
            SPV.junctions.Clear();
            //Sgm.junctions.Clear();

            Sgm.Add(segment, 100, "Segment");

            #region Первый проход

            while (newJunctions.Count > 0)
            {
                foreach (CommonJunction njunction in newJunctions)
                {

                    XTrace(njunction);

                }

                newJunctions.junctions.Clear();

                if (junctionJunctions.Count != 0)
                {
                    foreach (CommonJunction jjunction in junctionJunctions)
                    {
                        GetAdjacentJunctions(jjunction);
                        if (!isSgm(jjunction.EID))
                        {
                            GetAdjacentSgmJunctions(jjunction);
                        }
                    }

                }
                junctionJunctions.junctions.Clear();
                //newJunctions.junctions.AddRange(junctionJunctions.junctions);
                //junctionJunctions.junctions.Clear();
            }

            #endregion
            #region Второй проход
            foreach (CommonJunction armjunction in allArmJunctions)
            {
                GetAdjacentArm(armjunction);
            }

            foreach (CommonJunction Spnt in Spoints)
            {

                if (isPsup(Spnt.EID))
                {
                    VSUP.Add(Spnt.SpointValve, 2, "VSUP");
                    continue;
                }
                //newJunctions.junctions.Clear();
                newJunctions.Add(Spnt);
                //GetAdjacentJunctions(armjunction);
                abon2Junctions.junctions.Clear();
                grs2Junctions.junctions.Clear();
                junctionJunctions.junctions.Clear();
                pass2.junctions.Clear();
                Sgm2.junctions.Clear();
                while (newJunctions.Count > 0)
                {
                    foreach (CommonJunction njunctions in newJunctions)
                    {
                        if (GetClassID(njunctions.EID) == grsClassID)
                            grs2Junctions.Add(njunctions.EID, 4, "GRS");
                        YTrace(njunctions);
                    }

                    //Доработка алгоритма
                    if (junctionJunctions.Count == 0 && Sgm2.Count == 0)
                    {
                        foreach (CommonJunction abon2 in abon2Junctions)
                        {
                            GetAdjacentSgm2Junctions(abon2);
                        }
                        newJunctions.junctions.Clear();
                    }
                    else
                    {
                        newJunctions.junctions.Clear();

                        foreach (CommonJunction jjunction in junctionJunctions)
                        {
                            GetAdjacentJunctions(jjunction);
                            GetAdjacentSgm2Junctions(jjunction);
                        }

                        junctionJunctions.junctions.Clear();
                    }
                }
                if (grs2Junctions.Count == 0)
                {
                    abonJunctions.junctions.AddRange(abon2Junctions.junctions);
                    for (int i = 0; i < Sgm2.junctions.Count; i++)
                    {
                        if (!isSgm(Sgm2.junctions[i].EID))
                        {
                            Sgm.junctions.Add(Sgm2.junctions[i]);
                        }
                    }

                }
                else
                {
                    VSUP.Add(Spnt.SpointValve, 2, "VSUP");
                    Psup.junctions.AddRange(pass2.junctions);
                }
            }
            #endregion

            armaturaJunctions.junctions.AddRange(VSUP.junctions);



        }

        private void BTrace(CommonJunction njunctions)
        {
            if (!NodeID(njunctions.EID))
            {
                edgejunctions.Add(njunctions.EID);
                if (GetClassID(njunctions.EID) == armaturaClassID)
                {

                    allArmJunctions.Add(njunctions.EID, 2, "Valve");
                }

                if (GetClassID(njunctions.EID) == prgClassID)
                {
                    allArmJunctions.Add(njunctions.EID, 22, "PRG");
                    
                }

                if (GetClassID(njunctions.EID) == grsClassID)
                    grsOutJunctions.Add(njunctions.EID, 4, "GRS");

                if (GetClassID(njunctions.EID) == junctionClassID)
                    junctionJunctions.Add(njunctions.EID, 1, "Junction");

                if (GetClassID(njunctions.EID) == consumerClassID)
                    abonJunctions.Add(njunctions.EID, 3, "Consumer");

                if (GetClassID(njunctions.EID) == subscriberClassID)
                    abonJunctions.Add(njunctions.EID, 3, "Subscriber");

            }
        }

        private void B2Trace(CommonJunction njunctions)
        {
            if (!NodeID(njunctions.EID))
            {

                edgejunctions.Add(njunctions.EID);
                pass2.Add(njunctions.EID);

                if (GetClassID(njunctions.EID) == armaturaClassID)
                    junctionJunctions.Add(njunctions.EID, 2, "Valve");
                if (GetClassID(njunctions.EID) == prgClassID)
                    junctionJunctions.Add(njunctions.EID, 22, "PRG");

                //if (GetClassID(njunctions.EID) == grsClassID)
                //    grs2Junctions.Add(njunctions.EID, 4, "GRS");

                if (GetClassID(njunctions.EID) == junctionClassID)
                    junctionJunctions.Add(njunctions.EID, 1, "Junction");

                if (GetClassID(njunctions.EID) == consumerClassID)
                    abon2Junctions.Add(njunctions.EID, 3, "Consumer");

                if (GetClassID(njunctions.EID) == subscriberClassID)
                    abon2Junctions.Add(njunctions.EID, 3, "Subscriber");

           }
        }

        private void XTrace(CommonJunction njunctions)
        {
            if (!NodeID(njunctions.EID))
            {
                edgejunctions.Add(njunctions.EID);
                if (GetClassID(njunctions.EID) == armaturaClassID)
                {
                    if(isValve(njunctions.EID))
                        junctionJunctions.Add(njunctions.EID, 2, "VALVE");
                    else allArmJunctions.Add(njunctions.EID, 2, "Valve");
                }

                if (GetClassID(njunctions.EID) == prgClassID)
                {
                    if (isValve(njunctions.EID))
                        junctionJunctions.Add(njunctions.EID, 22, "PRG");
                    else allArmJunctions.Add(njunctions.EID, 22, "PRG");

                }

                if (GetClassID(njunctions.EID) == grsClassID)
                    grsOutJunctions.Add(njunctions.EID, 4, "GRS");

                if (GetClassID(njunctions.EID) == junctionClassID)
                    junctionJunctions.Add(njunctions.EID, 1, "Junction");

                if (GetClassID(njunctions.EID) == consumerClassID)
                    abonJunctions.Add(njunctions.EID, 3, "Consumer");

                if (GetClassID(njunctions.EID) == subscriberClassID)
                    abonJunctions.Add(njunctions.EID, 3, "Subscriber");

            }

        }

        private void YTrace(CommonJunction njunctions)
        {
            if (!NodeID(njunctions.EID))
            {

                edgejunctions.Add(njunctions.EID);
                pass2.Add(njunctions.EID);

                if (GetClassID(njunctions.EID) == armaturaClassID)
                    junctionJunctions.Add(njunctions.EID, 2, "Valve");
                if (GetClassID(njunctions.EID) == prgClassID)
                    junctionJunctions.Add(njunctions.EID, 22, "PRG");

                //if (GetClassID(njunctions.EID) == grsClassID)
                //    grs2Junctions.Add(njunctions.EID, 4, "GRS");

                if (GetClassID(njunctions.EID) == junctionClassID)
                    junctionJunctions.Add(njunctions.EID, 1, "Junction");

                if (GetClassID(njunctions.EID) == consumerClassID)
                    abon2Junctions.Add(njunctions.EID, 3, "Consumer");

                if (GetClassID(njunctions.EID) == subscriberClassID)
                    abon2Junctions.Add(njunctions.EID, 3, "Subscriber");

            }
        }

        private void GetAdjacentJunctions(CommonJunction jjunction)
        {
            int numEdges;
            
            forwardStar.FindAdjacent(0, jjunction.EID, out numEdges);
            for (int i = 0; i < numEdges; i++)
            {
                int childJunctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out childJunctionEID, out netWt);
                newJunctions.Add(childJunctionEID, 1, "New junction");
            }
        }

        private void GetJunction(int EdgeID)
        {
            int numEdges;

            forwardStar.FindAdjacent(0, EdgeID, out numEdges);
            for (int i = 0; i < numEdges; i++)
            {
                int childJunctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out childJunctionEID, out netWt);
                newJunctions.Add(childJunctionEID, 1, "New junction");
            }
        }

        private void GetAdjacentSgmJunctions(CommonJunction sgmjunction)
        {
            int numEdges;
            forwardStar.FindAdjacent(0, sgmjunction.EID, out numEdges);
            int AdjEDGE;
            bool reverseOr;
            object adWV;
            for (int i = 0; i < numEdges; i++)
            {
                forwardStar.QueryAdjacentEdge(i, out AdjEDGE, out reverseOr, out adWV);
                //int childJunctionEID;
                //object netWt;
                //forwardStar.QueryAdjacentJunction(i, out childJunctionEID, out netWt);
                if(!isSgm(AdjEDGE))
                Sgm.Add(AdjEDGE, 5, "SGM EDGE");
            }
        }
        private void GetAdjacentSgm2Junctions(CommonJunction sgmjunction)
        {
            int numEdges;
            forwardStar.FindAdjacent(0, sgmjunction.EID, out numEdges);
            int AdjEDGE;
            bool reverseOr;
            object adWV;
            for (int i = 0; i < numEdges; i++)
            {
                //int childJunctionEID;
                //object netWt;
                //forwardStar.QueryAdjacentJunction(i, out childJunctionEID, out netWt);
                forwardStar.QueryAdjacentEdge(i, out AdjEDGE, out reverseOr, out adWV);
                
                Sgm2.Add(AdjEDGE, 5, "SGM EDGE");
            }
        }


        private void GetAdjacentArm(CommonJunction armjunction)
        {
            int numEdges;
            forwardStar.FindAdjacent(0, armjunction.EID, out numEdges);
            for (int i = 0; i < numEdges; i++)
            {
                int childJunctionEID;
                object netWt;
                forwardStar.QueryAdjacentJunction(i, out childJunctionEID, out netWt);
                if(!NodeID(childJunctionEID))
                Spoints.Add(childJunctionEID, 1, "Arm junction",armjunction.EID,"Arm");
            }
        }

        private bool NodeID(int EID)
        {
            for (int i = 0; i < edgejunctions.junctions.Count; i++)
            {
                if (edgejunctions.junctions[i].EID == EID)
                {
                    return true;
                }
            }
            return false;
        }

        private bool isValve(int EID)
        {
            for (int i = 0; i < tmpList.junctions.Count; i++)
            {
                if (tmpList.junctions[i].EID == EID)
                {
                    return true;
                }
            }
            return false;
        }

        private bool isSgm(int EID)
        {
            for (int i = 0; i < Sgm.junctions.Count; i++)
            {
                if (Sgm.junctions[i].EID == EID)
                {
                    return true;
                }
            }
            return false;

        }
        private bool isPsup(int EID)
        {
            for (int i = 0; i < Psup.junctions.Count; i++)
            {
                if (Psup.junctions[i].EID == EID)
                {
                    return true;
                }
            }
            return false;
        }


        private int GetClassID(int eid)
        {
            try
            {
                INetElements netElements = (INetElements)utilityNetwork;
                int classID; int userID; int userSubID;
                netElements.QueryIDs(eid, esriElementType.esriETJunction, out classID, out userID, out userSubID);
                return classID;
            }
            catch (Exception e)
            {
                Trace.WriteLine(e.ToString());
                return -1;
            }
        }

        public static int ClassIDFromName(string featureClassName, IWorkspace mapWksp)
        {
            string name = featureClassName;
            int periodIndex = name.IndexOf(".", 0);
            if (periodIndex != -1)
            {
                name = name.Substring(periodIndex + 1);
            }

            IEnumDatasetName featureDatasetNames = mapWksp.get_DatasetNames(esriDatasetType.esriDTFeatureDataset);
            IDatasetName featureDatasetName = featureDatasetNames.Next();
            while (featureDatasetName != null)
            {
                int classID = ClassIDFromName(featureDatasetName, name);
                if (classID != 0)
                {
                    Marshal.ReleaseComObject(featureDatasetNames);
                    Marshal.ReleaseComObject(featureDatasetName);
                    return classID;
                }

                featureDatasetName = featureDatasetNames.Next();
            }
            Marshal.ReleaseComObject(featureDatasetNames);
            Marshal.ReleaseComObject(featureDatasetName);
            return 0;
        }

        private static int ClassIDFromName(IDatasetName featureDatasetName, string className)
        {
            int classID = 0;
            IEnumDatasetName featureClassNames = featureDatasetName.SubsetNames;
            IDatasetName featureClassName = featureClassNames.Next();
            while (featureClassName != null)
            {
                string name = featureClassName.Name;
                int periodIndex = name.IndexOf(".", 0);
                if (periodIndex != -1)
                {
                    name = name.Substring(periodIndex + 1);
                }
                if (string.Compare(name, className, true) == 0)
                {
                    IObjectClassName objClassName = (IObjectClassName)featureClassName;
                    classID = objClassName.ObjectClassID;
                    break;
                }
                featureClassName = featureClassNames.Next();
            }
            Marshal.ReleaseComObject(featureClassNames);
            Marshal.ReleaseComObject(featureDatasetName);
            return classID;
        }
    }
}
