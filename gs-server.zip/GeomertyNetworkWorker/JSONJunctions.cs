﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Serialization;
using System.IO;
using System.Xml;
using System.Reflection;
using Newtonsoft.Json;

namespace GeomertyNetworkWorker
{
    public class JSONJunctions
    {
        public List<Dictionary<string, object>> junctions { get; set; }

        public int Count
        {
            get { return junctions.Count; }
        }

        public JSONJunctions()
        {
            junctions = new List<Dictionary<string, object>>();
        }        
        public JSONJunctions(Dictionary<string, object> junction)
            : this()
        {
            junctions.Add(junction);
        }
        public Dictionary<string, object> Add(Dictionary<string, object> junction)
        {
            junctions.Add(junction);
            return junction;
        }

        #region Implementation of IEnumerable
        public System.Collections.IEnumerator GetEnumerator()
        {
            return junctions.GetEnumerator();
        }
        #endregion

        public string getJSON()
        {
            string json = JsonConvert.SerializeObject(junctions);

            return json;
        }

        public string getJSONSingle()
        {
            List<Dictionary<string, object>> junctionsSingle = new List<Dictionary<string, object>>();
            bool isHave = false;
            for (int i = 0; i < junctions.Count; i++)
            {
                isHave = false;
                for (int j = 0; j < junctionsSingle.Count; j++)
                {
                    if ((int)(junctions[i]["eid"]) == (int)(junctionsSingle[j]["eid"]))
                    {
                        isHave = true;
                        break;
                    }
                }
                if (!isHave)
                {
                    junctionsSingle.Add(junctions[i]);
                }
            }
            string json = JsonConvert.SerializeObject(junctionsSingle);

            return json;
        }


    }
}
