﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeomertyNetworkWorker
{
    class CalculateGasReserve

    {
        public static double calculateVolume( double diameter, double length)
        {
           return (((Math.PI * (diameter * diameter)) / 4) * length);
        }
        public static double calculateGasReserve (double Volume, double AbsMiddlePressure, double GasCompressFactor, double MiddleTemperature)
        {
            double _GasReserve;
            _GasReserve = (Volume * AbsMiddlePressure * (273.15 + 20))/(1.033 * GasCompressFactor * MiddleTemperature);
            return _GasReserve;
        }

        public static double calculateFactMiddlePressure(double StartPressure, double EndPressure)
        {
            double _FactualPressure;
            
            double fuckTmp = 2D / 3D;
            _FactualPressure = fuckTmp * (StartPressure + ((EndPressure * EndPressure) / (StartPressure + EndPressure)));
            return _FactualPressure;
        }
        public static double calculateAbsMiddlePressure(double FactualPressure)
        {
            
            return FactualPressure + 1;
        }

        public static double calculateGasCompressFactor (double MiddleTemperature, double AbsMiddlePressure, double Density = 0.7011)
        {
            double _rTemperature;
            double _rPressure;
            double _Temperature;
            double _Pressure;
            double _GasCompressFactor;
            _Temperature = 155.24 * (0.564 + Density);
            _Pressure = 1.808 * (26.831 - Density);
            _rTemperature = MiddleTemperature / _Temperature;
            _rPressure = AbsMiddlePressure / _Pressure;

           _GasCompressFactor = 1 - ((0.0241 * _rPressure) / (1 - (1.68 * _rTemperature) + (0.78 * Math.Pow(_rTemperature,2)) + (0.0107 * Math.Pow(_rTemperature,3))));

            return _GasCompressFactor;
        }

        public static double calculateMiddleTemperature (double StartTemperature, double EndTemperature, double GroundTemperature)
        {
            double _MiddleTemperature;
            if (StartTemperature == EndTemperature && StartTemperature == GroundTemperature && EndTemperature == GroundTemperature)
            {
                return  StartTemperature + 273.15;
            }
            double _tempStartEnd = StartTemperature - EndTemperature;
            double _tempStartGround = StartTemperature - GroundTemperature;
            double _tempEndGround = EndTemperature - GroundTemperature;
            double _tempLn = Math.Log(_tempStartGround / _tempEndGround);
            _MiddleTemperature = GroundTemperature + (_tempStartEnd / _tempLn) + 273.15;
            return _MiddleTemperature;
        }

        public static double convertToMeter (double convertNumber)
        {
            return convertNumber*0.001;
        }
        public static double convertFromMPaToKGS_CM2 (double convertNumber)
        {
            return convertNumber * 10.1971621297793;
        }
        public static double convertFromKGS_CM2ToMPa(double convertNumber)
        {
            return convertNumber * 0.0980665;
        }
        public static double convertToCelsius (double convertNumber)
        {
            return convertNumber-273.15;
        }
       


       

    }
}
