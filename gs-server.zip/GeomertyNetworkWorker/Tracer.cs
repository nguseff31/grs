﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.IO;

namespace GazServiceTools
{
    class TraceInfo
    {
        public TimeSpan diff;
        public StackFrame startFrame;
        public StackFrame stopFrame;
        public int level;
        public string name;
    }
    class Tracer
    {
        Stack<Timer> stack;
        Stack<TraceInfo> infoStack;

        public Tracer()
        {
            this.stack = new Stack<Timer>();
            infoStack = new Stack<TraceInfo>();
            infoStack.Push(null);
        }
        public void StartTrace(string periodName)
        {
            Timer t = new Timer(periodName);
            if (stack.Count == 0)
                t.level = 1;
            else
                t.level = stack.Peek().level + 1;
            stack.Push(t);
            stack.Peek().Start();
        }
        public void StopTrace()
        {
            if (stack.Count == 0)
                throw new Exception("Timer call stack error. There is missing Stop() call somewhere");
            Timer current = stack.Pop();
            current.Stop();
            TraceInfo info = new TraceInfo
            {
                diff = current.result,
                startFrame = current.startFrame,
                level = current.level,
                stopFrame = current.stopFrame,
                name = current.name
            };
            infoStack.Push(info);
        }

        public string getMessage()
        {
            if (stack.Count != 0)
                return "Timer call stack is not empty, missed stop statement";
            string msg = "";
            TraceInfo ti;
            while ((ti = infoStack.Pop()) != null)
            {
                msg += String.Format("{0}:`{1}` trace start:{2} in {3}, stop:{4} in {5}. {6} seconds run time.\n", new String('-', ti.level), ti.name, ti.startFrame.GetFileLineNumber(), Path.GetFileName(ti.startFrame.GetFileName()), ti.stopFrame.GetFileLineNumber(), Path.GetFileName(ti.stopFrame.GetFileName()), ti.diff.TotalSeconds);
            }
            return msg;
        }
    }
    class StatisticTraceInfo
    {
        public LinkedList<double> callTimes;
        public StackFrame startFrame;
        public StackFrame stopFrame;
        public DateTime lastTime;
        public bool started;
        public int calls;
    }
    class NullTracer
    {
        public void Start(string name)
        {
        }
        public void Stop(string name)
        {
        }
        public string getMessage()
        {
            return "This is null tracer. Use Tracer and StatisticTracer classes to get trace info.";
        }
        public void StartTrace(string name)
        {
        }
        public void StopTrace(string name)
        {
        }
        public string getAllStatistic()
        {
            return "This is null tracer. Use Tracer and StatisticTracer classes to get trace info.";
        }
    }
    class StatisticTracer
    {
        Dictionary<string, StatisticTraceInfo> dict;
        string[] statistics;

        public StatisticTracer()
        {
            dict = new Dictionary<string, StatisticTraceInfo>();
            statistics = new string[] { "Sum", "Average", "Deviation", "Calls"};
        }
        public Dictionary<string, double> preProcess(IEnumerable<double> arr)
        {
            double sum = 0;
            double sq = 0;
            int count = 0;

            foreach(double a in arr) {
                sum += a;
                sq += a * a;
                count++;
            }
            double sum_sq = sum * sum;
            double avg = sum / count;
            double dev = (sq - sum_sq / count) / (count - 1);
            return new Dictionary<string, double> { 
                { "Sum", sum },
                { "Average", avg },
                { "Calls", count },
                { "Deviation", dev }
            };
        }
        
        public string getStatistic(string name)
        {
            string stat = "Statistics for " + name + "\n";
            Dictionary<string, double> results = preProcess(dict[name].callTimes);
            foreach (string statistic in statistics)
            {
                stat += "--" + statistic + ": " + results[statistic] + "\n";
            }
            return stat;
        }
        public string getAllStatistic()
        {
            string stat = "";
            foreach (KeyValuePair<string, StatisticTraceInfo> pair in dict)
            {
                stat += getStatistic(pair.Key) + "\n";
            }
            return stat;
        }
        public void Start(string name)
        {
            if (dict.ContainsKey(name))
            {
                dict[name].lastTime = DateTime.Now;
                dict[name].started = true;
            }
            else
            {
                StatisticTraceInfo si = new StatisticTraceInfo {
                  callTimes = new LinkedList<double>(),
                  calls = 0,
                  startFrame = new StackFrame(1, true),
                  started = true,
                  lastTime = DateTime.Now
                };
                dict.Add(name, si);
            }
        }
        public void Stop(string name)
        {
            if (!dict.ContainsKey(name))
                throw new Exception("Start `" + name + "` timer before Stop it");
            if(!dict[name].started)
                throw new Exception("Start `" + name + "` timer before Stop it");
            dict[name].started = false;
            DateTime now = DateTime.Now;
            dict[name].callTimes.AddLast((now - dict[name].lastTime).TotalSeconds);
            dict[name].lastTime = now;
            if (dict[name].calls == 0)
            {
                dict[name].stopFrame = new StackFrame(1, true);
            }
            dict[name].calls++;
        }
    }
    class Timer
    {
        DateTime from;
        DateTime to;
        bool started = false;
        public string name;
        public TimeSpan result;
        public StackFrame startFrame;
        public StackFrame stopFrame;
        public int level;

        public Timer(string periodName, int level = 0)
        {
            this.name = periodName;
            this.level = level;
        }
        public void Start()
        {
            if (started)
                throw new Exception("Timer already started");
            from = DateTime.Now;
            startFrame = new StackFrame(2, true);
            started = true;
        }
        public TimeSpan Stop()
        {
            if (!started)
                throw new Exception("Before call Stop() start Timer first");
            to = DateTime.Now;
            this.result = to - from;
            stopFrame = new StackFrame(2, true);
            return this.result;
        }

    }
}