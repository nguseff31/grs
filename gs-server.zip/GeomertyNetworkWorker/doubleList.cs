﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeomertyNetworkWorker
{
public class doubleList
{
   public double _x;
   public double _y;

 
   public doubleList(double X, double Y)
   {
       this._x = X;
       this._y = Y;

   }

}
}
