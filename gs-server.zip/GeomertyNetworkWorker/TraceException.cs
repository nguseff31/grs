﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeomertyNetworkWorker
{
    public class TraceException : Exception
    {
        private string message;
        public TraceException(string Message)
            : base()
        {
            message = Message;
        }

        public override string Message
        {
            get
            {
                return message;
            }
        }
    }
}
